/**
 * Standardized Qualification Point Scale — global configuration variables.
 *
 * These constants are the single source of truth for the cross-category
 * qualification race. The backend leaderboard engine cross-checks them every
 * time a board is assembled, so the moment a director updates a team's status
 * in /director-dashboard the public team rows re-derive from these values in
 * real time.
 */

/** Points for clearing Round 1 of a Compulsory category. */
export const COMPULSORY_R1 = 40;
/** Points for clearing Round 2 of a Compulsory category. */
export const COMPULSORY_R2 = 70;
/** Points for a Round 3 podium finish in a Compulsory category. */
export const COMPULSORY_R3 = 150;

/** Points for clearing Round 1 of an Optional category. */
export const OPTIONAL_R1 = 25;
/** Points for clearing Round 2 of an Optional category. */
export const OPTIONAL_R2 = 45;
/** Points for a Round 3 podium finish in an Optional category. */
export const OPTIONAL_R3 = 100;

/**
 * The pool of 3 Compulsory-track categories. Each team dynamically selects
 * exactly 2 of these 3 as its Compulsory events, alongside 3 Optional events,
 * for a total of exactly 5 active categories per team.
 */
export const COMPULSORY_POOL = ["vinculum", "science-frenzy", "scilase"] as const;

/** Whether a category slug belongs to the Compulsory track. */
export function isCompulsoryCategory(slug: string): boolean {
  return (COMPULSORY_POOL as readonly string[]).includes(slug);
}

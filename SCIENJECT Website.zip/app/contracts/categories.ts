// Shared static catalog for SCIENJECT 6.0 — used by the DB seed and the frontend.

export const LAUNCH_DATE_ISO = "2026-10-02T09:00:00";
export const VENUE_NAME = "Lahore Grammar School Gulberg 15C and 16C O/A Level Campus";
/** Official delegate registration Google Form — the ONLY target of the Register CTA. */
export const REGISTRATION_FORM_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLSfo1DNPPT2IFVVini-wWwvMOBEiHFLyRIdYuPPqd1E6vWkQsw/viewform?utm_source=ig&utm_medium=social&utm_content=link_in_bio";

/**
 * Venue routing engine — two campus branches and a strict five-option floor
 * matrix. Legacy building "Block" configurations are removed; the floor dropdown
 * is hardcoded to exactly these five selections, and a custom room/allocation
 * text field stays active in the admin venue mapper for bespoke room/lab codes.
 */
export const VENUE_FLOORS = ["1st Floor", "2nd Floor", "3rd Floor", "Courtyard/Open Area", "Auditorium"] as const;

export const VENUE_BRANCHES = [
  {
    label: "16C A-Levels Branch",
    description: "A-Levels campus layout — 16C",
    areas: VENUE_FLOORS,
  },
  {
    label: "15C O-Levels Branch",
    description: "O-Levels campus layout — 15C",
    areas: VENUE_FLOORS,
  },
] as const;

export interface CategoryDef {
  slug: string;
  name: string;
  discipline: string; // e.g. "Pure Mathematics & Arithmetic Logic"
  description: string;
  room: string;
  venue: string;
  icon: string; // lucide icon name
  order: number;
}

export const CATEGORIES: CategoryDef[] = [
  {
    slug: "vinculum",
    name: "Vinculum",
    discipline: "Pure Mathematics & Arithmetic Logic",
    description:
      "Tests calculation speed, numerical problem-solving, and point-wagering auction strategies.",
    room: "Maths Gallery",
    venue: "15C O-Levels Branch · 1st Floor",
    icon: "Sigma",
    order: 1,
  },
  {
    slug: "science-frenzy",
    name: "Science Frenzy",
    discipline: "Chemistry & Applied Mechanical Physics",
    description:
      "Combines chemical reaction testing with manual catapult engineering and projectile trajectory tracking.",
    room: "Auditorium A",
    venue: "15C O-Levels Branch · Auditorium",
    icon: "FlaskConical",
    order: 2,
  },
  {
    slug: "aqualibrium",
    name: "Aqualibrium",
    discipline: "Ecology, Sustainability & Climate Tech",
    description:
      "Evaluates case-study analysis on ecological tracking and green technology implementation.",
    room: "Eco Pavilion",
    venue: "15C O-Levels Branch · Courtyard/Open Area",
    icon: "Leaf",
    order: 3,
  },
  {
    slug: "sleuths-saga",
    name: "Sleuth's Saga",
    discipline: "Forensic Science & Inductive Logic",
    description:
      "Tests deductive processing through forensic evidence file parsing and timeline contradictions.",
    room: "Seminar Hall 2",
    venue: "15C O-Levels Branch · 2nd Floor",
    icon: "Search",
    order: 4,
  },
  {
    slug: "robomatrix",
    name: "Robomatrix",
    discipline: "Mechatronics & Robotics Engineering",
    description:
      "Evaluates basic electronic circuit configuration, autonomous sensory calibration, and mechanical navigation.",
    room: "Robotics Lab",
    venue: "16C A-Levels Branch · 2nd Floor",
    icon: "Bot",
    order: 5,
  },
  {
    slug: "avionix",
    name: "Avionix",
    discipline: "Aerodynamics & Aviation Systems",
    description:
      "Examines flight physics, aerodynamic design parameters, and structural mechanics under operational stress.",
    room: "Tech Wing Room 103",
    venue: "16C A-Levels Branch · 1st Floor",
    icon: "Plane",
    order: 6,
  },
  {
    slug: "equinox",
    name: "Equinox",
    discipline: "Astronomy & Astrophysics",
    description:
      "Reviews orbital mechanics, stellar physics, and structural blueprint modeling for space settlements.",
    room: "Planetarium Dome",
    venue: "15C O-Levels Branch · 3rd Floor",
    icon: "Moon",
    order: 7,
  },
  {
    slug: "scilase",
    name: "Scilase",
    discipline: "Molecular Biology & Epidemiology",
    description:
      "Handles biochemistry and public health logistics, exploring organic extraction protocols and transmission tracking frameworks.",
    room: "Optics Lab 1",
    venue: "15C O-Levels Branch · 1st Floor",
    icon: "Zap",
    order: 8,
  },
  {
    slug: "pitchcraft",
    name: "Pitch Craft",
    discipline: "Acoustical Physics & Waveform Editing",
    description:
      "Covers audio engineering fundamentals, testing frequency/pitch identification alongside digital waveform synthesis.",
    room: "Innovation Studio",
    venue: "16C A-Levels Branch · 1st Floor",
    icon: "Mic",
    order: 9,
  },
  {
    slug: "entrepreneurship-x-stem",
    name: "Entrepreneurship X STEM",
    discipline: "Quantitative Economics & Venture Design",
    description:
      "Tests technical commercial viability by evaluating supply costs, market-entry strategy, and scalable operational budgeting.",
    room: "Boardroom B",
    venue: "16C A-Levels Branch · 2nd Floor",
    icon: "Briefcase",
    order: 10,
  },
  {
    slug: "neuroflix",
    name: "Neuroflix",
    discipline: "Sci-Fi Analytical Theory & Technology Policy",
    description:
      "Evaluates hard-science concepts in fiction, focusing on narrative timeline sequencing and global technology diplomacy.",
    room: "Bio Lab 2",
    venue: "15C O-Levels Branch · 2nd Floor",
    icon: "Brain",
    order: 11,
  },
  {
    slug: "tech-valley",
    name: "Tech Valley",
    discipline: "Data Structures & Applied Cryptography",
    description:
      "Computer science baseline testing string decryption techniques, algorithm troubleshooting, and prototype design.",
    room: "Computing Lab 3",
    venue: "16C A-Levels Branch · 3rd Floor",
    icon: "Code",
    order: 12,
  },
  {
    slug: "femstem",
    name: "FemStem",
    discipline: "Legal Frameworks & Historical Science",
    description:
      "Combines debates on gender equity in STEM with analytical puzzles detailing landmark scientific milestones.",
    room: "Seminar Hall 1",
    venue: "15C O-Levels Branch · 1st Floor",
    icon: "Sparkles",
    order: 13,
  },
];

export interface DepartmentDef {
  slug: string;
  name: string;
  remit: string;
}

export const DEPARTMENTS: DepartmentDef[] = [
  { slug: "media", name: "Media", remit: "Photography, videography & live coverage" },
  { slug: "registrations", name: "Registrations", remit: "Delegate rosters, fees & attendance" },
  { slug: "logistics", name: "Logistics", remit: "Rooms, equipment & material supply" },
  { slug: "publications", name: "Publications", remit: "Study guides, briefs & printed matter" },
  { slug: "marketing", name: "Marketing", remit: "Outreach, socials & sponsor relations" },
  { slug: "security", name: "Security", remit: "Campus safety, access & crowd control" },
];

export const EVENT_SCHEDULE = [
  { time: "08:30", date: "Oct 2", title: "Delegate Registration & Kit Collection", venue: "Main Atrium" },
  { time: "09:00", date: "Oct 2", title: "Grand Opening Ceremony", venue: "Auditorium A" },
  { time: "10:00", date: "Oct 2", title: "Round 1 — All 13 Categories Begin", venue: "Category Rooms" },
  { time: "17:00", date: "Oct 2", title: "Round 1 Evaluation Window Closes", venue: "Director Portals" },
  { time: "09:30", date: "Oct 3", title: "Round 2 — Semifinal Challenges", venue: "Category Rooms" },
  { time: "16:30", date: "Oct 3", title: "Round 2 Evaluation Window Closes", venue: "Director Portals" },
  { time: "10:00", date: "Oct 4", title: "Round 3 — Grand Finals", venue: "Auditorium A & Arenas" },
  { time: "18:00", date: "Oct 4", title: "Valedictory & Prize Ceremony", venue: "Main Stage" },
];

export const CONTACTS = {
  directors: [
    { name: "Alizay Ali Khan", phone: "+92 316 4781886" },
    { name: "Abdul Munim", phone: "+92 313 1486593" },
  ],
  eventHeads: [
    { name: "Ali Hassan Naveed", phone: "+92 313 6134869" },
    { name: "Noor ul Huda Jehangir", phone: "+92 324 9758080" },
    { name: "Ghazia Abid", phone: "+92 306 4456666" },
  ],
  instagram: "@scienject_6.0",
  email: "scienject6.0@gmail.com",
};

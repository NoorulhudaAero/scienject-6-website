import { Hexagon } from "lucide-react";
import { trpc } from "@/providers/trpc";

/** Infinite-loop sponsor marquee fixed at the bottom of public pages (DB-driven). */
export function SponsorCarousel() {
  const { data } = trpc.public.sponsors.useQuery(undefined, { refetchInterval: 30000 });
  if (!data || data.length === 0) return null;
  const doubled = [...data, ...data];
  return (
    <footer className="border-t border-[#D4AF37]/25 bg-[#0c0b07]">
      <div className="py-2 text-center">
        <span className="font-display text-[10px] font-semibold uppercase tracking-[0.4em] text-[#C5A059]">
          Official Partners of SCIENJECT 6.0
        </span>
      </div>
      <div className="marquee-paused overflow-hidden pb-4 pt-1">
        <div className="animate-marquee-slow flex w-max items-center gap-10 px-4">
          {doubled.map((sponsor, i) => (
            <div
              key={`${sponsor}-${i}`}
              className="flex shrink-0 items-center gap-2.5 rounded-lg border border-[#D4AF37]/25 bg-[#121212] px-5 py-2.5"
            >
              <Hexagon className="h-4 w-4 text-[#D4AF37]" />
              <span className="font-display text-xs font-semibold tracking-[0.18em] text-[#F3E5AB]/90 whitespace-nowrap">
                {sponsor}
              </span>
            </div>
          ))}
        </div>
      </div>
      <div className="border-t border-[#D4AF37]/15 py-3 text-center text-[11px] tracking-wide text-muted-foreground">
        SCIENJECT 6.0 · Lahore Grammar School Gulberg 15C and 16C O/A Level Campus · October 2–4, 2026
      </div>
    </footer>
  );
}

import { useEffect, useState } from "react";

/** Ticking clock — re-renders the consumer every `intervalMs`. */
export function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

function useCountdown(target: Date) {
  const now = useNow(1000);
  const diff = Math.max(0, target.getTime() - now);
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return { days, hours, minutes, seconds, done: diff === 0 };
}

const pad = (n: number) => String(n).padStart(2, "0");

/** Hero countdown: 4 gold-bordered cards (DAYS / HOURS / MINUTES / SECONDS). */
export function HeroCountdown({ target }: { target: Date }) {
  const { days, hours, minutes, seconds, done } = useCountdown(target);
  const cells = [
    { label: "DAYS", value: pad(days) },
    { label: "HOURS", value: pad(hours) },
    { label: "MINUTES", value: pad(minutes) },
    { label: "SECONDS", value: pad(seconds) },
  ];
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-5">
      {cells.map((c) => (
        <div key={c.label} className="gold-card gold-pulse rounded-xl px-4 py-6 text-center sm:px-6 sm:py-8">
          <div className="font-mono2 text-4xl font-bold gold-text sm:text-6xl tabular-nums">{done ? "00" : c.value}</div>
          <div className="mt-2 text-[10px] font-semibold uppercase tracking-[0.35em] text-muted-foreground sm:text-xs">
            {c.label}
          </div>
        </div>
      ))}
    </div>
  );
}

/** Compact glowing gold digital countdown for round evaluation windows. */
export function RoundCountdown({ target, label }: { target: Date; label: string }) {
  const { days, hours, minutes, seconds, done } = useCountdown(target);
  return (
    <div className="inline-flex flex-col items-center gap-1 rounded-lg border border-[#D4AF37]/50 bg-[#121212] px-5 py-3 gold-pulse">
      <span className="text-[10px] font-semibold uppercase tracking-[0.3em] text-[#C5A059]">{label}</span>
      {done ? (
        <span className="font-mono2 text-lg font-bold text-red-400">WINDOW CLOSED</span>
      ) : (
        <span className="font-mono2 text-xl font-bold digital-glow tabular-nums sm:text-2xl">
          {days > 0 ? `${pad(days)}d : ` : ""}{pad(hours)}h : {pad(minutes)}m : {pad(seconds)}s
        </span>
      )}
    </div>
  );
}

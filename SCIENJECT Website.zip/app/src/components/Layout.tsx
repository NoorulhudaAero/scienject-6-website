import type { ReactNode } from "react";
import { Instagram, Mail } from "lucide-react";
import { Ticker } from "./Ticker";
import { SiteHeader } from "./SiteHeader";
import { SponsorCarousel } from "./SponsorCarousel";
import { FloatingBadge } from "./FloatingBadge";
import { FlashAlertOverlay } from "./FlashAlertOverlay";
import { SocialFloat } from "./SocialFloat";
import { CONTACTS } from "@contracts/categories";

/** Footer connect bar — the permanent home of the official email + Instagram. */
function ConnectFooter() {
  return (
    <footer className="border-t border-[#D4AF37]/25 bg-[#0A0A0A]">
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="mb-5 text-center font-display text-xs font-semibold uppercase tracking-[0.4em] text-[#C5A059]">
          Connect With Us
        </div>
        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row sm:gap-12">
          <a
            href={`mailto:${CONTACTS.email}`}
            className="flex items-center gap-3 rounded-xl border border-[#D4AF37]/40 bg-[#121212] px-6 py-3 transition hover:border-[#D4AF37] hover:bg-[#D4AF37]/10"
          >
            <Mail className="h-5 w-5 text-[#D4AF37]" />
            <span className="font-mono2 text-base font-bold text-[#F3E5AB] sm:text-lg">{CONTACTS.email}</span>
          </a>
          <a
            href="https://instagram.com/scienject_6.0"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-3 rounded-xl border border-[#D4AF37]/40 bg-[#121212] px-6 py-3 transition hover:border-[#D4AF37] hover:bg-[#D4AF37]/10"
          >
            <Instagram className="h-5 w-5 text-[#D4AF37]" />
            <span className="font-mono2 text-base font-bold text-[#F3E5AB] sm:text-lg">{CONTACTS.instagram}</span>
          </a>
        </div>
        <p className="mt-6 text-center text-[10px] uppercase tracking-[0.3em] text-muted-foreground">
          SCIENJECT 6.0 · Lahore Grammar School Gulberg 15C and 16C O/A Level Campus · October 2–4, 2026
        </p>
      </div>
    </footer>
  );
}

export function Layout({ children, sponsors = true }: { children: ReactNode; sponsors?: boolean }) {
  return (
    <div className="luxury-bg min-h-screen flex flex-col">
      <Ticker />
      <SiteHeader />
      <FloatingBadge />
      <SocialFloat />
      <main className="flex-1 pt-[92px]">{children}</main>
      {sponsors && <SponsorCarousel />}
      <ConnectFooter />
      <FlashAlertOverlay />
    </div>
  );
}

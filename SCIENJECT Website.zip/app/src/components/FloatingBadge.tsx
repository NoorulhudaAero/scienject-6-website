import { useLocation, useNavigate } from "react-router";
import { Zap } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { clearSession, getAllSessions, type StoredSession } from "@/lib/auth";

/**
 * Floating gold control badge — anchored top-right on public screens whenever a
 * valid staff token exists. Clicking restores the user's workspace instantly,
 * with no re-login or PIN prompt. Tokens are only ever cleared by manual logout.
 */
export function FloatingBadge() {
  const navigate = useNavigate();
  const location = useLocation();
  const sessions = getAllSessions();

  // Validate the highest-priority stored session (admin > director > department)
  const ordered: StoredSession[] = ["admin", "director", "department"]
    .map((r) => sessions.find((s) => s.role === r))
    .filter((s): s is StoredSession => Boolean(s));

  const candidate = ordered[0] ?? null;

  const validation = trpc.auth.validate.useQuery(
    { token: candidate?.token ?? "" },
    { enabled: Boolean(candidate), retry: false, staleTime: 5 * 60_000 },
  );

  if (!candidate) return null;

  // Only hide after a definitive invalid response — never on transient errors
  if (validation.isFetched && (validation.isError || validation.data?.role !== candidate.role)) {
    clearSession(candidate.role);
    return null;
  }

  const meta =
    candidate.role === "admin"
      ? { label: "Return to Master Admin Desk", path: "/admin" }
      : candidate.role === "director"
        ? { label: `Return to ${validation.data?.categoryName ?? candidate.categoryName ?? "Category"} Workspace`, path: "/director-dashboard" }
        : { label: `Return to ${validation.data?.departmentName ?? candidate.departmentName ?? "Department"} Desk`, path: "/department-dashboard" };

  // Hide while the user is already inside that workspace
  if (location.pathname === meta.path) return null;

  return (
    <button
      onClick={() => navigate(meta.path)}
      className="fixed right-4 top-[104px] z-40 flex items-center gap-2 rounded-full border border-[#D4AF37] bg-[#0A0A0A]/95 py-2 pl-3.5 pr-4 shadow-[0_0_26px_rgba(212,175,55,0.4)] backdrop-blur transition hover:bg-[#D4AF37]/15 sm:right-6"
    >
      <Zap className="h-4 w-4 animate-pulse text-[#D4AF37]" />
      <span className="text-xs font-bold text-[#F3E5AB]">⚡ {meta.label}</span>
    </button>
  );
}

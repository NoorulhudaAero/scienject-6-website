import { useState } from "react";
import { Crown } from "lucide-react";

/**
 * Official SCIENJECT 6.0 logo slot.
 * Renders public/branding/scienject-logo.png — swap that file to rebrand every
 * slot (navbar + hero) at once. Falls back to the gold crown crest while the
 * PNG is unavailable so the layout never breaks.
 *
 * `animated` enables the futuristic hero treatment: a slow 3D coin-spin on the
 * crest, wrapped by two counter-rotating gold tech rings and a breathing halo.
 */
export function LogoMark({
  className = "h-9 w-9",
  fallbackClassName = "h-4 w-4",
  animated = false,
}: {
  className?: string;
  fallbackClassName?: string;
  animated?: boolean;
}) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className={`flex items-center justify-center rounded-md border border-[#D4AF37]/60 bg-gradient-to-br from-[#1a1405] to-[#0A0A0A] ${className}`}>
        <Crown className={`text-[#D4AF37] ${fallbackClassName}`} />
      </div>
    );
  }

  const img = (
    <img
      src="/branding/scienject-logo.png"
      alt="SCIENJECT 6.0 official logo"
      onError={() => setFailed(true)}
      className={`rounded-full object-cover drop-shadow-[0_0_14px_rgba(212,175,55,0.35)] ${
        animated ? "logo-coin-spin h-full w-full" : className
      }`}
      draggable={false}
    />
  );

  if (!animated) return img;

  return (
    <div className={`relative ${className}`} style={{ perspective: "900px" }}>
      {/* breathing gold halo */}
      <div
        aria-hidden
        className="logo-halo absolute -inset-4 rounded-full bg-[radial-gradient(circle,rgba(212,175,55,0.28)_0%,rgba(212,175,55,0.08)_45%,transparent_70%)]"
      />
      {/* outer dashed orbit ring */}
      <div
        aria-hidden
        className="logo-ring absolute -inset-2.5 rounded-full border border-dashed border-[#D4AF37]/50"
      />
      {/* inner counter-rotating arc ring */}
      <div
        aria-hidden
        className="logo-ring-reverse absolute -inset-1 rounded-full border-2 border-transparent [border-top-color:rgba(212,175,55,0.8)] [border-bottom-color:rgba(243,229,171,0.5)]"
      />
      {img}
    </div>
  );
}

import { trpc } from "@/providers/trpc";
import { Megaphone } from "lucide-react";

/** Thin metallic-gold live announcement marquee, fixed at the very top of every page. */
export function Ticker() {
  const { data } = trpc.public.ticker.useQuery(undefined, { refetchInterval: 10000 });
  const items = data && data.length > 0 ? data : ["✦ SCIENJECT 6.0 — Central Event Platform"];
  const line = items.join("   ✦   ");
  const loop = `${line}   ✦   `;

  return (
    <div className="fixed top-0 left-0 right-0 z-50 h-9 overflow-hidden border-b border-[#D4AF37]/40 bg-gradient-to-r from-[#100c02] via-[#1a1405] to-[#100c02] marquee-paused">
      <div className="flex h-full items-center">
        <div className="flex items-center gap-2 shrink-0 px-3 border-r border-[#D4AF37]/40 h-full bg-[#0A0A0A] z-10">
          <Megaphone className="h-3.5 w-3.5 text-[#D4AF37]" />
          <span className="font-display text-[10px] font-bold tracking-[0.25em] gold-text">LIVE</span>
        </div>
        <div className="relative flex-1 overflow-hidden h-full flex items-center">
          <div className="animate-marquee flex whitespace-nowrap">
            {[0, 1].map((i) => (
              <span key={i} className="text-xs tracking-wide text-[#F3E5AB] drop-shadow-[0_0_6px_rgba(212,175,55,0.5)] pr-2">
                {loop.repeat(3)}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

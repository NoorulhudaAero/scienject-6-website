import { useEffect, type ReactNode } from "react";
import { useNavigate } from "react-router";
import { ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/providers/trpc";
import { clearSession, getSession, type Role } from "@/lib/auth";

function FullScreenLoader({ label }: { label: string }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#0A0A0A]">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-[#D4AF37]/20 border-t-[#D4AF37]" />
      <span className="font-display text-xs uppercase tracking-[0.35em] text-[#C5A059]">{label}</span>
    </div>
  );
}

/**
 * Programmatic route guard — blocks unauthorized navigation.
 * Missing/expired token or wrong role → instant redirect to "/" with a permission error.
 */
export function RequireRole({ role, children }: { role: Role; children: ReactNode }) {
  const navigate = useNavigate();
  const session = getSession(role);

  const validation = trpc.auth.validate.useQuery(
    { token: session?.token ?? "" },
    { enabled: Boolean(session?.token), retry: false, staleTime: 60_000 },
  );

  const denied =
    !session ||
    (validation.isFetched &&
      (validation.isError ||
        validation.data?.role !== role ||
        (role === "director" && validation.data?.categoryId == null) ||
        (role === "department" && !validation.data?.departmentName)));

  useEffect(() => {
    if (denied) {
      clearSession(role);
      toast.error("Permission denied", {
        description: `You must sign in as ${
          role === "admin" ? "the Master Admin" : role === "director" ? "a Category Director" : "a Department Head"
        } to access that area.`,
        icon: <ShieldAlert className="h-4 w-4 text-[#D4AF37]" />,
      });
      navigate("/", { replace: true, state: { authError: true } });
    }
  }, [denied, navigate, role]);

  if (!session || validation.isLoading) return <FullScreenLoader label="Verifying Credentials" />;
  if (denied) return <FullScreenLoader label="Redirecting" />;
  return <>{children}</>;
}

import { Instagram, Mail } from "lucide-react";
import { CONTACTS } from "@contracts/categories";

/**
 * Permanent floating social badge — anchored to the right viewport edge,
 * vertically centered, always visible on public pages.
 */
export function SocialFloat() {
  return (
    <div className="fixed right-0 top-1/2 z-40 flex -translate-y-1/2 flex-col gap-1.5 rounded-l-xl border border-r-0 border-[#D4AF37]/50 bg-[#0A0A0A]/95 p-1.5 shadow-[0_0_24px_rgba(212,175,55,0.25)] backdrop-blur-md">
      <a
        href="https://instagram.com/scienject_6.0"
        target="_blank"
        rel="noreferrer"
        title={CONTACTS.instagram}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-[#D4AF37] transition hover:bg-[#D4AF37]/15 hover:text-[#F3E5AB]"
      >
        <Instagram className="h-4.5 w-4.5" />
      </a>
      <a
        href={`mailto:${CONTACTS.email}`}
        title={CONTACTS.email}
        className="flex h-9 w-9 items-center justify-center rounded-lg text-[#D4AF37] transition hover:bg-[#D4AF37]/15 hover:text-[#F3E5AB]"
      >
        <Mail className="h-4.5 w-4.5" />
      </a>
    </div>
  );
}

import { useEffect, useState } from "react";
import { Zap } from "lucide-react";
import { trpc } from "@/providers/trpc";

const DISMISS_KEY = "scienject_flash_dismissed";

/**
 * Urgent Flash Alert overlay — polls the backend at low latency and, the
 * moment the Master Admin emits an alert, overrides whatever public page the
 * delegate is viewing with a full-screen modal framed by a thick glowing gold
 * gradient border. Dismissal is per-device via the "Close Alert" control.
 */
export function FlashAlertOverlay() {
  const alert = trpc.public.activeFlashAlert.useQuery(undefined, {
    refetchInterval: 4000,
    refetchIntervalInBackground: true,
  });
  const [dismissedId, setDismissedId] = useState<number | null>(() => {
    const v = sessionStorage.getItem(DISMISS_KEY);
    return v ? Number(v) : null;
  });

  const active = alert.data && alert.data.id !== dismissedId ? alert.data : null;

  const dismiss = (id: number) => {
    sessionStorage.setItem(DISMISS_KEY, String(id));
    setDismissedId(id);
  };

  // Lock background scroll while the override is up
  useEffect(() => {
    if (!active) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [active]);

  if (!active) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 p-4 backdrop-blur-md sm:p-8"
      role="alertdialog"
      aria-modal="true"
      aria-label="Urgent Flash Alert"
    >
      <div className="relative w-full max-w-3xl rounded-3xl bg-gradient-to-br from-[#C5A059] via-[#F3E5AB] to-[#D4AF37] p-[5px] shadow-[0_0_90px_rgba(212,175,55,0.55)]">
        <div className="rounded-[calc(1.5rem-5px)] bg-[#0A0A0A] px-6 py-10 text-center sm:px-12 sm:py-14">
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full border-2 border-[#D4AF37] bg-[#D4AF37]/10 shadow-[0_0_30px_rgba(212,175,55,0.4)]">
            <Zap className="h-8 w-8 animate-pulse text-[#D4AF37]" />
          </div>
          <p className="font-display text-xs font-black uppercase tracking-[0.45em] text-[#D4AF37]">
            Urgent Flash Alert
          </p>
          <p className="mt-5 whitespace-normal break-words font-display text-xl font-bold leading-relaxed text-white sm:text-2xl">
            {active.text}
          </p>
          <p className="mt-5 font-mono2 text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
            SCIENJECT 6.0 · Master Admin Broadcast · {new Date(active.createdAt).toLocaleTimeString()}
          </p>
          <button
            onClick={() => dismiss(active.id)}
            className="mt-8 rounded-full bg-gradient-to-r from-[#C5A059] via-[#D4AF37] to-[#F3E5AB] px-10 py-3.5 font-display text-sm font-black uppercase tracking-[0.3em] text-black shadow-[0_0_30px_rgba(212,175,55,0.4)] transition hover:shadow-[0_0_48px_rgba(212,175,55,0.65)]"
          >
            Close Alert
          </button>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router";
import { Briefcase, Menu, Shield, Trophy, X } from "lucide-react";
import { getSession } from "@/lib/auth";
import { LogoMark } from "./LogoMark";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/delegates", label: "Delegate Hub" },
  { to: "/rankings", label: "Live Leaderboard" },
  { to: "/registration", label: "Registration" },
  { to: "/media", label: "Media" },
  { to: "/feedback", label: "Feedback" },
];

const PORTALS = [
  { to: "/director-dashboard", label: "Director Portal", icon: Shield },
  { to: "/department-dashboard", label: "Department Portal", icon: Briefcase },
  { to: "/admin", label: "Master Admin", icon: Trophy },
];

export function SiteHeader() {
  const navigate = useNavigate();
  const director = getSession("director");
  const department = getSession("department");
  const admin = getSession("admin");
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <>
      <header className="fixed top-9 left-0 right-0 z-40 border-b border-[#D4AF37]/25 bg-[#0A0A0A]/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5">
            {/* Dedicated high-contrast logo slot — swap public/branding/scienject-logo.png to rebrand */}
            <LogoMark className="h-10 w-10 rounded-md border border-[#D4AF37]/60 bg-gradient-to-br from-[#1a1405] to-[#0A0A0A] p-0.5" />
            <div className="leading-tight">
              <div className="font-display text-sm font-bold tracking-[0.2em] gold-text">SCIENJECT 6.0</div>
              <div className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground">Central Event Platform</div>
            </div>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {NAV.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `rounded-md px-3 py-1.5 text-sm transition-colors ${
                    isActive ? "bg-[#D4AF37]/10 text-[#F3E5AB]" : "text-muted-foreground hover:text-[#F3E5AB]"
                  }`
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            {director ? (
              <button
                onClick={() => navigate("/director-dashboard")}
                className="hidden sm:flex items-center gap-1.5 rounded-md border border-[#D4AF37]/40 px-2.5 py-1.5 text-xs text-[#F3E5AB] hover:bg-[#D4AF37]/10"
              >
                <Shield className="h-3.5 w-3.5" /> {director.categoryName} Desk
              </button>
            ) : (
              <Link
                to="/director-dashboard"
                className="hidden sm:flex items-center gap-1.5 rounded-md border border-[#D4AF37]/40 px-2.5 py-1.5 text-xs text-muted-foreground hover:text-[#F3E5AB] hover:bg-[#D4AF37]/10"
              >
                <Shield className="h-3.5 w-3.5" /> Director
              </Link>
            )}
            {department ? (
              <button
                onClick={() => navigate("/department-dashboard")}
                className="hidden md:flex items-center gap-1.5 rounded-md border border-[#D4AF37]/40 px-2.5 py-1.5 text-xs text-[#F3E5AB] hover:bg-[#D4AF37]/10"
              >
                <Briefcase className="h-3.5 w-3.5" /> {department.departmentName} Desk
              </button>
            ) : (
              <Link
                to="/department-dashboard"
                className="hidden md:flex items-center gap-1.5 rounded-md border border-[#D4AF37]/40 px-2.5 py-1.5 text-xs text-muted-foreground hover:text-[#F3E5AB] hover:bg-[#D4AF37]/10"
              >
                <Briefcase className="h-3.5 w-3.5" /> Department
              </Link>
            )}
            {admin ? (
              <button
                onClick={() => navigate("/admin")}
                className="flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-2.5 py-1.5 text-xs font-semibold text-black hover:opacity-90"
              >
                <Trophy className="h-3.5 w-3.5" /> Admin Desk
              </button>
            ) : (
              <Link
                to="/admin"
                className="hidden sm:flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-2.5 py-1.5 text-xs font-semibold text-black hover:opacity-90"
              >
                <Trophy className="h-3.5 w-3.5" /> Master Admin
              </Link>
            )}

            {/* Mobile access point — gold hamburger opens the portal drawer */}
            <button
              onClick={() => setDrawerOpen(true)}
              aria-label="Open navigation menu"
              className="flex h-9 w-9 items-center justify-center rounded-md border-2 border-[#D4AF37]/70 bg-[#D4AF37]/10 text-[#D4AF37] transition hover:bg-[#D4AF37]/20 lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>
      </header>

      {/* ── Mobile side-drawer: full nav + portal access points ─────────── */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setDrawerOpen(false)} />
          <aside className="absolute right-0 top-0 flex h-full w-72 flex-col border-l-2 border-[#D4AF37]/50 bg-[#0A0A0A] shadow-[0_0_40px_rgba(212,175,55,0.15)]">
            <div className="flex items-center justify-between border-b border-[#D4AF37]/25 px-5 py-4">
              <div className="flex items-center gap-2.5">
                <LogoMark className="h-9 w-9 rounded-md border border-[#D4AF37]/60 bg-gradient-to-br from-[#1a1405] to-[#0A0A0A] p-0.5" />
                <div className="font-display text-sm font-bold tracking-[0.2em] gold-text">SCIENJECT 6.0</div>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                aria-label="Close navigation menu"
                className="flex h-8 w-8 items-center justify-center rounded-md border border-[#D4AF37]/40 text-[#C5A059] hover:bg-[#D4AF37]/10"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <nav className="flex flex-col gap-1 px-3 py-4">
              {NAV.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  onClick={() => setDrawerOpen(false)}
                  className={({ isActive }) =>
                    `rounded-md px-3 py-2.5 text-sm font-medium transition-colors ${
                      isActive ? "bg-[#D4AF37]/15 text-[#F3E5AB]" : "text-muted-foreground hover:bg-[#D4AF37]/5 hover:text-[#F3E5AB]"
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>

            <div className="mt-2 border-t border-[#D4AF37]/25 px-3 py-4">
              <div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[0.25em] text-[#C5A059]">Portal Access</div>
              <div className="flex flex-col gap-1.5">
                {PORTALS.map((p) => {
                  const Icon = p.icon;
                  return (
                    <Link
                      key={p.to}
                      to={p.to}
                      onClick={() => setDrawerOpen(false)}
                      className="flex items-center gap-2.5 rounded-md border border-[#D4AF37]/40 px-3 py-2.5 text-sm font-semibold text-[#F3E5AB] transition hover:bg-[#D4AF37]/10"
                    >
                      <Icon className="h-4 w-4 text-[#D4AF37]" /> {p.label}
                    </Link>
                  );
                })}
              </div>
            </div>

            <div className="mt-auto border-t border-[#D4AF37]/25 px-5 py-4 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              Lahore Grammar School Gulberg 15C and 16C O/A Level Campus
            </div>
          </aside>
        </div>
      )}
    </>
  );
}

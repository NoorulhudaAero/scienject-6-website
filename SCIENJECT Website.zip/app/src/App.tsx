import { Routes, Route } from "react-router";
import { Toaster } from "sonner";
import Home from "./pages/Home";
import Delegates from "./pages/Delegates";
import Rankings from "./pages/Rankings";
import Registration from "./pages/Registration";
import Feedback from "./pages/Feedback";
import Media from "./pages/Media";
import DirectorDashboard from "./pages/DirectorDashboard";
import DepartmentDashboard from "./pages/DepartmentDashboard";
import Admin from "./pages/Admin";

export default function App() {
  return (
    <>
      <Toaster theme="dark" position="bottom-right" toastOptions={{ style: { background: "#121212", border: "1px solid rgba(212,175,55,0.4)", color: "#fff" } }} />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/delegates" element={<Delegates />} />
        <Route path="/rankings" element={<Rankings />} />
        <Route path="/registration" element={<Registration />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/media" element={<Media />} />
        <Route path="/director-dashboard" element={<DirectorDashboard />} />
        <Route path="/department-dashboard" element={<DepartmentDashboard />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </>
  );
}

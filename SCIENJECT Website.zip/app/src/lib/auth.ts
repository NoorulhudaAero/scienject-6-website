export type Role = "director" | "admin" | "department";

const KEYS: Record<Role, string> = {
  director: "scienject_director_session",
  admin: "scienject_admin_session",
  department: "scienject_department_session",
};

export interface StoredSession {
  token: string;
  role: Role;
  categorySlug?: string;
  categoryName?: string;
  departmentSlug?: string;
  departmentName?: string;
}

export function getSession(role: Role): StoredSession | null {
  try {
    const raw = localStorage.getItem(KEYS[role]);
    return raw ? (JSON.parse(raw) as StoredSession) : null;
  } catch {
    return null;
  }
}

export function saveSession(session: StoredSession) {
  localStorage.setItem(KEYS[session.role], JSON.stringify(session));
}

export function clearSession(role: Role) {
  localStorage.removeItem(KEYS[role]);
}

/** All currently stored staff sessions (tokens persist across public navigation). */
export function getAllSessions(): StoredSession[] {
  return (Object.keys(KEYS) as Role[])
    .map((r) => getSession(r))
    .filter((s): s is StoredSession => Boolean(s));
}

import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../api/router";

export type RouterOutputs = inferRouterOutputs<AppRouter>;
export type DirectorDashboardData = RouterOutputs["director"]["dashboard"];
export type LeaderboardData = RouterOutputs["public"]["leaderboard"];
export type AdminOverviewData = RouterOutputs["admin"]["overview"];

import { useState } from "react";
import { CheckCircle2, ClipboardList, Send, Star } from "lucide-react";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/providers/trpc";
import { CATEGORIES } from "@contracts/categories";

const ROLES = ["Delegate", "Team Leader", "Faculty Advisor", "Guest", "Judge"];

function RatingRow({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] px-4 py-3">
      <span className="text-sm font-medium text-white">{label}</span>
      <div className="flex gap-1.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n)}
            aria-label={`${label} ${n} of 5`}
            className="transition-transform hover:scale-110"
          >
            <Star
              className={`h-6 w-6 ${
                n <= value ? "fill-[#D4AF37] text-[#D4AF37] drop-shadow-[0_0_6px_rgba(212,175,55,0.5)]" : "text-white/20"
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-[#D4AF37]/30 bg-[#0A0A0A] px-4 py-2.5 text-sm text-white placeholder:text-muted-foreground focus:border-[#D4AF37] focus:outline-none";

export default function Feedback() {
  const [delegateName, setDelegateName] = useState("");
  const [school, setSchool] = useState("");
  const [role, setRole] = useState("Delegate");
  const [overall, setOverall] = useState(0);
  const [organization, setOrganization] = useState(0);
  const [venue, setVenue] = useState(0);
  const [judging, setJudging] = useState(0);
  const [favorite, setFavorite] = useState("");
  const [highlights, setHighlights] = useState("");
  const [improvements, setImprovements] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const submit = trpc.public.submitFeedback.useMutation({
    onSuccess: () => setSubmitted(true),
    onError: (e) => toast.error(e.message),
  });

  const valid =
    delegateName.trim().length > 0 && overall > 0 && organization > 0 && venue > 0 && judging > 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!valid) {
      toast.error("Please complete your name and all four rating fields.");
      return;
    }
    submit.mutate({
      delegateName: delegateName.trim(),
      school: school.trim() || undefined,
      role,
      overallRating: overall,
      organizationRating: organization,
      venueRating: venue,
      judgingRating: judging,
      favoriteCategory: favorite || undefined,
      highlights: highlights.trim() || undefined,
      improvements: improvements.trim() || undefined,
    });
  };

  return (
    <Layout>
      <section className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#121212]/80 px-4 py-1.5">
            <ClipboardList className="h-3.5 w-3.5 text-[#D4AF37]" />
            <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-[#F3E5AB]">
              Event Evaluation
            </span>
          </div>
          <h1 className="font-display text-4xl font-black tracking-wide sm:text-5xl">
            Delegate <span className="gold-text">Feedback</span>
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">
            Help the organizing council refine SCIENJECT. Your responses are recorded securely and reviewed
            exclusively by the Master Admin council.
          </p>
        </div>

        {submitted ? (
          <div className="gold-card rounded-2xl p-10 text-center">
            <CheckCircle2 className="mx-auto mb-4 h-14 w-14 text-[#D4AF37]" />
            <h2 className="font-display text-2xl font-bold text-white">
              Feedback <span className="gold-text">Recorded</span>
            </h2>
            <p className="mx-auto mt-3 max-w-md text-sm text-muted-foreground">
              Thank you — your evaluation has been securely logged with the organizing council.
            </p>
            <button
              onClick={() => {
                setSubmitted(false);
                setDelegateName(""); setSchool(""); setRole("Delegate");
                setOverall(0); setOrganization(0); setVenue(0); setJudging(0);
                setFavorite(""); setHighlights(""); setImprovements("");
              }}
              className="mt-6 rounded-full border border-[#D4AF37]/50 px-6 py-2 text-xs font-bold uppercase tracking-[0.2em] text-[#F3E5AB] transition hover:bg-[#D4AF37]/10"
            >
              Submit Another Response
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="gold-card space-y-6 rounded-2xl p-6 sm:p-8">
            {/* Identity */}
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  Full Name *
                </label>
                <input className={inputCls} value={delegateName} onChange={(e) => setDelegateName(e.target.value)} placeholder="Your name" maxLength={255} />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  School Institution
                </label>
                <input className={inputCls} value={school} onChange={(e) => setSchool(e.target.value)} placeholder="Your campus / institution" maxLength={255} />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  Your Role
                </label>
                <Select value={role} onValueChange={setRole}>
                  <SelectTrigger className="border-[#D4AF37]/30 bg-[#0A0A0A] text-white focus:ring-[#D4AF37]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
                    {ROLES.map((r) => (
                      <SelectItem key={r} value={r} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  Favourite Category
                </label>
                <Select value={favorite} onValueChange={setFavorite}>
                  <SelectTrigger className="border-[#D4AF37]/30 bg-[#0A0A0A] text-white focus:ring-[#D4AF37]">
                    <SelectValue placeholder="Optional" />
                  </SelectTrigger>
                  <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c.slug} value={c.name} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Ratings */}
            <div className="space-y-3">
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">Rate Your Experience *</p>
              <RatingRow label="Overall Event Experience" value={overall} onChange={setOverall} />
              <RatingRow label="Organization & Scheduling" value={organization} onChange={setOrganization} />
              <RatingRow label="Venue & Campus Facilities" value={venue} onChange={setVenue} />
              <RatingRow label="Judging Quality & Fairness" value={judging} onChange={setJudging} />
            </div>

            {/* Free text */}
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  Highlights — what did you love?
                </label>
                <textarea className={`${inputCls} min-h-[90px] resize-y`} value={highlights} onChange={(e) => setHighlights(e.target.value)} maxLength={4000} />
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  Improvements — what should we refine?
                </label>
                <textarea className={`${inputCls} min-h-[90px] resize-y`} value={improvements} onChange={(e) => setImprovements(e.target.value)} maxLength={4000} />
              </div>
            </div>

            <button
              type="submit"
              disabled={submit.isPending}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#C5A059] via-[#D4AF37] to-[#F3E5AB] py-3.5 font-display text-sm font-black uppercase tracking-[0.25em] text-black shadow-[0_0_30px_rgba(212,175,55,0.3)] transition hover:shadow-[0_0_44px_rgba(212,175,55,0.5)] disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              {submit.isPending ? "Submitting…" : "Submit Feedback"}
            </button>
          </form>
        )}
      </section>
    </Layout>
  );
}

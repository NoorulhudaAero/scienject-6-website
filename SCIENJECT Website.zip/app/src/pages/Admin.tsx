import { useMemo, useState } from "react";
import { useNavigate } from "react-router";
import {
  AlertTriangle, Building2, CalendarClock, ChevronDown, ChevronUp, Crown, FileUp, Hexagon, KeyRound, LogOut, MapPin, Megaphone, MessageSquareText, Pencil, Plus,
  Radio, RotateCcw, Save, Square, Star, Timer, Trash2, X, Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { RequireRole } from "@/components/guards";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { trpc } from "@/providers/trpc";
import { clearSession, getSession, saveSession, type StoredSession } from "@/lib/auth";
import { CATEGORIES, VENUE_BRANCHES, VENUE_FLOORS } from "@contracts/categories";
import { useNow } from "@/components/Countdown";
import type { AdminOverviewData } from "@/types/api";

const inputCls =
  "w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]";
const monoInputCls =
  "w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 font-mono2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]";
const goldBtn =
  "rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-4 py-2 text-xs font-bold text-black hover:opacity-90 disabled:opacity-40";
const labelCls = "mb-1 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]";

/**
 * Rolling evaluation-clock cell for the Global Overview grid. Ticks every second
 * and reports the precise remaining minutes:seconds of the active evaluation
 * timer only — the launch-day countdown can never leak into this slot.
 */
function EvalClockCell({ endsAt, round }: { endsAt: string | Date | null; round: number | null }) {
  const now = useNow(1000);
  if (!endsAt) return <span className="font-mono2 text-muted-foreground">—</span>;
  const ms = new Date(endsAt).getTime() - now;
  if (ms <= 0) return <span className="font-mono2 text-muted-foreground">—</span>;
  const total = Math.floor(ms / 1000);
  const hh = Math.floor(total / 3600);
  const mm = Math.floor((total % 3600) / 60);
  const ss = total % 60;
  const stamp = hh > 0 ? `${hh}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}` : `${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
  return (
    <span className="font-mono2 font-bold text-[#F3E5AB]">
      R{round ?? "?"} · {stamp} left
    </span>
  );
}

/* ──────────────────────────── AUTH GATE ──────────────────────────── */

function AdminGate() {
  const navigate = useNavigate();
  const [key, setKey] = useState("");
  const login = trpc.auth.loginAdmin.useMutation({
    onSuccess: (data) => {
      saveSession({ token: data.token, role: "admin" });
      toast.success("Master Admin authenticated — welcome back");
      navigate(0);
    },
    onError: (e) => toast.error("Access denied", { description: e.message }),
  });

  return (
    <div className="mx-auto max-w-md px-4 py-20">
      <div className="gold-card rounded-2xl p-8">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-[#D4AF37]/50 bg-[#D4AF37]/10">
            <Crown className="h-7 w-7 text-[#D4AF37]" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-wide">
            Welcome to the <span className="gold-text">Master Admin Portal</span>
          </h1>
          <p className="mt-2 text-xs text-muted-foreground">
            Executive control panel. Enter the Master Admin Secret Key to oversee all 13 categories.
          </p>
        </div>
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (key) login.mutate({ masterKey: key });
          }}
        >
          <div className="relative">
            <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#C5A059]" />
            <input
              type="password"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="Master Admin Secret Key"
              className="w-full rounded-md border border-[#D4AF37]/40 bg-[#0A0A0A] py-2.5 pl-10 pr-3 font-mono2 text-sm text-white placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
            />
          </div>
          <button type="submit" disabled={login.isPending || !key} className={`w-full ${goldBtn} py-3 text-sm`}>
            {login.isPending ? "Verifying…" : "Access Portal"}
          </button>
        </form>
      </div>
    </div>
  );
}

/* ───────────────────────── SCORE OVERRIDE ────────────────────────── */

function ScoreOverride({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const [slug, setSlug] = useState(CATEGORIES[0].slug);
  const [round, setRound] = useState(1);
  const board = trpc.admin.categoryBoard.useQuery({ token: session.token, categorySlug: slug, round });
  const [edit, setEdit] = useState<{ teamId: number; criteriaId: number; value: string } | null>(null);

  const saveCell = trpc.admin.upsertScores.useMutation({
    onSuccess: () => {
      toast.success("Score overridden");
      setEdit(null);
      utils.admin.categoryBoard.invalidate();
      utils.admin.overview.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const cells = useMemo(() => board.data?.criteria ?? [], [board.data]);

  return (
    <div className="gold-card rounded-xl p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
          <Pencil className="h-4 w-4 text-[#D4AF37]" /> Data Override Console
        </h3>
        <div className="flex gap-2">
          <select value={slug} onChange={(e) => setSlug(e.target.value)} className={inputCls.replace("w-full", "") + " px-3 py-1.5"}>
            {CATEGORIES.map((c) => (
              <option key={c.slug} value={c.slug}>{c.name}</option>
            ))}
          </select>
          <select value={round} onChange={(e) => setRound(Number(e.target.value))} className={monoInputCls.replace("w-full", "") + " px-3 py-1.5"}>
            {[1, 2, 3].map((r) => (
              <option key={r} value={r}>Round {r}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="max-h-96 overflow-auto rounded-lg border border-[#D4AF37]/15">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-[#121212]">
            <tr className="border-b border-[#D4AF37]/20 text-left">
              <th className="px-4 py-2.5 font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Team</th>
              {cells.map((c) => (
                <th key={c.id} className="px-3 py-2.5 text-center font-display text-xs uppercase tracking-[0.1em] text-[#C5A059]">
                  {c.name}
                </th>
              ))}
              <th className="px-4 py-2.5 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Total</th>
            </tr>
          </thead>
          <tbody>
            {board.data?.teams.map((t) => (
              <tr key={t.id} className="border-b border-[#D4AF37]/10 hover:bg-[#D4AF37]/5">
                <td className="px-4 py-2 font-medium text-white">{t.name}</td>
                {cells.map((c) => {
                  const editing = edit?.teamId === t.id && edit?.criteriaId === c.id;
                  return (
                    <td key={c.id} className="px-3 py-2 text-center">
                      {editing ? (
                        <span className="inline-flex items-center gap-1">
                          <input
                            autoFocus
                            type="number"
                            value={edit.value}
                            min={0}
                            max={c.maxPoints}
                            onChange={(e) => setEdit({ ...edit, value: e.target.value })}
                            onKeyDown={(e) => {
                              if (e.key === "Enter")
                                saveCell.mutate({ token: session.token, categorySlug: slug, round, entries: [{ teamId: t.id, criteriaId: c.id, value: Number(edit.value) || 0 }] });
                              if (e.key === "Escape") setEdit(null);
                            }}
                            className="w-16 rounded border border-[#D4AF37] bg-[#0A0A0A] px-1.5 py-1 text-center font-mono2 text-xs text-[#F3E5AB] focus:outline-none"
                          />
                          <button
                            onClick={() =>
                              saveCell.mutate({ token: session.token, categorySlug: slug, round, entries: [{ teamId: t.id, criteriaId: c.id, value: Number(edit.value) || 0 }] })
                            }
                            className="text-[#D4AF37] hover:text-[#F3E5AB]"
                          >
                            <Save className="h-3.5 w-3.5" />
                          </button>
                          <button onClick={() => setEdit(null)} className="text-muted-foreground hover:text-red-400">
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </span>
                      ) : (
                        <button
                          onClick={() => setEdit({ teamId: t.id, criteriaId: c.id, value: String(t.scores[c.id] ?? 0) })}
                          className="rounded px-2 py-1 font-mono2 text-xs text-[#F3E5AB] hover:bg-[#D4AF37]/15 hover:text-[#F3E5AB]"
                          title="Click to override"
                        >
                          {t.scores[c.id] ?? 0}
                        </button>
                      )}
                    </td>
                  );
                })}
                <td className="px-4 py-2 text-center font-mono2 text-sm font-bold gold-text">{t.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ─────────────────────────── CSV UPLOAD ──────────────────────────── */

function CsvUpload({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const [csv, setCsv] = useState("");
  const upload = trpc.admin.csvUpload.useMutation({
    onSuccess: (r) => {
      toast.success(
        `Roster ingested — ${r.membersInserted} member${r.membersInserted === 1 ? "" : "s"} registered across ${r.teamsCreated} new team${r.teamsCreated === 1 ? "" : "s"}${
          r.warnings.length ? ` · ${r.warnings.length} warning${r.warnings.length === 1 ? "" : "s"}` : ""
        }`,
      );
      r.warnings.forEach((w) => toast.warning(w));
      setCsv("");
      utils.admin.overview.invalidate();
    },
    onError: (e) => toast.error("Import failed", { description: e.message }),
  });

  const loadFile = (file: File | undefined) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setCsv(String(reader.result ?? ""));
    reader.readAsText(file);
  };

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <FileUp className="h-4 w-4 text-[#D4AF37]" /> Bulk Member Roster Uploader
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        One <span className="font-semibold text-[#F3E5AB]">individual member</span> per row, exactly four columns:{" "}
        <span className="font-mono2 text-[#F3E5AB]">Team Name, School Institution, Member Name, Categories</span>
      </p>
      <p className="mt-1 text-xs text-muted-foreground">
        The Categories cell accepts comma-separated lists (e.g.{" "}
        <span className="font-mono2 text-[#F3E5AB]">Avionix, Pitchcraft, Equinox</span>) — the parser splits them and
        cross-populates the member into every listed category's director dashboard.
      </p>
      <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed border-[#D4AF37]/40 bg-[#0A0A0A] px-3 py-2.5 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/10">
        <FileUp className="h-3.5 w-3.5" /> Load .csv / .txt / .tsv file
        <input type="file" accept=".csv,.txt,.tsv,text/csv,text/plain" className="hidden" onChange={(e) => loadFile(e.target.files?.[0])} />
      </label>
      <textarea
        value={csv}
        onChange={(e) => setCsv(e.target.value)}
        rows={6}
        placeholder={
          "Team Name, School Institution, Member Name, Categories\nQuantum Quizzers, LGS Gulberg, Ayaan Raza, Avionix, Pitchcraft\nQuantum Quizzers, LGS Gulberg, Hira Shah, Equinox\nStellar Minds, Aitchison College, Daniyal Khan, Avionix"
        }
        className={`${monoInputCls} mt-2 text-xs placeholder:text-muted-foreground/50`}
      />
      <button
        onClick={() => csv.trim() && upload.mutate({ token: session.token, csvText: csv })}
        disabled={upload.isPending || !csv.trim()}
        className={`${goldBtn} mt-2 w-full`}
      >
        {upload.isPending ? "Ingesting rows…" : "Ingest Member Rows"}
      </button>
    </div>
  );
}

/* ───────────────────────── TICKER CONTROLLER ─────────────────────── */

function TickerController({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const [text, setText] = useState("");
  const list = trpc.admin.listAnnouncements.useQuery({ token: session.token });

  const invalidateAll = () => {
    utils.admin.listAnnouncements.invalidate();
    utils.public.ticker.invalidate();
  };
  const setTicker = trpc.admin.setTicker.useMutation({
    onSuccess: () => { toast.success("Ticker overwritten — now live on all public pages"); setText(""); invalidateAll(); },
    onError: (e) => toast.error(e.message),
  });
  const add = trpc.admin.addAnnouncement.useMutation({
    onSuccess: () => { toast.success("Announcement added to ticker rotation"); setText(""); invalidateAll(); },
    onError: (e) => toast.error(e.message),
  });
  const remove = trpc.admin.removeAnnouncement.useMutation({ onSuccess: invalidateAll, onError: (e) => toast.error(e.message) });

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <Megaphone className="h-4 w-4 text-[#D4AF37]" /> Ticker Controller
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">Overwrite or append to the live marquee on every public page.</p>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={2}
        placeholder="📢 Avionix Round 1 results are now LIVE!"
        className={`${inputCls} mt-3 placeholder:text-muted-foreground/50`}
      />
      <div className="mt-2 flex gap-2">
        <button onClick={() => text.trim() && setTicker.mutate({ token: session.token, text: text.trim() })} className={`${goldBtn} flex-1`}>
          Overwrite Ticker
        </button>
        <button
          onClick={() => text.trim() && add.mutate({ token: session.token, text: text.trim() })}
          className="flex-1 rounded-md border border-[#D4AF37]/40 py-2 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/10"
        >
          Add to Rotation
        </button>
      </div>
      <div className="mt-4 max-h-44 space-y-1.5 overflow-y-auto pr-1">
        {list.data?.map((a) => (
          <div
            key={a.id}
            className={`flex items-start justify-between gap-2 rounded-md border px-3 py-2 text-xs ${
              a.active ? "border-[#D4AF37]/30 bg-[#0A0A0A] text-white" : "border-white/5 bg-[#0A0A0A] text-muted-foreground line-through"
            }`}
          >
            <span>{a.text}</span>
            <button onClick={() => remove.mutate({ token: session.token, id: a.id })} className="shrink-0 text-muted-foreground hover:text-red-400">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─────────────── CATEGORY CONTROL (venue · runtime · live) ───────── */

function CategoryControl({ session, overview }: { session: StoredSession; overview: AdminOverviewData | undefined }) {
  const utils = trpc.useUtils();
  const [slug, setSlug] = useState(CATEGORIES[0].slug);
  const cat = overview?.find((c) => c.slug === slug);

  const [form, setForm] = useState<{ name?: string; room?: string; venue?: string; tagline?: string; activeRound?: string }>({});
  const [minutes, setMinutes] = useState("60");

  const invalidate = () => utils.admin.overview.invalidate();
  const update = trpc.admin.updateCategory.useMutation({
    onSuccess: () => { toast.success("Category updated"); setForm({}); invalidate(); utils.public.categories.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const setTimer = trpc.admin.setEvaluationTimer.useMutation({
    onSuccess: () => { toast.success("Evaluation clock updated"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const haltTimer = trpc.admin.haltEvaluationTimer.useMutation({
    onSuccess: () => { toast.success("Evaluation clock halted"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const timerActive = Boolean(cat?.evalTimerEndsAt && new Date(cat.evalTimerEndsAt).getTime() > Date.now());

  return (
    <div className="gold-card rounded-xl p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
          <Building2 className="h-4 w-4 text-[#D4AF37]" /> Category & Venue Control
        </h3>
        <select value={slug} onChange={(e) => { setSlug(e.target.value); setForm({}); }} className={inputCls.replace("w-full", "") + " px-3 py-1.5"}>
          {CATEGORIES.map((c) => (
            <option key={c.slug} value={c.slug}>{c.name}</option>
          ))}
        </select>
      </div>

      {cat && (
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-3">
            <div>
              <label className={labelCls}>Category Name</label>
              <input value={form.name ?? cat.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className={labelCls}>Room</label>
                <input value={form.room ?? cat.room} onChange={(e) => setForm({ ...form, room: e.target.value })} className={inputCls} />
              </div>
              <div>
                <label className={labelCls}>Venue (Branch · Floor)</label>
                <input value={form.venue ?? cat.venue} onChange={(e) => setForm({ ...form, venue: e.target.value })} className={inputCls} />
              </div>
            </div>
            <div>
              <label className={labelCls}>Tagline / Runtime Description</label>
              <input value={form.tagline ?? cat.tagline} onChange={(e) => setForm({ ...form, tagline: e.target.value })} className={inputCls} />
            </div>
            <div>
              <label className={labelCls}>Active Round</label>
              <select
                value={form.activeRound ?? String(cat.activeRound)}
                onChange={(e) => setForm({ ...form, activeRound: e.target.value })}
                className={monoInputCls}
              >
                {[1, 2, 3].map((r) => (
                  <option key={r} value={r}>Round {r}</option>
                ))}
              </select>
            </div>
            <button
              onClick={() =>
                update.mutate({
                  token: session.token,
                  categorySlug: slug,
                  name: form.name ?? cat.name,
                  room: form.room ?? cat.room,
                  venue: form.venue ?? cat.venue,
                  tagline: form.tagline ?? cat.tagline,
                  activeRound: Number(form.activeRound ?? cat.activeRound),
                })
              }
              className={`${goldBtn} w-full`}
            >
              Save Category Parameters
            </button>
          </div>

          <div className="space-y-4">
            {/* Live Now switchboard */}
            <div className="flex items-center justify-between rounded-lg border border-[#D4AF37]/25 bg-[#0A0A0A] p-4">
              <div>
                <div className="flex items-center gap-2 text-sm font-bold text-white">
                  <Radio className="h-4 w-4 text-[#D4AF37]" /> "Live Now" Status
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  When on, this category populates the live status marquee on the home page.
                </p>
              </div>
              <Switch
                checked={cat.isLiveNow}
                onCheckedChange={(v) => update.mutate({ token: session.token, categorySlug: slug, isLiveNow: v })}
                className="data-[state=checked]:bg-[#D4AF37]"
              />
            </div>

            {/* Master timer control */}
            <div className="rounded-lg border border-[#D4AF37]/25 bg-[#0A0A0A] p-4">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Timer className="h-4 w-4 text-[#D4AF37]" /> Evaluation Clock Override
              </div>
              {timerActive && cat.evalTimerEndsAt && (
                <p className="mt-1.5 font-mono2 text-xs text-[#F3E5AB]">
                  Running · Round {cat.evalTimerRound} · ends {new Date(cat.evalTimerEndsAt).toLocaleString()}
                </p>
              )}
              <div className="mt-3 flex gap-2">
                <input type="number" min={1} value={minutes} onChange={(e) => setMinutes(e.target.value)} className={`${monoInputCls} w-24`} placeholder="Mins" />
                <select value={form.activeRound ?? String(cat.activeRound)} disabled className={`${monoInputCls} flex-1 opacity-60`}>
                  <option>Round {form.activeRound ?? cat.activeRound}</option>
                </select>
                <button
                  onClick={() => setTimer.mutate({ token: session.token, categorySlug: slug, round: Number(form.activeRound ?? cat.activeRound), minutes: Number(minutes) || 60 })}
                  className={goldBtn}
                >
                  Set
                </button>
                {timerActive && (
                  <button
                    onClick={() => haltTimer.mutate({ token: session.token, categorySlug: slug })}
                    className="flex items-center gap-1 rounded-md border border-red-500/40 px-3 py-2 text-xs font-semibold text-red-400 hover:bg-red-500/10"
                  >
                    <Square className="h-3 w-3" /> Halt
                  </button>
                )}
              </div>
              <p className="mt-2 text-[10px] text-muted-foreground">
                Master Admin retains global override of any director-started evaluation clock.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─────────────────── VENUE ROOM ALLOCATION MAPPING ────────────────── */

interface VenueEdit {
  room: string; // custom allocation input — any room/lab code
  branch: string; // VENUE_BRANCHES label
  area: string; // floor — one of the five hardcoded VENUE_FLOORS selections
}

/** Legacy building-block strings collapse onto the strict floor matrix. */
function legacyAreaToFloor(area: string): string {
  const a = area.toLowerCase();
  if (a.includes("courtyard")) return "Courtyard/Open Area";
  if (a.includes("auditorium")) return "Auditorium";
  return VENUE_FLOORS[0];
}

function parseVenue(current: { room: string; venue: string }): VenueEdit {
  const [branch, area] = current.venue.split("·").map((s) => s.trim());
  const knownBranch = VENUE_BRANCHES.find((b) => b.label === branch);
  const rawArea = area || VENUE_FLOORS[0];
  return {
    room: current.room,
    branch: knownBranch ? knownBranch.label : VENUE_BRANCHES[0].label,
    area: (VENUE_FLOORS as readonly string[]).includes(rawArea) ? rawArea : legacyAreaToFloor(rawArea),
  };
}

function VenueMapEditor({ session, overview }: { session: StoredSession; overview: AdminOverviewData | undefined }) {
  const utils = trpc.useUtils();
  const [edits, setEdits] = useState<Record<string, VenueEdit>>({});

  const update = trpc.admin.updateCategory.useMutation({
    onSuccess: (_d, vars) => {
      toast.success("Room allocation updated — live on the Delegate Hub");
      setEdits((e) => {
        const next = { ...e };
        delete next[vars.categorySlug];
        return next;
      });
      utils.admin.overview.invalidate();
      utils.public.categories.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const valueFor = (slug: string, current: { room: string; venue: string }): VenueEdit => edits[slug] ?? parseVenue(current);

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <MapPin className="h-4 w-4 text-[#D4AF37]" /> Venue Room Allocation Map
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Bind every category to a campus branch (16C A-Levels / 15C O-Levels) and one of the five hardcoded floor
        selections — 1st Floor, 2nd Floor, 3rd Floor, Courtyard/Open Area or Auditorium — plus a custom room/lab
        allocation code. Saves override the old strings instantly and project straight onto the public Delegate Hub.
      </p>

      <div className="mt-4 space-y-2">
        <div className="hidden grid-cols-[150px_170px_170px_1fr_90px] gap-2 px-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#C5A059] lg:grid">
          <span>Category</span><span>Campus Branch</span><span>Floor</span><span>Room / Lab Code (Custom)</span><span />
        </div>
        {overview?.map((c) => {
          const v = valueFor(c.slug, c);
          const dirty = Boolean(edits[c.slug]);
          const branch = VENUE_BRANCHES.find((b) => b.label === v.branch) ?? VENUE_BRANCHES[0];
          return (
            <div
              key={c.id}
              className={`grid items-center gap-2 rounded-lg border p-2 lg:grid-cols-[150px_170px_170px_1fr_90px] ${
                dirty ? "border-[#D4AF37]/60 bg-[#D4AF37]/5" : "border-[#D4AF37]/15 bg-[#0A0A0A]"
              }`}
            >
              <span className="text-sm font-semibold text-white">{c.name}</span>
              <select
                value={v.branch}
                onChange={(e) => {
                  const nextBranch = VENUE_BRANCHES.find((b) => b.label === e.target.value) ?? VENUE_BRANCHES[0];
                  setEdits((x) => ({ ...x, [c.slug]: { ...v, branch: nextBranch.label, area: nextBranch.areas[0] } }));
                }}
                className="rounded border border-[#D4AF37]/20 bg-[#0A0A0A] px-2 py-1.5 text-xs text-[#F3E5AB] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
              >
                {VENUE_BRANCHES.map((b) => (
                  <option key={b.label} value={b.label}>{b.label}</option>
                ))}
              </select>
              <select
                value={v.area}
                onChange={(e) => setEdits((x) => ({ ...x, [c.slug]: { ...v, area: e.target.value } }))}
                className="rounded border border-[#D4AF37]/20 bg-[#0A0A0A] px-2 py-1.5 text-xs text-[#F3E5AB] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
              >
                {branch.areas.map((a) => (
                  <option key={a} value={a}>{a}</option>
                ))}
                {!branch.areas.includes(v.area as never) && <option value={v.area}>{v.area}</option>}
              </select>
              <input
                value={v.room}
                onChange={(e) => setEdits((x) => ({ ...x, [c.slug]: { ...v, room: e.target.value } }))}
                placeholder="e.g. Room 204 / Dome Entrance"
                className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
              />
              <button
                onClick={() =>
                  update.mutate({
                    token: session.token,
                    categorySlug: c.slug,
                    room: v.room,
                    venue: `${v.branch} · ${v.area}`,
                  })
                }
                disabled={!dirty || update.isPending}
                className={`${goldBtn} flex items-center justify-center gap-1 px-2 py-1.5`}
              >
                <Save className="h-3 w-3" /> Save
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─────────────────────── STUDY GUIDE MANAGER ─────────────────────── */

function StudyGuideManager({ session, overview }: { session: StoredSession; overview: AdminOverviewData | undefined }) {
  const utils = trpc.useUtils();
  const [slug, setSlug] = useState(CATEGORIES[0].slug);
  const cat = overview?.find((c) => c.slug === slug);

  const refresh = () => {
    utils.admin.overview.invalidate();
    utils.public.categories.invalidate();
  };
  const upload = trpc.admin.uploadStudyGuide.useMutation({
    onSuccess: () => { toast.success('Study guide uploaded — the public card now reads "Download Guide"'); refresh(); },
    onError: (e) => toast.error("Upload failed", { description: e.message }),
  });
  const remove = trpc.admin.removeStudyGuide.useMutation({
    onSuccess: () => { toast.success("Study guide removed — card back to Coming Soon"); refresh(); },
    onError: (e) => toast.error(e.message),
  });

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    if (file.type !== "application/pdf") { toast.error("Only PDF files are accepted"); return; }
    if (file.size > 20 * 1024 * 1024) { toast.error("PDF exceeds the 20 MB limit"); return; }
    const reader = new FileReader();
    reader.onload = () => {
      const dataBase64 = String(reader.result).split(",")[1] ?? "";
      upload.mutate({ token: session.token, categorySlug: slug, dataBase64 });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <FileUp className="h-4 w-4 text-[#D4AF37]" /> Study Guide PDF Pipeline
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Upload a category's official guide — it binds to that category card on the public pages and flips the button
        from "Coming Soon" to "Download Guide" instantly.
      </p>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <select value={slug} onChange={(e) => setSlug(e.target.value)} className={inputCls.replace("w-full", "") + " px-3 py-1.5"}>
          {CATEGORIES.map((c) => (
            <option key={c.slug} value={c.slug}>{c.name}</option>
          ))}
        </select>
        <span
          className={`rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-[0.15em] ${
            cat?.hasStudyGuide ? "border-[#D4AF37]/60 bg-[#D4AF37]/12 text-[#F3E5AB]" : "border-white/15 text-muted-foreground"
          }`}
        >
          {cat?.hasStudyGuide ? "● Guide Live" : "Coming Soon"}
        </span>
        <label className={`${goldBtn} flex cursor-pointer items-center gap-1.5`}>
          <FileUp className="h-3.5 w-3.5" /> {upload.isPending ? "Uploading…" : cat?.hasStudyGuide ? "Replace PDF" : "Upload Study Guide PDF"}
          <input type="file" accept="application/pdf" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
        </label>
        {cat?.hasStudyGuide && (
          <button
            onClick={() => remove.mutate({ token: session.token, categorySlug: slug })}
            disabled={remove.isPending}
            className="flex items-center gap-1 rounded-md border border-red-500/40 px-3 py-2 text-xs font-semibold text-red-400 hover:bg-red-500/10"
          >
            <Trash2 className="h-3.5 w-3.5" /> Remove
          </button>
        )}
      </div>
      <div className="mt-4 grid max-h-40 grid-cols-2 gap-1.5 overflow-y-auto sm:grid-cols-3 lg:grid-cols-4">
        {overview?.map((c) => (
          <button
            key={c.slug}
            onClick={() => setSlug(c.slug)}
            className={`rounded-md border px-2 py-1.5 text-left text-[11px] transition ${
              c.slug === slug ? "border-[#D4AF37] bg-[#D4AF37]/10 text-[#F3E5AB]" : "border-[#D4AF37]/15 text-white/80 hover:border-[#D4AF37]/40"
            }`}
          >
            {c.name} {c.hasStudyGuide ? "📄" : ""}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ─────────────────────── LIVE SWITCHBOARD GRID ───────────────────── */

function LiveSwitchboard({ session, overview }: { session: StoredSession; overview: AdminOverviewData | undefined }) {
  const utils = trpc.useUtils();
  const update = trpc.admin.updateCategory.useMutation({
    onSuccess: () => { utils.admin.overview.invalidate(); utils.public.categories.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <Radio className="h-4 w-4 text-[#D4AF37]" /> Live Switchboard
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Toggle whether a category is "Live Now" on campus. Active categories populate the home page status card.
      </p>
      <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {overview?.map((c) => (
          <div key={c.id} className="flex items-center justify-between rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] px-3 py-2.5">
            <div>
              <div className="text-sm font-semibold text-white">{c.name}</div>
              <div className={`text-[10px] font-bold uppercase tracking-[0.2em] ${c.isLiveNow ? "text-[#D4AF37]" : "text-muted-foreground"}`}>
                {c.isLiveNow ? "● Live Now" : "Inactive"}
              </div>
            </div>
            <Switch
              checked={c.isLiveNow}
              onCheckedChange={(v) => update.mutate({ token: session.token, categorySlug: c.slug, isLiveNow: v })}
              className="data-[state=checked]:bg-[#D4AF37]"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

/* ────────────────────────── SCHEDULE EDITOR ──────────────────────── */

function ScheduleEditor({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const items = trpc.admin.listSchedule.useQuery({ token: session.token });
  const [newItem, setNewItem] = useState({ dayLabel: "Oct 2", timeLabel: "", title: "", venue: "" });

  const invalidate = () => {
    utils.admin.listSchedule.invalidate();
    utils.public.schedule.invalidate();
  };
  const add = trpc.admin.addScheduleItem.useMutation({
    onSuccess: () => { toast.success("Time slot appended to the master timeline"); setNewItem({ dayLabel: "Oct 2", timeLabel: "", title: "", venue: "" }); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const updateItem = trpc.admin.updateScheduleItem.useMutation({ onSuccess: invalidate, onError: (e) => toast.error(e.message) });
  const move = trpc.admin.moveScheduleItem.useMutation({ onSuccess: invalidate, onError: (e) => toast.error(e.message) });
  const remove = trpc.admin.removeScheduleItem.useMutation({
    onSuccess: () => { toast.success("Schedule item removed"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const rowCls = "grid grid-cols-[auto_64px_72px_1fr_1fr_auto] items-center gap-2 rounded-lg border border-[#D4AF37]/15 bg-[#0A0A0A] p-2";

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <CalendarClock className="h-4 w-4 text-[#D4AF37]" /> Master Timeline Editor
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Edits publish instantly to the home page and Delegate Hub. New slots are auto-sequenced into perfect
        chronological order by their Date + Time values the moment they are appended — no manual dragging required.
      </p>

      <div className="mt-4 space-y-2">
        {items.data?.map((item, idx) => (
          <div key={item.id} className={rowCls}>
            <div className="flex flex-col">
              <button
                onClick={() => move.mutate({ token: session.token, id: item.id, direction: "up" })}
                disabled={idx === 0 || move.isPending}
                className="text-[#D4AF37] transition hover:text-[#F3E5AB] disabled:opacity-20"
                title="Move up"
              >
                <ChevronUp className="h-4 w-4" />
              </button>
              <button
                onClick={() => move.mutate({ token: session.token, id: item.id, direction: "down" })}
                disabled={idx === (items.data?.length ?? 0) - 1 || move.isPending}
                className="text-[#D4AF37] transition hover:text-[#F3E5AB] disabled:opacity-20"
                title="Move down"
              >
                <ChevronDown className="h-4 w-4" />
              </button>
            </div>
            <input
              defaultValue={item.dayLabel}
              onBlur={(e) => e.target.value !== item.dayLabel && updateItem.mutate({ token: session.token, id: item.id, dayLabel: e.target.value })}
              className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 font-mono2 text-xs text-[#F3E5AB] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
            <input
              defaultValue={item.timeLabel}
              onBlur={(e) => e.target.value !== item.timeLabel && updateItem.mutate({ token: session.token, id: item.id, timeLabel: e.target.value })}
              className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 font-mono2 text-xs text-[#F3E5AB] focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
            <input
              defaultValue={item.title}
              onBlur={(e) => e.target.value !== item.title && updateItem.mutate({ token: session.token, id: item.id, title: e.target.value })}
              className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 text-xs text-white focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
            <input
              defaultValue={item.venue}
              onBlur={(e) => e.target.value !== item.venue && updateItem.mutate({ token: session.token, id: item.id, venue: e.target.value })}
              className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 text-xs text-white/80 focus:outline-none focus:ring-1 focus:ring-[#D4AF37]"
            />
            <button onClick={() => remove.mutate({ token: session.token, id: item.id })} className="px-2 text-muted-foreground hover:text-red-400">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Append a fresh timeline entity on the fly */}
      <div className="mt-4 rounded-lg border border-dashed border-[#D4AF37]/40 bg-[#0A0A0A] p-3">
        <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.25em] text-[#C5A059]">New Time Slot</div>
        <div className="grid grid-cols-[64px_72px_1fr_1fr] items-center gap-2">
          <input value={newItem.dayLabel} onChange={(e) => setNewItem({ ...newItem, dayLabel: e.target.value })} placeholder="Oct 3" className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 font-mono2 text-xs text-[#F3E5AB] focus:outline-none" />
          <input value={newItem.timeLabel} onChange={(e) => setNewItem({ ...newItem, timeLabel: e.target.value })} placeholder="14:00" className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 font-mono2 text-xs text-[#F3E5AB] focus:outline-none" />
          <input value={newItem.title} onChange={(e) => setNewItem({ ...newItem, title: e.target.value })} placeholder="Event title" className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 text-xs text-white focus:outline-none" />
          <input value={newItem.venue} onChange={(e) => setNewItem({ ...newItem, venue: e.target.value })} placeholder="Venue" className="rounded border border-[#D4AF37]/20 bg-transparent px-2 py-1.5 text-xs text-white/80 focus:outline-none" />
        </div>
        <button
          onClick={() => newItem.title && newItem.timeLabel && add.mutate({ token: session.token, ...newItem })}
          disabled={!newItem.title || !newItem.timeLabel || add.isPending}
          className={`${goldBtn} mt-3 flex w-full items-center justify-center gap-1.5`}
        >
          <Plus className="h-3.5 w-3.5" /> {add.isPending ? "Appending…" : "Add New Time Slot"}
        </button>
      </div>
    </div>
  );
}

/* ────────────────────────── SPONSOR MANAGER ──────────────────────── */

function SponsorManager({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const list = trpc.admin.listSponsors.useQuery({ token: session.token });
  const [name, setName] = useState("");

  const invalidate = () => {
    utils.admin.listSponsors.invalidate();
    utils.public.sponsors.invalidate();
  };
  const add = trpc.admin.addSponsor.useMutation({
    onSuccess: () => { toast.success("Sponsor added — now scrolling in the public footer"); setName(""); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const remove = trpc.admin.removeSponsor.useMutation({
    onSuccess: () => { toast.success("Sponsor removed"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <Hexagon className="h-4 w-4 text-[#D4AF37]" /> Dynamic Sponsor Management
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Sponsors render in the infinite horizontal banner at the bottom of every public page.
      </p>
      <div className="mt-3 flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Sponsor / school / brand name" className={inputCls} />
        <button onClick={() => name.trim() && add.mutate({ token: session.token, name: name.trim() })} className={goldBtn}>
          Add
        </button>
      </div>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {list.data?.map((s) => (
          <div key={s.id} className="flex items-center justify-between rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] px-3 py-2">
            <span className="flex items-center gap-2 font-display text-xs font-semibold tracking-[0.15em] text-[#F3E5AB]">
              <Hexagon className="h-3.5 w-3.5 text-[#D4AF37]" /> {s.name}
            </span>
            <button onClick={() => remove.mutate({ token: session.token, id: s.id })} className="text-muted-foreground hover:text-red-400">
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────────────── SYSTEM DATA MAINTENANCE (GLOBAL WIPE) ─────────── */

const RESET_CONFIRMATION = "RESET-SCIENJECT";

/**
 * High-security global purge suite. Each trigger requires the Master Admin to
 * type the verification string RESET-SCIENJECT into its own confirmation box;
 * the server re-validates the string before any DELETE executes.
 */
function SystemMaintenance({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const [wipeInput, setWipeInput] = useState("");
  const [chatInput, setChatInput] = useState("");
  const [keepTrash, setKeepTrash] = useState(true);

  const trash = trpc.admin.listTrash.useQuery({ token: session.token }, { refetchInterval: 30000 });

  const refreshAll = () => {
    utils.admin.overview.invalidate();
    utils.public.categories.invalidate();
    utils.admin.listTrash.invalidate();
  };

  const wipeRosters = trpc.admin.wipeAllRosters.useMutation({
    onSuccess: (r) => {
      toast.success("Global roster wipe complete", {
        description: `${r.teams} teams · ${r.members} members · ${r.registrations} category assignments · ${r.attendance} attendance rows · ${r.scores} score cells purged across all 13 categories${r.trashSaved ? " · snapshot saved to Trash Bin (30 days)" : ""}`,
      });
      setWipeInput("");
      refreshAll();
    },
    onError: (e) => toast.error("Wipe refused", { description: e.message }),
  });

  const clearPings = trpc.admin.clearPingHistory.useMutation({
    onSuccess: (r) => {
      toast.success(`Ping chat history flushed — ${r.purgedPings} messages permanently deleted${r.trashSaved ? " · snapshot saved to Trash Bin (30 days)" : ""}`);
      setChatInput("");
      refreshAll();
    },
    onError: (e) => toast.error("Purge refused", { description: e.message }),
  });

  const restore = trpc.admin.restoreTrash.useMutation({
    onSuccess: (r) => {
      toast.success("Backup restored into live tables", {
        description: Object.entries(r.restored).map(([k, v]) => `${v} ${k}`).join(" · "),
      });
      refreshAll();
    },
    onError: (e) => toast.error("Restore failed", { description: e.message }),
  });

  const destroyTrash = trpc.admin.deleteTrash.useMutation({
    onSuccess: () => { toast.success("Trash entry permanently destroyed"); refreshAll(); },
    onError: (e) => toast.error(e.message),
  });

  const dangerBox =
    "rounded-md border border-red-500/40 bg-[#0A0A0A] px-3 py-2 font-mono2 text-sm text-red-300 placeholder:text-red-500/40 focus:outline-none focus:ring-2 focus:ring-red-500";
  const dangerBtn =
    "flex w-full items-center justify-center gap-2 rounded-md border-2 border-red-500 bg-red-500/10 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-red-400 transition hover:bg-red-500/25 disabled:cursor-not-allowed disabled:opacity-40";

  return (
    <div className="rounded-xl border-2 border-red-500/50 bg-red-500/5 p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-red-400">
        <AlertTriangle className="h-4 w-4" /> System Data Maintenance
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Global emergency purge controls — clears all test data before live operations. Each action requires typing{" "}
        <span className="font-mono2 font-bold text-red-300">{RESET_CONFIRMATION}</span> into its verification box and
        is re-validated server-side. These wipes are permanent and cannot be undone.
      </p>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {/* Global roster wipe */}
        <div className="rounded-lg border border-red-500/40 bg-[#0A0A0A] p-4">
          <div className="text-sm font-bold text-white">🚨 WIPE ALL SYSTEM ROSTERS &amp; REGISTRATIONS</div>
          <p className="mt-1 text-xs text-muted-foreground">
            Drops every individual member record, team institution, attendance checklist, category assignment and
            cached score across all 13 categories simultaneously. Published result states are retracted.
          </p>
          <input
            value={wipeInput}
            onChange={(e) => setWipeInput(e.target.value)}
            placeholder={`Type ${RESET_CONFIRMATION} to authorize`}
            className={`${dangerBox} mt-3 w-full`}
          />
          <label className="mt-2.5 flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={keepTrash}
              onChange={(e) => setKeepTrash(e.target.checked)}
              className="h-4 w-4 accent-[#D4AF37]"
            />
            Keep a recoverable copy in the <span className="font-semibold text-[#F3E5AB]">Trash Bin</span> (auto-expires after 30 days)
          </label>
          <button
            onClick={() => wipeRosters.mutate({ token: session.token, confirmation: wipeInput, keepTrash })}
            disabled={wipeInput !== RESET_CONFIRMATION || wipeRosters.isPending}
            className={`${dangerBtn} mt-2`}
          >
            <Trash2 className="h-4 w-4" /> {wipeRosters.isPending ? "Wiping database…" : "🚨 Execute Global Roster Wipe"}
          </button>
        </div>

        {/* Ping chat history flush */}
        <div className="rounded-lg border border-red-500/40 bg-[#0A0A0A] p-4">
          <div className="text-sm font-bold text-white">🗑️ CLEAR GLOBAL PING CHAT HISTORY</div>
          <p className="mt-1 text-xs text-muted-foreground">
            Permanently flushes the centralized messaging table — every historical ping sent by the general
            departments (Media, Logistics, Publications, Marketing, Registrations, Security) and all 13 category
            rooms.
          </p>
          <input
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            placeholder={`Type ${RESET_CONFIRMATION} to authorize`}
            className={`${dangerBox} mt-3 w-full`}
          />
          <label className="mt-2.5 flex cursor-pointer items-center gap-2 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={keepTrash}
              onChange={(e) => setKeepTrash(e.target.checked)}
              className="h-4 w-4 accent-[#D4AF37]"
            />
            Keep a recoverable copy in the <span className="font-semibold text-[#F3E5AB]">Trash Bin</span> (auto-expires after 30 days)
          </label>
          <button
            onClick={() => clearPings.mutate({ token: session.token, confirmation: chatInput, keepTrash })}
            disabled={chatInput !== RESET_CONFIRMATION || clearPings.isPending}
            className={`${dangerBtn} mt-2`}
          >
            <Trash2 className="h-4 w-4" /> {clearPings.isPending ? "Flushing chat…" : "🗑️ Flush Ping History"}
          </button>
        </div>
      </div>

      {/* ── Trash Bin: recoverable snapshots, 30-day retention ── */}
      <div className="mt-4 rounded-lg border border-[#D4AF37]/25 bg-[#0A0A0A] p-4">
        <div className="flex items-center justify-between">
          <div className="text-sm font-bold text-white">🗃️ Trash Bin — Recoverable Backups</div>
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
            {trash.data?.length ?? 0} snapshot{trash.data?.length === 1 ? "" : "s"} · 30-day retention
          </span>
        </div>
        <div className="mt-3 space-y-2">
          {trash.data?.map((t) => {
            const daysLeft = Math.max(0, Math.ceil((new Date(t.expiresAt).getTime() - Date.now()) / 86400000));
            return (
              <div key={t.id} className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-[#D4AF37]/15 bg-[#121212] px-3 py-2.5">
                <div>
                  <div className="text-xs font-semibold text-white">{t.label}</div>
                  <div className="mt-0.5 text-[10px] text-muted-foreground">
                    {t.summary} · saved {new Date(t.createdAt).toLocaleString()} ·{" "}
                    <span className={daysLeft <= 5 ? "font-bold text-red-400" : "text-[#C5A059]"}>{daysLeft} days left</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => restore.mutate({ token: session.token, id: t.id })}
                    disabled={restore.isPending}
                    className="flex items-center gap-1 rounded-md border border-[#D4AF37]/50 px-2.5 py-1.5 text-[11px] font-bold text-[#F3E5AB] hover:bg-[#D4AF37]/10 disabled:opacity-40"
                  >
                    <RotateCcw className="h-3 w-3" /> Restore
                  </button>
                  <button
                    onClick={() => destroyTrash.mutate({ token: session.token, id: t.id })}
                    disabled={destroyTrash.isPending}
                    className="flex items-center gap-1 rounded-md border border-red-500/40 px-2.5 py-1.5 text-[11px] font-semibold text-red-400 hover:bg-red-500/10 disabled:opacity-40"
                  >
                    <Trash2 className="h-3 w-3" /> Delete Forever
                  </button>
                </div>
              </div>
            );
          })}
          {trash.data && trash.data.length === 0 && (
            <p className="py-4 text-center text-xs text-muted-foreground">
              Trash Bin is empty — tick the backup option before a wipe to park a recoverable snapshot here.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────── FEEDBACK VAULT (admin-only) ─────────────── */

function Stars({ n }: { n: number }) {
  return (
    <span className="inline-flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} className={`h-3.5 w-3.5 ${i <= n ? "fill-[#D4AF37] text-[#D4AF37]" : "text-white/15"}`} />
      ))}
    </span>
  );
}

function FeedbackViewer({ session }: { session: StoredSession }) {
  const feedback = trpc.admin.listFeedback.useQuery({ token: session.token }, { refetchInterval: 30000 });
  const rows = feedback.data ?? [];
  const avg = (key: "overallRating" | "organizationRating" | "venueRating" | "judgingRating") =>
    rows.length ? (rows.reduce((s, r) => s + r[key], 0) / rows.length).toFixed(1) : "—";

  return (
    <div className="gold-card overflow-hidden rounded-xl">
      <div className="border-b border-[#D4AF37]/20 px-5 py-4">
        <h3 className="flex items-center gap-2 font-display text-lg font-bold text-white">
          <MessageSquareText className="h-4 w-4 text-[#D4AF37]" /> Delegate Feedback Vault
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Secure isolated submissions from /feedback — visible exclusively in this Master Admin portal.
        </p>
        {rows.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-[11px] text-[#F3E5AB]">
            <span>Responses: <b className="font-mono2">{rows.length}</b></span>
            <span>Overall: <b className="font-mono2">{avg("overallRating")}</b>/5</span>
            <span>Organization: <b className="font-mono2">{avg("organizationRating")}</b>/5</span>
            <span>Venue: <b className="font-mono2">{avg("venueRating")}</b>/5</span>
            <span>Judging: <b className="font-mono2">{avg("judgingRating")}</b>/5</span>
          </div>
        )}
      </div>
      <div className="max-h-[520px] space-y-3 overflow-y-auto p-5">
        {rows.map((r) => (
          <div key={r.id} className="rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="font-semibold text-white">{r.delegateName}</span>
                <span className="ml-2 rounded-full border border-[#D4AF37]/40 bg-[#D4AF37]/10 px-2 py-0.5 text-[10px] font-semibold text-[#F3E5AB]">
                  {r.role}
                </span>
                {r.school && <div className="mt-0.5 text-[11px] text-muted-foreground">{r.school}</div>}
              </div>
              <span className="font-mono2 text-[10px] text-muted-foreground">
                {new Date(r.createdAt).toLocaleString()}
              </span>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-1.5 text-[11px] text-white/80 sm:grid-cols-4">
              <span className="flex items-center gap-1.5">Overall <Stars n={r.overallRating} /></span>
              <span className="flex items-center gap-1.5">Organization <Stars n={r.organizationRating} /></span>
              <span className="flex items-center gap-1.5">Venue <Stars n={r.venueRating} /></span>
              <span className="flex items-center gap-1.5">Judging <Stars n={r.judgingRating} /></span>
            </div>
            {r.favoriteCategory && (
              <p className="mt-2 text-[11px] text-[#F3E5AB]">Favourite category: <b>{r.favoriteCategory}</b></p>
            )}
            {r.highlights && (
              <p className="mt-2 whitespace-normal break-words text-xs leading-relaxed text-white/75">
                <span className="font-bold text-[#C5A059]">Highlights: </span>{r.highlights}
              </p>
            )}
            {r.improvements && (
              <p className="mt-1 whitespace-normal break-words text-xs leading-relaxed text-white/75">
                <span className="font-bold text-[#C5A059]">Improvements: </span>{r.improvements}
              </p>
            )}
          </div>
        ))}
        {feedback.data && rows.length === 0 && (
          <p className="py-10 text-center text-sm text-muted-foreground">
            No feedback responses recorded yet.
          </p>
        )}
      </div>
    </div>
  );
}

/* ─────────────────────── URGENT FLASH ALERTS ─────────────────────── */

function FlashAlertBroadcaster({ session }: { session: StoredSession }) {
  const utils = trpc.useUtils();
  const [text, setText] = useState("");
  const active = trpc.public.activeFlashAlert.useQuery(undefined, { refetchInterval: 5000 });

  const emit = trpc.admin.emitFlashAlert.useMutation({
    onSuccess: () => {
      toast.success("Flash Alert emitted to every public screen");
      setText("");
      utils.public.activeFlashAlert.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const retract = trpc.admin.clearFlashAlert.useMutation({
    onSuccess: () => { toast.success("Flash Alert retracted"); utils.public.activeFlashAlert.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-lg font-bold text-white">
        <Zap className="h-4 w-4 text-[#D4AF37]" /> Urgent Push Broadcast
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Emit a flash alert that instantly overrides every public delegate screen with a full-screen
        gold-bordered overlay until dismissed. Live window: 10 minutes.
      </p>

      {active.data && (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border-2 border-[#D4AF37] bg-[#D4AF37]/10 px-4 py-3">
          <div className="min-w-0">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#D4AF37]">Live on all screens now</p>
            <p className="mt-0.5 whitespace-normal break-words text-sm text-white">{active.data.text}</p>
          </div>
          <button
            onClick={() => retract.mutate({ token: session.token })}
            disabled={retract.isPending}
            className="shrink-0 rounded-md border border-red-500/50 bg-red-500/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-red-400 hover:bg-red-500/20 disabled:opacity-40"
          >
            Retract
          </button>
        </div>
      )}

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        maxLength={1000}
        rows={3}
        placeholder="Type the urgent broadcast text — e.g. “All delegates report to the Auditorium immediately for the closing ceremony lineup.”"
        className="mt-4 w-full resize-y rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
      />
      <button
        onClick={() => text.trim() && emit.mutate({ token: session.token, text: text.trim() })}
        disabled={emit.isPending || !text.trim()}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-md bg-gradient-to-r from-[#C5A059] via-[#D4AF37] to-[#F3E5AB] px-4 py-3 font-display text-xs font-black uppercase tracking-[0.25em] text-black shadow-[0_0_24px_rgba(212,175,55,0.3)] transition hover:shadow-[0_0_36px_rgba(212,175,55,0.5)] disabled:opacity-40"
      >
        <Zap className="h-4 w-4" />
        {emit.isPending ? "Emitting…" : "Emit Flash Alert"}
      </button>
    </div>
  );
}

/* ───────────────────────────── PANEL ─────────────────────────────── */

function AdminPanel({ session }: { session: StoredSession }) {
  const navigate = useNavigate();
  const overview = trpc.admin.overview.useQuery({ token: session.token }, { refetchInterval: 20000 });
  const logout = trpc.auth.logout.useMutation();

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-[#C5A059]">
            <Crown className="h-3.5 w-3.5" /> Master Admin · Global Read/Write
          </div>
          <h1 className="mt-1 font-display text-3xl font-black tracking-wide sm:text-4xl">
            Master <span className="gold-text">Control Panel</span>
          </h1>
        </div>
        <button
          onClick={() => {
            logout.mutate({ token: session.token });
            clearSession("admin");
            navigate("/");
          }}
          className="flex items-center gap-1.5 rounded-md border-2 border-[#D4AF37]/60 px-3 py-2 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/10"
        >
          <LogOut className="h-3.5 w-3.5" /> Log Out
        </button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-6 flex flex-wrap border border-[#D4AF37]/30 bg-[#121212]">
          <TabsTrigger value="overview" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">Overview</TabsTrigger>
          <TabsTrigger value="categories" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">Categories & Venue</TabsTrigger>
          <TabsTrigger value="schedule" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">Schedule</TabsTrigger>
          <TabsTrigger value="sponsors" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">Sponsors</TabsTrigger>
          <TabsTrigger value="data" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">Data & Ticker</TabsTrigger>
          <TabsTrigger value="comms" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">Comms & Feedback</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8">
          {/* Global overview grid */}
          <div>
            <h2 className="mb-4 font-display text-lg font-bold text-white">Global Overview — 13 Categories</h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {overview.data?.map((c) => {
                const pct = c.teamCount ? Math.round((c.gradedCount / c.teamCount) * 100) : 0;
                return (
                  <div key={c.id} className="gold-card rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <span className="font-display text-sm font-bold text-white">{c.name}</span>
                      <div className="flex items-center gap-1.5">
                        {c.isLiveNow && (
                          <span className="rounded-full border border-red-500/50 bg-red-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-red-400">Live</span>
                        )}
                        <span
                          className={`rounded-full border px-2 py-0.5 font-mono2 text-[10px] font-bold ${
                            c.resultsLive ? "border-[#D4AF37]/60 bg-[#D4AF37]/12 text-[#F3E5AB]" : "border-white/15 text-muted-foreground"
                          }`}
                        >
                          {c.resultsLive ? "● LIVE" : "GRADING"}
                        </span>
                      </div>
                    </div>
                    <div className="mt-2 space-y-1 text-xs text-muted-foreground">
                      <div className="flex justify-between">
                        <span>Active round</span>
                        <span className="font-mono2 font-bold gold-text">R{c.activeRound}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Teams graded</span>
                        <span className="font-mono2 text-[#F3E5AB]">{c.gradedCount}/{c.teamCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Eval clock</span>
                        <EvalClockCell endsAt={c.evalTimerEndsAt} round={c.evalTimerRound} />
                      </div>
                    </div>
                    <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/5">
                      <div className="h-full rounded-full bg-gradient-to-r from-[#8a6d2b] via-[#D4AF37] to-[#F3E5AB]" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <LiveSwitchboard session={session} overview={overview.data} />
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          <CategoryControl session={session} overview={overview.data} />
          <VenueMapEditor session={session} overview={overview.data} />
          <StudyGuideManager session={session} overview={overview.data} />
        </TabsContent>

        <TabsContent value="schedule">
          <ScheduleEditor session={session} />
        </TabsContent>

        <TabsContent value="sponsors">
          <SponsorManager session={session} />
        </TabsContent>

        <TabsContent value="data" className="space-y-6">
          <ScoreOverride session={session} />
          <div className="grid gap-6 lg:grid-cols-2">
            <CsvUpload session={session} />
            <TickerController session={session} />
          </div>
          <SystemMaintenance session={session} />
        </TabsContent>

        <TabsContent value="comms" className="space-y-6">
          <FlashAlertBroadcaster session={session} />
          <FeedbackViewer session={session} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ────────────────────────────── PAGE ─────────────────────────────── */

export default function Admin() {
  const session = getSession("admin");
  return (
    <Layout sponsors={false}>
      {session ? (
        <RequireRole role="admin">
          <AdminPanel session={session} />
        </RequireRole>
      ) : (
        <AdminGate />
      )}
    </Layout>
  );
}

import { useEffect, useMemo, useRef, useState } from "react";
import { Camera, Clapperboard, ImageOff, Play, Sparkles } from "lucide-react";
import { Layout } from "@/components/Layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/providers/trpc";

/** The six chronological timeline directories of the media gallery. */
const DAY_TABS = [
  { value: "promo", label: "Promotional Material", tag: "Pre-Event" },
  { value: "opening", label: "Opening Ceremony", tag: "Kickoff" },
  { value: "day1", label: "Day 1", tag: "Oct 2" },
  { value: "day2", label: "Day 2", tag: "Oct 3" },
  { value: "day3", label: "Day 3", tag: "Oct 4" },
  { value: "closing", label: "Closing Ceremony", tag: "Finale" },
] as const;

type DayTag = (typeof DAY_TABS)[number]["value"];

interface GalleryItem {
  id: number;
  kind: "photo" | "video";
  url: string;
  title: string;
  dayTag: string;
  orientation: "vertical" | "landscape";
}

declare global {
  interface Window {
    instgrm?: { Embeds: { process: () => void } };
  }
}

/** Trigger the official Instagram embed processor after each render. */
function useInstagramEmbed(deps: unknown[]) {
  useEffect(() => {
    const t = setTimeout(() => window.instgrm?.Embeds?.process?.(), 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

const isInstagram = (url: string) => /instagram\.com/i.test(url);
const isDirectVideoFile = (url: string) =>
  /\.(mp4|webm|mov)(\?|#|$)/i.test(url) || /^\/uploads\//.test(url);

/** Native Meta wrapper for Instagram posts/reels — blockquote + embed.js. */
function InstagramEmbed({ url, title }: { url: string; title: string }) {
  const ref = useRef<HTMLQuoteElement>(null);
  useInstagramEmbed([url]);
  return (
    <div className="overflow-hidden rounded-xl border-2 border-[#F3E5AB]/70 bg-[#121212] shadow-[0_0_18px_rgba(243,229,171,0.12)]">
      <blockquote
        ref={ref}
        className="instagram-media mx-auto"
        data-instgrm-permalink={url}
        data-instgrm-version="14"
        style={{ maxWidth: 540, width: "100%", margin: "0 auto", background: "#0A0A0A" }}
      >
        <a href={url} target="_blank" rel="noreferrer" className="block px-4 py-10 text-center text-sm text-[#D4AF37]">
          View {title || "this post"} on Instagram
        </a>
      </blockquote>
    </div>
  );
}

/**
 * Video card — vertical 9:16 uploads get an uncropped vertical bounding slot
 * with light gold metadata trims; landscape files render in a 16:9 frame.
 * Direct/local files stream via native HTML5 <video playsinline controls loop>;
 * external page links degrade to a tap-to-open player.
 */
function VideoCard({ item }: { item: GalleryItem }) {
  const [orientation, setOrientation] = useState<"vertical" | "landscape">(item.orientation);
  const direct = isDirectVideoFile(item.url);
  const vertical = orientation === "vertical";

  const shell = vertical
    ? "mx-auto w-56 sm:w-64 overflow-hidden rounded-[1.4rem] border-2 border-[#F3E5AB]/70 bg-black shadow-[0_0_26px_rgba(243,229,171,0.18)]"
    : "overflow-hidden rounded-xl border-2 border-[#F3E5AB]/70 bg-black shadow-[0_0_18px_rgba(243,229,171,0.12)]";

  return (
    <figure className={vertical ? "" : "group"}>
      <div className={shell}>
        <div className={vertical ? "aspect-[9/16] w-full" : "aspect-video w-full"}>
          {direct ? (
            <video
              src={item.url}
              playsInline
              controls
              loop
              preload="metadata"
              onLoadedMetadata={(e) => {
                const v = e.currentTarget;
                if (v.videoHeight > v.videoWidth) setOrientation("vertical");
                else setOrientation("landscape");
              }}
              className="h-full w-full object-contain"
            />
          ) : (
            <a href={item.url} target="_blank" rel="noreferrer" className="relative flex h-full w-full items-center justify-center bg-[radial-gradient(circle_at_50%_30%,rgba(212,175,55,0.22),transparent_60%)]">
              <span className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-[#D4AF37] bg-black/60 transition hover:scale-110 hover:bg-[#D4AF37]">
                <Play className="ml-0.5 h-6 w-6 fill-[#D4AF37] text-[#D4AF37] hover:fill-black hover:text-black" />
              </span>
            </a>
          )}
        </div>
        {/* light gold metadata trim */}
        <div className="border-t border-[#F3E5AB]/50 bg-[#0A0A0A] px-3 py-2">
          <p className="truncate text-center text-[11px] font-semibold text-[#F3E5AB]">{item.title || "Untitled highlight"}</p>
          {vertical && (
            <p className="mt-0.5 text-center font-mono2 text-[8px] uppercase tracking-[0.3em] text-[#D4AF37]/70">9:16 Vertical Reel</p>
          )}
        </div>
      </div>
    </figure>
  );
}

/** Vertical streaming mockup player — the hero highlights carousel card. */
function VerticalPlayer({ item }: { item: GalleryItem }) {
  if (isInstagram(item.url)) {
    return (
      <div className="w-64 shrink-0 snap-start overflow-hidden rounded-[1.6rem] border-2 border-[#F3E5AB]/70 bg-[#121212] shadow-[0_0_26px_rgba(243,229,171,0.18)] sm:w-72">
        <InstagramEmbed url={item.url} title={item.title} />
      </div>
    );
  }
  return (
    <div className="w-56 shrink-0 snap-start sm:w-64">
      <VideoCard item={{ ...item, orientation: "vertical" }} />
    </div>
  );
}

function PhotoCard({ item }: { item: GalleryItem }) {
  const [failed, setFailed] = useState(false);
  return (
    <figure className="group relative overflow-hidden rounded-xl border-2 border-[#F3E5AB]/70 bg-[#121212] shadow-[0_0_18px_rgba(243,229,171,0.12)] transition hover:border-[#F3E5AB] hover:shadow-[0_0_32px_rgba(212,175,55,0.3)]">
      <div className="aspect-[4/3] w-full overflow-hidden">
        {failed ? (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 bg-[#0A0A0A] text-muted-foreground">
            <ImageOff className="h-8 w-8 text-[#D4AF37]/50" />
            <span className="text-[10px] uppercase tracking-[0.2em]">Image unavailable</span>
          </div>
        ) : (
          <img
            src={item.url}
            alt={item.title || "Event coverage"}
            loading="lazy"
            onError={() => setFailed(true)}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        )}
      </div>
      {item.title && (
        <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent px-3 pb-2 pt-7 text-xs font-medium text-[#F3E5AB]">
          {item.title}
        </figcaption>
      )}
    </figure>
  );
}

function EmptyDay({ label }: { label: string }) {
  return (
    <div className="gold-card rounded-2xl px-6 py-16 text-center">
      <Camera className="mx-auto mb-4 h-10 w-10 text-[#D4AF37]/60" />
      <p className="font-display text-lg font-bold text-white">{label} coverage drops soon</p>
      <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
        The Media Team publishes photo sets and highlight reels here as the day unfolds on campus.
      </p>
    </div>
  );
}

export default function Media() {
  const gallery = trpc.public.mediaGallery.useQuery(undefined, { refetchInterval: 20000 });
  const [tab, setTab] = useState<DayTag>("promo");

  const { reels, tabItems } = useMemo(() => {
    const rows = (gallery.data ?? []) as GalleryItem[];
    return {
      reels: rows.filter((r) => r.kind === "video"),
      tabItems: rows.filter((r) => r.dayTag === tab),
    };
  }, [gallery.data, tab]);

  useInstagramEmbed([gallery.data, tab]);

  const activeLabel = DAY_TABS.find((d) => d.value === tab)?.label ?? "";

  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#121212]/80 px-4 py-1.5">
            <Clapperboard className="h-3.5 w-3.5 text-[#D4AF37]" />
            <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-[#F3E5AB]">Official Event Coverage</span>
          </div>
          <h1 className="font-display text-4xl font-black tracking-wide sm:text-5xl">
            Media <span className="gold-text">Gallery</span>
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">
            Every frame from Lahore Grammar School Gulberg 15C and 16C O/A Level Campus — captured by the SCIENJECT 6.0 Media Team.
          </p>
        </div>

        {/* Immersive video highlights carousel — vertical streaming players */}
        <div className="mb-12">
          <div className="mb-4 flex items-center gap-3">
            <Sparkles className="h-4 w-4 text-[#D4AF37]" />
            <h2 className="font-display text-lg font-bold uppercase tracking-[0.2em] text-white">
              Video <span className="gold-text">Highlights</span>
            </h2>
            <span className="h-px flex-1 bg-gradient-to-r from-[#D4AF37]/50 to-transparent" />
          </div>
          {reels.length > 0 ? (
            <div className="flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4 [scrollbar-width:thin]">
              {reels.map((v) => (
                <VerticalPlayer key={v.id} item={v} />
              ))}
            </div>
          ) : (
            <div className="flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="w-44 shrink-0 sm:w-52">
                  <div className="relative flex aspect-[9/16] items-center justify-center overflow-hidden rounded-[1.6rem] border-2 border-dashed border-[#F3E5AB]/30 bg-[#121212]/60">
                    <div className="absolute left-1/2 top-2 h-1.5 w-14 -translate-x-1/2 rounded-full bg-black/60" />
                    <div className="text-center">
                      <Play className="mx-auto mb-2 h-7 w-7 text-[#D4AF37]/40" />
                      <p className="px-4 font-mono2 text-[9px] uppercase tracking-[0.3em] text-muted-foreground">Reel {i} · Coming Soon</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Six-directory chronological timeline tabs */}
        <Tabs value={tab} onValueChange={(v) => setTab(v as DayTag)} className="w-full">
          <TabsList className="mx-auto mb-8 flex h-auto w-fit max-w-full flex-wrap justify-center border border-[#D4AF37]/30 bg-[#121212]">
            {DAY_TABS.map((d) => (
              <TabsTrigger key={d.value} value={d.value} className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
                {d.label}
                <span className="ml-1.5 hidden text-[9px] uppercase tracking-widest opacity-70 sm:inline">{d.tag}</span>
              </TabsTrigger>
            ))}
          </TabsList>
          {DAY_TABS.map((d) => (
            <TabsContent key={d.value} value={d.value}>
              {tabItems.length > 0 ? (
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {tabItems.map((m) =>
                    m.kind === "video" ? (
                      isInstagram(m.url) ? (
                        <InstagramEmbed key={m.id} url={m.url} title={m.title} />
                      ) : (
                        <VideoCard key={m.id} item={m} />
                      )
                    ) : (
                      <PhotoCard key={m.id} item={m} />
                    ),
                  )}
                </div>
              ) : (
                <EmptyDay label={activeLabel} />
              )}
            </TabsContent>
          ))}
        </Tabs>
      </section>
    </Layout>
  );
}

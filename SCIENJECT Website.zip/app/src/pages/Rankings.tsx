import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router";
import { Award, ClipboardList, Crown, Medal, Radio, Scale, Timer, Trophy, X } from "lucide-react";
import { Layout } from "@/components/Layout";
import { RoundCountdown, useNow } from "@/components/Countdown";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/providers/trpc";
import { CATEGORIES } from "@contracts/categories";

const RANK_ICONS = [Crown, Medal, Award];

/**
 * Public Transparency Modal — renders the Standardized Qualification Point
 * Scale straight from the live backend config variables.
 */
function PointScaleModal({ onClose }: { onClose: () => void }) {
  const scale = trpc.public.pointScale.useQuery();
  const poolNames = (scale.data?.compulsoryPool ?? [])
    .map((slug) => CATEGORIES.find((c) => c.slug === slug)?.name ?? slug);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const c = scale.data?.compulsory;
  const o = scale.data?.optional;

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="Point Scale Breakdown"
    >
      <div
        className="relative max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-2xl border-2 border-[#D4AF37] bg-[#0A0A0A] p-6 shadow-[0_0_60px_rgba(212,175,55,0.25)] sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-full border border-[#D4AF37]/40 p-1.5 text-[#D4AF37] transition hover:bg-[#D4AF37]/15"
          aria-label="Close"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="mb-6 flex items-center gap-3">
          <Scale className="h-6 w-6 text-[#D4AF37]" />
          <h2 className="font-display text-2xl font-black tracking-wide text-white">
            Point Scale <span className="gold-text">Breakdown</span>
          </h2>
        </div>

        {/* (a) Category Selection Parameters */}
        <div className="mb-6 rounded-xl border border-[#D4AF37]/30 bg-[#121212] p-5">
          <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-[0.25em] text-[#D4AF37]">
            Category Selection Parameters
          </h3>
          <p className="text-sm leading-relaxed text-white">
            Each team competes in exactly <span className="font-bold text-[#F3E5AB]">5 categories</span>:{" "}
            <span className="font-bold text-[#F3E5AB]">2 Compulsory</span> (dynamically selected by the team out of a
            pool of 3 choices) + <span className="font-bold text-[#F3E5AB]">3 Optional</span>.
          </p>
          {poolNames.length > 0 && (
            <p className="mt-3 text-xs leading-relaxed text-white/70">
              Compulsory pool: <span className="font-semibold text-[#F3E5AB]">{poolNames.join(" · ")}</span>
            </p>
          )}
        </div>

        {/* (b) Point Scale Weightage */}
        <div className="rounded-xl border border-[#D4AF37]/30 bg-[#121212] p-5">
          <h3 className="mb-4 font-display text-sm font-bold uppercase tracking-[0.25em] text-[#D4AF37]">
            Point Scale Weightage
          </h3>
          <div className="space-y-4">
            <div>
              <p className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-white">Compulsory Categories</p>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/8 px-2 py-3">
                  <p className="text-[10px] uppercase tracking-widest text-white/60">R1 Qualification</p>
                  <p className="mt-1 font-mono2 text-xl font-black text-[#F3E5AB]">{c?.r1 ?? "…"} pts</p>
                </div>
                <div className="rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/8 px-2 py-3">
                  <p className="text-[10px] uppercase tracking-widest text-white/60">R2 Qualification</p>
                  <p className="mt-1 font-mono2 text-xl font-black text-[#F3E5AB]">{c?.r2 ?? "…"} pts</p>
                </div>
                <div className="rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/8 px-2 py-3">
                  <p className="text-[10px] uppercase tracking-widest text-white/60">R3 Podium</p>
                  <p className="mt-1 font-mono2 text-xl font-black text-[#F3E5AB]">{c?.r3 ?? "…"} pts</p>
                </div>
              </div>
            </div>
            <div>
              <p className="mb-2 text-xs font-bold uppercase tracking-[0.2em] text-white">Optional Categories</p>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg border border-white/15 bg-white/5 px-2 py-3">
                  <p className="text-[10px] uppercase tracking-widest text-white/60">R1 Qualification</p>
                  <p className="mt-1 font-mono2 text-xl font-black text-white">{o?.r1 ?? "…"} pts</p>
                </div>
                <div className="rounded-lg border border-white/15 bg-white/5 px-2 py-3">
                  <p className="text-[10px] uppercase tracking-widest text-white/60">R2 Qualification</p>
                  <p className="mt-1 font-mono2 text-xl font-black text-white">{o?.r2 ?? "…"} pts</p>
                </div>
                <div className="rounded-lg border border-white/15 bg-white/5 px-2 py-3">
                  <p className="text-[10px] uppercase tracking-widest text-white/60">R3 Podium</p>
                  <p className="mt-1 font-mono2 text-xl font-black text-white">{o?.r3 ?? "…"} pts</p>
                </div>
              </div>
            </div>
          </div>
          <p className="mt-4 border-t border-[#D4AF37]/20 pt-3 text-[11px] leading-relaxed text-white/60">
            Live sync active — the moment a director updates a team's status, public team rows re-derive from these
            exact point variables in real time.
          </p>
        </div>
      </div>
    </div>
  );
}


function CategoryLeaderboard() {
  const [params, setParams] = useSearchParams();
  const [category, setCategory] = useState(params.get("category") ?? "avionix");
  const [round, setRound] = useState("1");

  useEffect(() => {
    const c = params.get("category");
    if (c && CATEGORIES.some((x) => x.slug === c)) setCategory(c);
  }, [params]);

  const board = trpc.public.leaderboard.useQuery(
    { categorySlug: category, round: Number(round) },
    { refetchInterval: 15000 },
  );

  // TIMER ISOLATION: the only clock permitted on a public category page is the
  // "Time Left in Round" evaluation timer — and only while a Director or Master
  // Admin has explicitly started one. No launch/day countdowns or window-close
  // clocks ever leak into this view. Ticks every second so the clock unmounts
  // the instant it hits 00:00.
  const now = useNow(1000);
  const evalTimer = useMemo(() => {
    const ends = board.data?.category.evalTimerEndsAt;
    return ends && new Date(ends).getTime() > now ? new Date(ends) : null;
  }, [board.data?.category.evalTimerEndsAt, now]);

  return (
    <>
      {/* Controls + countdowns */}
      <div className="mb-8 flex flex-col items-center justify-between gap-6 lg:flex-row">
        <div className="flex flex-wrap items-center justify-center gap-3">
          <Select
            value={category}
            onValueChange={(v) => {
              setCategory(v);
              setParams({ category: v });
            }}
          >
            <SelectTrigger className="w-[230px] border-[#D4AF37]/40 bg-[#121212] text-white focus:ring-[#D4AF37]">
              <SelectValue placeholder="Select Category" />
            </SelectTrigger>
            <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
              {CATEGORIES.map((c) => (
                <SelectItem key={c.slug} value={c.slug} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={round} onValueChange={setRound}>
            <SelectTrigger className="w-[170px] border-[#D4AF37]/40 bg-[#121212] text-white focus:ring-[#D4AF37]">
              <SelectValue placeholder="Active Round" />
            </SelectTrigger>
            <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
              {[1, 2, 3].map((r) => (
                <SelectItem key={r} value={String(r)} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                  Round {r}
                  {board.data?.category.activeRound === r ? " · Active" : ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {evalTimer && board.data?.category.evalTimerRound === Number(round) && (
          <div className="flex flex-wrap items-center justify-center gap-4">
            <RoundCountdown target={evalTimer} label={`Time Left in Round ${round}`} />
          </div>
        )}
      </div>

      {/* Meta strip */}
      {board.data && (
        <div className="mb-6 flex flex-wrap items-center justify-center gap-x-8 gap-y-2 text-xs text-muted-foreground">
          <span className="uppercase tracking-[0.15em] text-[#C5A059]">{board.data.category.discipline}</span>
          <span>
            Venue: <span className="text-[#F3E5AB]">{board.data.category.room} · {board.data.category.venue}</span>
          </span>
          <span>
            Cutoff to qualify: <span className="font-mono2 font-bold gold-text">{board.data.config.cutoffScore} pts</span>
          </span>
          <span>
            Teams: <span className="text-[#F3E5AB]">{board.data.teams.length}</span>
          </span>
        </div>
      )}

      {/* Table */}
      <div className="gold-card overflow-hidden rounded-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#D4AF37]/30 bg-[#D4AF37]/5 text-left">
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Rank</th>
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Team</th>
                {board.data?.criteria.map((c) => (
                  <th key={c.id} className="px-4 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">
                    {c.name}
                    <span className="block font-mono2 text-[9px] normal-case tracking-normal text-muted-foreground">/{c.maxPoints}</span>
                  </th>
                ))}
                <th className="px-4 py-3 text-center font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Total</th>
                <th className="px-4 py-3 text-center font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Status</th>
              </tr>
            </thead>
            <tbody>
              {board.data?.teams.map((t) => {
                const top3 = t.rank <= 3 && t.graded;
                const RankIcon = RANK_ICONS[t.rank - 1];
                return (
                  <tr
                    key={t.id}
                    className={`border-b border-[#D4AF37]/10 transition-colors ${
                      top3 ? "bg-gradient-to-r from-[#D4AF37]/12 via-[#D4AF37]/4 to-transparent" : "hover:bg-[#D4AF37]/5"
                    }`}
                  >
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        {top3 && RankIcon ? (
                          <RankIcon className={`h-4 w-4 ${t.rank === 1 ? "text-[#F3E5AB]" : t.rank === 2 ? "text-[#D4AF37]" : "text-[#C5A059]"}`} />
                        ) : null}
                        <span className={`font-mono2 font-bold ${top3 ? "gold-glow" : "text-muted-foreground"}`}>#{t.rank}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`font-semibold ${top3 ? "gold-glow" : "text-white"}`}>{t.name}</span>
                      {t.school && <div className="text-[11px] text-muted-foreground">{t.school}</div>}
                    </td>
                    {board.data.criteria.map((c) => (
                      <td key={c.id} className="px-4 py-3.5 text-center font-mono2 text-xs text-[#F3E5AB]">
                        {t.scores[c.id] ?? 0}
                      </td>
                    ))}
                    <td className="px-4 py-3.5 text-center">
                      <span className={`font-mono2 text-base font-bold ${top3 ? "gold-glow" : "gold-text"}`}>{t.total}</span>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span
                        className={`inline-block rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] ${
                          t.status === "Qualified"
                            ? "border-[#D4AF37]/60 bg-[#D4AF37]/12 text-[#F3E5AB]"
                            : "border-red-500/40 bg-red-500/10 text-red-400"
                        }`}
                      >
                        {t.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {board.data && board.data.teams.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-muted-foreground">
                    No teams registered in this category yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/**
 * Individual Team Leaderboard — the Race for Best Delegation master grid.
 * Column schema is fixed: Rank · Team Name · Institution · R1 · R2 · R3 · Total.
 * Every cell carries standardized scale-key block points computed exclusively
 * by the backend engine — raw rubric marks never surface on this grid.
 */
function TeamLeaderboard() {
  const standings = trpc.public.teamStandings.useQuery(undefined, { refetchInterval: 15000 });
  return (
    <div className="gold-card overflow-hidden rounded-xl">
      <div className="border-b border-[#D4AF37]/20 px-5 py-4">
        <h3 className="flex items-center gap-2 font-display text-lg font-bold text-white">
          <Trophy className="h-4 w-4 text-[#D4AF37]" /> Individual Team Leaderboard
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Standardized qualification block points across all categories — re-sorted live as directors flag round results.
        </p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#D4AF37]/30 bg-[#D4AF37]/5 text-left">
              <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Rank</th>
              <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Team Name</th>
              <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Institution</th>
              <th className="px-5 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Round 1 Points</th>
              <th className="px-5 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Round 2 Points</th>
              <th className="px-5 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Round 3 Points</th>
              <th className="px-5 py-3 text-center font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Total Points</th>
            </tr>
          </thead>
          <tbody>
            {standings.data?.map((s) => {
              const top3 = s.rank <= 3 && s.total > 0;
              const RankIcon = RANK_ICONS[s.rank - 1];
              const cell = (v: number, strong = false) => (
                <span
                  className={`font-mono2 ${
                    v > 0
                      ? strong
                        ? "text-base font-black gold-text"
                        : "font-bold text-[#F3E5AB]"
                      : "text-muted-foreground/50"
                  }`}
                >
                  {v}
                </span>
              );
              return (
                <tr
                  key={s.id}
                  className={`border-b border-[#D4AF37]/10 transition-colors ${
                    top3 ? "bg-gradient-to-r from-[#D4AF37]/12 via-[#D4AF37]/4 to-transparent" : "hover:bg-[#D4AF37]/5"
                  }`}
                >
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2">
                      {top3 && RankIcon ? (
                        <RankIcon className={`h-4 w-4 ${s.rank === 1 ? "text-[#F3E5AB]" : s.rank === 2 ? "text-[#D4AF37]" : "text-[#C5A059]"}`} />
                      ) : null}
                      <span className={`font-mono2 font-bold ${top3 ? "gold-glow" : "text-muted-foreground"}`}>#{s.rank}</span>
                    </div>
                  </td>
                  <td className={`px-5 py-3.5 font-semibold ${top3 ? "gold-glow" : "text-white"}`}>{s.name}</td>
                  <td className="px-5 py-3.5 text-xs text-[#F3E5AB]/85">{s.school ?? "Independent Delegation"}</td>
                  <td className="px-5 py-3.5 text-center">{cell(s.r1Pts)}</td>
                  <td className="px-5 py-3.5 text-center">{cell(s.r2Pts)}</td>
                  <td className="px-5 py-3.5 text-center">{cell(s.r3Pts)}</td>
                  <td className="px-5 py-3.5 text-center">{cell(s.total, true)}</td>
                </tr>
              );
            })}
            {standings.data && standings.data.length === 0 && (
              <tr>
                <td colSpan={7} className="px-5 py-12 text-center text-muted-foreground">
                  No teams on record yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function Rankings() {
  const [scaleOpen, setScaleOpen] = useState(false);
  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#121212]/80 px-4 py-1.5">
            <Radio className="h-3.5 w-3.5 animate-pulse text-[#D4AF37]" />
            <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-[#F3E5AB]">Live · Auto-refreshing</span>
          </div>
          <h1 className="font-display text-4xl font-black tracking-wide sm:text-5xl">
            Live <span className="gold-text">Leaderboard</span>
          </h1>
          <div className="mt-4 flex items-center justify-center gap-4">
            <span className="hidden h-px w-16 bg-gradient-to-r from-transparent to-[#D4AF37] sm:block" />
            <p className="font-display text-sm font-black uppercase tracking-[0.5em] text-[#D4AF37] drop-shadow-[0_0_12px_rgba(212,175,55,0.45)] sm:text-base">
              Race for Best Delegation
            </p>
            <span className="hidden h-px w-16 bg-gradient-to-l from-transparent to-[#D4AF37] sm:block" />
          </div>
          <div className="mt-6 flex justify-center">
            <button
              onClick={() => setScaleOpen(true)}
              className="inline-flex items-center gap-2 rounded-full border-2 border-[#D4AF37] bg-[#D4AF37]/5 px-6 py-2.5 font-display text-sm font-bold uppercase tracking-[0.2em] text-[#F3E5AB] shadow-[0_0_24px_rgba(212,175,55,0.2)] transition hover:bg-[#D4AF37]/15 hover:shadow-[0_0_36px_rgba(212,175,55,0.35)]"
            >
              <ClipboardList className="h-4 w-4 text-[#D4AF37]" />
              📋 See Point Scale Breakdown
            </button>
          </div>
        </div>

        <Tabs defaultValue="teams" className="w-full">
          <TabsList className="mx-auto mb-8 flex w-fit border border-[#D4AF37]/30 bg-[#121212]">
            <TabsTrigger value="teams" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              <Trophy className="mr-2 h-4 w-4" /> Team Leaderboard
            </TabsTrigger>
            <TabsTrigger value="categories" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              <Timer className="mr-2 h-4 w-4" /> Category Scorecards
            </TabsTrigger>
          </TabsList>
          <TabsContent value="teams">
            <TeamLeaderboard />
          </TabsContent>
          <TabsContent value="categories">
            <CategoryLeaderboard />
          </TabsContent>
        </Tabs>

        <p className="mt-4 text-center text-[11px] text-muted-foreground">
          <Trophy className="mr-1 inline h-3 w-3 text-[#D4AF37]" />
          Standings refresh automatically every 15–20 seconds as directors grade.
        </p>
      </section>
      {scaleOpen && <PointScaleModal onClose={() => setScaleOpen(false)} />}
    </Layout>
  );
}

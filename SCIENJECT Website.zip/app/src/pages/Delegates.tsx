import { useMemo, useState } from "react";
import { Link } from "react-router";
import { ArrowRight, Building2, CalendarClock, FileDown, MapPin, Navigation, Users } from "lucide-react";
import { Layout } from "@/components/Layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/providers/trpc";
import { VENUE_BRANCHES } from "@contracts/categories";

interface Block {
  name: string;
  description: string;
}

// Venue architecture: the two campus branches (A-Levels 16C / O-Levels 15C).
const KNOWN_BLOCKS: Block[] = VENUE_BRANCHES.map((b) => ({ name: b.label, description: b.description }));

function blockOfCategory(venue: string) {
  return venue.split("·")[0].trim();
}
function floorOfCategory(venue: string) {
  return venue.split("·")[1]?.trim() ?? "";
}

export default function Delegates() {
  // Fully DB-driven: Master Admin room/venue edits project here live, no rebuild required.
  const { data: categories } = trpc.public.categories.useQuery(undefined, { refetchInterval: 15000 });
  const { data: schedule } = trpc.public.schedule.useQuery(undefined, { refetchInterval: 15000 });
  const [selectedBlock, setSelectedBlock] = useState<string>(KNOWN_BLOCKS[0].name);

  const cats = useMemo(() => categories ?? [], [categories]);

  const blocks = useMemo(() => {
    const names = new Set(KNOWN_BLOCKS.map((b) => b.name));
    const dynamic = [...KNOWN_BLOCKS];
    for (const c of cats) {
      const b = blockOfCategory(c.venue);
      if (b && !names.has(b)) {
        names.add(b);
        dynamic.push({ name: b, description: "Custom allocation zone" });
      }
    }
    return dynamic;
  }, [cats]);

  const byBlock = useMemo(() => {
    const map = new Map<string, typeof cats>();
    for (const cat of cats) {
      const block = blockOfCategory(cat.venue);
      map.set(block, [...(map.get(block) ?? []), cat]);
    }
    return map;
  }, [cats]);

  const activeBlock = byBlock.has(selectedBlock) || blocks.some((b) => b.name === selectedBlock) ? selectedBlock : blocks[0]?.name ?? KNOWN_BLOCKS[0].name;

  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#121212]/80 px-4 py-1.5">
            <Users className="h-3.5 w-3.5 text-[#D4AF37]" />
            <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-[#F3E5AB]">Premium Delegate Hub</span>
          </div>
          <h1 className="font-display text-4xl font-black tracking-wide sm:text-5xl">
            Venue <span className="gold-text">& Room Directory</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm text-white/85">
            Every one of the 13 categories is mapped to a physical space on campus. Find your room, know your
            schedule, report on time.
          </p>
        </div>

        <Tabs defaultValue="map" className="w-full">
          <TabsList className="mx-auto mb-8 flex w-fit border border-[#D4AF37]/30 bg-[#121212]">
            <TabsTrigger value="map" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              <Navigation className="mr-2 h-4 w-4" /> Venue Map
            </TabsTrigger>
            <TabsTrigger value="directory" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              <Building2 className="mr-2 h-4 w-4" /> Room Directory
            </TabsTrigger>
            <TabsTrigger value="schedule" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              <CalendarClock className="mr-2 h-4 w-4" /> Schedule
            </TabsTrigger>
          </TabsList>

          {/* ── Interactive Venue Map ─────────────────────────── */}
          <TabsContent value="map">
            <div className="grid gap-6 lg:grid-cols-5">
              <div className="grid gap-3 sm:grid-cols-2 lg:col-span-2 lg:grid-cols-1">
                {blocks.map((block) => {
                  const count = byBlock.get(block.name)?.length ?? 0;
                  const active = activeBlock === block.name;
                  return (
                    <button
                      key={block.name}
                      onClick={() => setSelectedBlock(block.name)}
                      className={`gold-card rounded-xl p-4 text-left transition-all ${
                        active ? "ring-2 ring-[#D4AF37] shadow-[0_0_30px_rgba(212,175,55,0.25)]" : "opacity-80 hover:opacity-100"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-display text-sm font-bold tracking-wide text-white">{block.name}</span>
                        <span className="rounded-full border border-[#D4AF37]/40 px-2 py-0.5 font-mono2 text-[10px] text-[#F3E5AB]">
                          {count} {count === 1 ? "event" : "events"}
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-white/75">{block.description}</p>
                    </button>
                  );
                })}
              </div>

              <div className="gold-card rounded-xl p-6 lg:col-span-3">
                <div className="mb-5 flex items-center justify-between">
                  <h3 className="font-display text-xl font-bold gold-text">{activeBlock}</h3>
                  <span className="text-xs text-white/75">
                    {(byBlock.get(activeBlock) ?? []).length} categories hosted here
                  </span>
                </div>
                <div className="space-y-3">
                  {(byBlock.get(activeBlock) ?? []).map((cat) => (
                    <div
                      key={cat.slug}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] px-4 py-3"
                    >
                      <div>
                        <div className="font-semibold text-white">{cat.name}</div>
                        <div className="text-[10px] uppercase tracking-[0.15em] text-[#C5A059]">{cat.discipline}</div>
                        <div className="mt-0.5 flex items-center gap-3 text-xs text-[#F3E5AB]">
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3 text-[#D4AF37]" /> {cat.room}
                          </span>
                          <span className="text-white/75">{floorOfCategory(cat.venue)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {cat.hasStudyGuide ? (
                          <a
                            href={`/api/study-guide/${cat.slug}`}
                            className="flex items-center gap-1 rounded-md border border-[#D4AF37]/60 bg-[#D4AF37]/10 px-2.5 py-1 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/20"
                          >
                            <FileDown className="h-3 w-3" /> Download Guide
                          </a>
                        ) : (
                          <span className="flex items-center gap-1 rounded-md border border-white/10 px-2.5 py-1 text-xs text-muted-foreground">
                            <FileDown className="h-3 w-3" /> Coming Soon
                          </span>
                        )}
                        <Link
                          to={`/rankings?category=${cat.slug}`}
                          className="flex items-center gap-1 text-xs font-medium text-[#C5A059] hover:text-[#F3E5AB]"
                        >
                          Rankings <ArrowRight className="h-3 w-3" />
                        </Link>
                      </div>
                    </div>
                  ))}
                  {(byBlock.get(activeBlock) ?? []).length === 0 && (
                    <p className="py-8 text-center text-xs text-white/60">No categories allocated to this block yet.</p>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* ── Room Directory ────────────────────────────────── */}
          <TabsContent value="directory">
            <div className="gold-card overflow-hidden rounded-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#D4AF37]/30 bg-[#D4AF37]/5 text-left">
                      <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">#</th>
                      <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Category</th>
                      <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Room</th>
                      <th className="px-5 py-3 font-display text-xs uppercase tracking-[0.2em] text-[#C5A059]">Branch · Floor</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cats.map((cat, i) => (
                      <tr key={cat.slug} className="border-b border-[#D4AF37]/10 transition-colors hover:bg-[#D4AF37]/5">
                        <td className="px-5 py-3.5 font-mono2 text-xs text-white/70">{String(i + 1).padStart(2, "0")}</td>
                        <td className="px-5 py-3.5">
                          <Link to={`/rankings?category=${cat.slug}`} className="font-semibold text-white hover:gold-text">
                            {cat.name}
                          </Link>
                          <div className="text-xs text-white/75">{cat.discipline}</div>
                        </td>
                        <td className="px-5 py-3.5 font-medium text-[#F3E5AB]">{cat.room}</td>
                        <td className="px-5 py-3.5 text-white/80">{cat.venue}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          {/* ── Schedule (DB-driven, admin-editable) ──────────── */}
          <TabsContent value="schedule">
            <div className="relative mx-auto max-w-3xl border-l border-[#D4AF37]/30 pl-8">
              {(schedule ?? []).map((item) => (
                <div key={item.id} className="relative mb-6 last:mb-0">
                  <div className="absolute -left-[37px] top-1.5 h-4 w-4 rounded-full border border-[#D4AF37] bg-[#0A0A0A]">
                    <div className="m-[3px] h-1.5 w-1.5 rounded-full bg-[#D4AF37] shadow-[0_0_8px_rgba(212,175,55,0.9)]" />
                  </div>
                  <div className="gold-card rounded-xl p-4">
                    <div className="font-mono2 text-sm font-bold gold-text">
                      {item.dayLabel} · {item.timeLabel}
                    </div>
                    <div className="mt-1 font-semibold text-white">{item.title}</div>
                    <div className="text-xs text-[#F3E5AB]">{item.venue}</div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </section>
    </Layout>
  );
}

import { ArrowRight, Building2, Instagram, Landmark, Mail, Phone, UserCheck, Users } from "lucide-react";
import { Layout } from "@/components/Layout";
import { LogoMark } from "@/components/LogoMark";
import { CONTACTS, REGISTRATION_FORM_URL, VENUE_NAME } from "@contracts/categories";

const STEPS = [
  {
    title: "Fill the Official Registration Form",
    body: "Assemble your delegation and complete the official SCIENJECT 6.0 Google Form with your school institution, team names, and category selections.",
  },
  {
    title: "Submit the Registration Fee",
    body: "Pay via the school Accounts Office or by bank deposit (details below). Keep your deposit slip or receipt as proof of payment.",
  },
  {
    title: "Confirm with the Registrations Directorate",
    body: "Send proof of payment to the Directors Registrations via phone or email. Your team roster and category allocations will be confirmed over email.",
  },
];

export default function Registration() {
  return (
    <Layout>
      <section className="mx-auto max-w-5xl px-4 py-14 sm:px-6">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#121212]/80 px-4 py-1.5">
            <UserCheck className="h-3.5 w-3.5 text-[#D4AF37]" />
            <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-[#F3E5AB]">Delegate Registration</span>
          </div>
          <h1 className="font-display text-4xl font-black tracking-wide sm:text-5xl">
            Register for <span className="gold-text">SCIENJECT 6.0</span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-sm font-medium text-white">{VENUE_NAME} · October 2–4, 2026</p>
          <div className="mx-auto mt-6 flex justify-center">
            <LogoMark className="h-20 w-20" fallbackClassName="h-8 w-8" />
          </div>
          <button
            type="button"
            onClick={() => window.open(REGISTRATION_FORM_URL, "_blank", "noopener,noreferrer")}
            className="gold-pulse mt-6 inline-flex items-center gap-2.5 rounded-xl bg-[#D4AF37] px-10 py-4 font-display text-base font-black uppercase tracking-[0.15em] text-[#121212] shadow-[0_0_50px_rgba(212,175,55,0.45)] transition hover:scale-[1.03] hover:bg-[#F3E5AB]"
          >
            Click to Register Now <ArrowRight className="h-5 w-5" />
          </button>
        </div>

        {/* Steps */}
        <div className="grid gap-4 sm:grid-cols-3">
          {STEPS.map((s, i) => (
            <div key={i} className="gold-callout rounded-xl p-5">
              <div className="font-mono2 text-2xl font-bold gold-text">{String(i + 1).padStart(2, "0")}</div>
              <h3 className="mt-2 font-display text-base font-bold text-white">{s.title}</h3>
              <p className="mt-2 text-xs leading-relaxed text-white/90">{s.body}</p>
            </div>
          ))}
        </div>

        <div className="gold-divider mx-auto my-12 max-w-3xl" />

        {/* Payment methods */}
        <h2 className="mb-6 text-center font-display text-2xl font-bold tracking-wide">
          Payment <span className="gold-text">Methods</span>
        </h2>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="gold-callout rounded-xl p-6">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/8">
                <Building2 className="h-5 w-5 text-[#D4AF37]" />
              </div>
              <h3 className="font-display text-lg font-bold text-white">1 · Submit to the School Office</h3>
            </div>
            <div className="mt-4 space-y-2.5 text-sm text-white">
              <p>
                <span className="font-semibold text-[#F3E5AB]">Accounts Office</span> at Lahore Grammar School Gulberg 15C and 16C O/A Level Campus.
              </p>
              <div className="rounded-lg border border-[#D4AF37]/30 bg-[#0A0A0A] px-4 py-3">
                <div className="text-[10px] uppercase tracking-[0.25em] text-[#C5A059]">Timings</div>
                <p className="mt-1 font-medium text-white">Monday – Friday</p>
                <p className="font-mono2 text-sm font-semibold text-[#F3E5AB]">9:00 a.m. – 12:30 p.m.</p>
                <p className="font-mono2 text-sm font-semibold text-[#F3E5AB]">2:30 p.m. – 3:30 p.m.</p>
              </div>
            </div>
          </div>

          <div className="gold-callout rounded-xl p-6">
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/8">
                <Landmark className="h-5 w-5 text-[#D4AF37]" />
              </div>
              <h3 className="font-display text-lg font-bold text-white">2 · Bank Deposit</h3>
            </div>
            <div className="mt-4 space-y-2 rounded-lg border border-[#D4AF37]/30 bg-[#0A0A0A] px-4 py-3 text-sm">
              {[
                ["IBAN", "PK15ASCM0001000320232044"],
                ["Account Number", "1000320232044"],
                ["Account Title", "SHARIQUE HASSAN"],
                ["Bank", "Askari Bank"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between gap-4 border-b border-[#D4AF37]/10 py-1.5 last:border-0">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">{k}</span>
                  <span className="font-mono2 text-sm font-bold text-[#F3E5AB]">{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="gold-divider mx-auto my-12 max-w-3xl" />

        {/* Contacts */}
        <h2 className="mb-6 text-center font-display text-2xl font-bold tracking-wide">
          Contact <span className="gold-text">Information</span>
        </h2>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="gold-callout rounded-xl p-6">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-[#C5A059]">
              <Users className="h-4 w-4" /> Directors Registrations
            </div>
            <div className="mt-4 space-y-3">
              {CONTACTS.directors.map((c) => (
                <div key={c.phone}>
                  <div className="text-base font-semibold text-white">{c.name}</div>
                  <div className="flex items-center gap-1.5 font-mono2 text-sm font-semibold text-[#F3E5AB]">
                    <Phone className="h-3.5 w-3.5 text-[#D4AF37]" /> {c.phone}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="gold-callout rounded-xl p-6">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-[#C5A059]">
              <Users className="h-4 w-4" /> Event Heads
            </div>
            <div className="mt-4 space-y-3">
              {CONTACTS.eventHeads.map((c) => (
                <div key={c.phone}>
                  <div className="text-base font-semibold text-white">{c.name}</div>
                  <div className="flex items-center gap-1.5 font-mono2 text-sm font-semibold text-[#F3E5AB]">
                    <Phone className="h-3.5 w-3.5 text-[#D4AF37]" /> {c.phone}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="gold-callout rounded-xl p-6">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-[#C5A059]">
              <Mail className="h-4 w-4" /> Socials
            </div>
            <div className="mt-4 space-y-4">
              <a href="https://instagram.com/scienject_6.0" target="_blank" rel="noreferrer" className="flex items-center gap-2.5 transition hover:opacity-80">
                <Instagram className="h-5 w-5 text-[#D4AF37]" />
                <span className="font-mono2 text-base font-bold text-[#F3E5AB]">{CONTACTS.instagram}</span>
              </a>
              <a href={`mailto:${CONTACTS.email}`} className="flex items-center gap-2.5 transition hover:opacity-80">
                <Mail className="h-5 w-5 text-[#D4AF37]" />
                <span className="font-mono2 text-base font-bold text-[#F3E5AB]">{CONTACTS.email}</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}

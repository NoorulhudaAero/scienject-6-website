import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router";
import {
  AlertTriangle, FileDown, FileUp, KeyRound, LogOut, Play, Plus, Radio, Save, Settings2, ShieldCheck, Square, Timer, Trash2, Trophy, UserPlus,
} from "lucide-react";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { RoundCountdown, useNow } from "@/components/Countdown";
import { RequireRole } from "@/components/guards";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/providers/trpc";
import { clearSession, getSession, saveSession, type StoredSession } from "@/lib/auth";
import { CATEGORIES } from "@contracts/categories";
import type { DirectorDashboardData } from "@/types/api";
import { PingerFeed } from "./DepartmentDashboard";

/* ──────────────────────────── AUTH GATE ──────────────────────────── */

function DirectorGate() {
  const navigate = useNavigate();
  const [categorySlug, setCategorySlug] = useState("");
  const [pin, setPin] = useState("");
  const login = trpc.auth.loginDirector.useMutation({
    onSuccess: (data) => {
      saveSession({ token: data.token, role: "director", categorySlug: data.category.slug, categoryName: data.category.name });
      toast.success(`Welcome, ${data.category.name} Director`);
      navigate(0);
    },
    onError: (e) => toast.error("Access denied", { description: e.message }),
  });

  return (
    <div className="mx-auto max-w-md px-4 py-20">
      <div className="gold-card rounded-2xl p-8">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-[#D4AF37]/50 bg-[#D4AF37]/10">
            <ShieldCheck className="h-7 w-7 text-[#D4AF37]" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-wide">
            Director <span className="gold-text">Portal</span>
          </h1>
          <p className="mt-2 text-xs text-muted-foreground">
            Unified authorization gate. Select your category and enter its Secret Alphanumeric PIN.
          </p>
        </div>

        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (categorySlug && pin) login.mutate({ categorySlug, pin });
          }}
        >
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.2em] text-[#C5A059]">
              Category
            </label>
            <Select value={categorySlug} onValueChange={setCategorySlug}>
              <SelectTrigger className="border-[#D4AF37]/40 bg-[#0A0A0A] text-white focus:ring-[#D4AF37]">
                <SelectValue placeholder="Select your category" />
              </SelectTrigger>
              <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
                {CATEGORIES.map((c) => (
                  <SelectItem key={c.slug} value={c.slug} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.2em] text-[#C5A059]">
              Secret Category PIN
            </label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#C5A059]" />
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="e.g. AVX-9034-KP"
                className="w-full rounded-md border border-[#D4AF37]/40 bg-[#0A0A0A] py-2.5 pl-10 pr-3 font-mono2 text-sm text-white placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={login.isPending || !categorySlug || !pin}
            className="w-full rounded-lg bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#C5A059] py-3 text-sm font-bold text-black transition hover:opacity-90 disabled:opacity-40"
          >
            {login.isPending ? "Verifying…" : "Unlock Director Dashboard"}
          </button>
        </form>
      </div>
    </div>
  );
}

/* ─────────────────────────── MARKING GRID ────────────────────────── */

type Grid = Record<number, Record<number, number>>;

function MarkingGrid({
  session,
  round,
  data,
}: {
  session: StoredSession;
  round: number;
  data: DirectorDashboardData;
}) {
  const utils = trpc.useUtils();
  const criteria = data.criteria.filter((c) => c.round === round);
  const config = data.configs.find((c) => c.round === round);
  const cutoff = config?.cutoffScore ?? 0;

  const [grid, setGrid] = useState<Grid>(() => {
    const g: Grid = {};
    for (const t of data.teams) {
      g[t.id] = {};
      for (const c of criteria) {
        g[t.id][c.id] = data.scores.find((s) => s.teamId === t.id && s.criteriaId === c.id && s.round === round)?.value ?? 0;
      }
    }
    return g;
  });
  const dirty = useRef(false);
  const gridRef = useRef(grid);
  gridRef.current = grid;

  const save = trpc.director.upsertScores.useMutation({
    onSuccess: (r) => {
      dirty.current = false;
      toast.success(`Saved ${r.saved} score cells`, { duration: 1500 });
      utils.director.dashboard.invalidate();
    },
    onError: (e) => toast.error("Save failed", { description: e.message }),
  });

  const saveAll = () => {
    const entries: { teamId: number; criteriaId: number; value: number }[] = [];
    for (const t of data.teams) {
      for (const c of criteria) {
        entries.push({ teamId: t.id, criteriaId: c.id, value: gridRef.current[t.id]?.[c.id] ?? 0 });
      }
    }
    if (entries.length) save.mutate({ token: session.token, round, entries });
  };

  // Local auto-save every 30 seconds
  useEffect(() => {
    const id = setInterval(() => {
      if (dirty.current && !save.isPending) saveAll();
    }, 30000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [round, save.isPending]);

  const totals = useMemo(() => {
    const map: Record<number, number> = {};
    for (const t of data.teams) {
      map[t.id] = Math.round(criteria.reduce((sum, c) => sum + (grid[t.id]?.[c.id] ?? 0), 0) * 10) / 10;
    }
    return map;
  }, [grid, data.teams, criteria]);

  return (
    <div className="gold-card overflow-hidden rounded-xl">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#D4AF37]/20 px-5 py-4">
        <div>
          <h3 className="font-display text-lg font-bold text-white">Roster Marking Grid — Round {round}</h3>
          <p className="text-xs text-muted-foreground">
            Cutoff: <span className="font-mono2 gold-text font-bold">{cutoff} pts</span> · Auto-saves every 30s
          </p>
        </div>
        <button
          onClick={saveAll}
          disabled={save.isPending}
          className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-4 py-2 text-xs font-bold text-black hover:opacity-90 disabled:opacity-40"
        >
          <Save className="h-3.5 w-3.5" /> {save.isPending ? "Saving…" : "Save Now"}
        </button>
      </div>

      {criteria.length === 0 ? (
        <div className="px-5 py-12 text-center text-sm text-muted-foreground">
          No criteria defined for Round {round} yet — add evaluation fields in the Criteria Builder below.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#D4AF37]/20 bg-[#D4AF37]/5 text-left">
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Team</th>
                {criteria.map((c) => (
                  <th key={c.id} className="px-3 py-3 text-center font-display text-xs uppercase tracking-[0.1em] text-[#C5A059]">
                    {c.name}
                    <span className="block font-mono2 text-[9px] normal-case text-muted-foreground">max {c.maxPoints}</span>
                  </th>
                ))}
                <th className="px-4 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Total</th>
                <th className="px-4 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Status</th>
              </tr>
            </thead>
            <tbody>
              {data.teams.map((t) => {
                const total = totals[t.id] ?? 0;
                const qualified = total >= cutoff && cutoff > 0;
                return (
                  <tr key={t.id} className="border-b border-[#D4AF37]/10 hover:bg-[#D4AF37]/5">
                    <td className="px-4 py-2.5">
                      <div className="font-semibold text-white">{t.name}</div>
                      {t.school && <div className="text-[11px] text-muted-foreground">{t.school}</div>}
                    </td>
                    {criteria.map((c) => (
                      <td key={c.id} className="px-3 py-2.5 text-center">
                        <input
                          type="number"
                          min={0}
                          max={c.maxPoints}
                          step="0.5"
                          value={grid[t.id]?.[c.id] ?? 0}
                          onChange={(e) => {
                            dirty.current = true;
                            const raw = Number(e.target.value);
                            const v = Math.max(0, Math.min(Number.isNaN(raw) ? 0 : raw, c.maxPoints));
                            setGrid((g) => ({ ...g, [t.id]: { ...g[t.id], [c.id]: v } }));
                          }}
                          className="w-20 rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-2 py-1.5 text-center font-mono2 text-sm text-[#F3E5AB] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
                        />
                      </td>
                    ))}
                    <td className="px-4 py-2.5 text-center">
                      <span className="font-mono2 text-base font-bold gold-text">{total}</span>
                    </td>
                    <td className="px-4 py-2.5 text-center">
                      <span
                        className={`inline-block rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.15em] ${
                          qualified
                            ? "border-[#D4AF37]/60 bg-[#D4AF37]/12 text-[#F3E5AB]"
                            : "border-red-500/40 bg-red-500/10 text-red-400"
                        }`}
                      >
                        {qualified ? "Qualified" : "Eliminated"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ─────────────────────── EVALUATION TIMER CONTROL ─────────────────── */

function EvalTimer({ session, data, round }: { session: StoredSession; data: DirectorDashboardData; round: number }) {
  const utils = trpc.useUtils();
  const [minutes, setMinutes] = useState("60");
  const start = trpc.director.startEvaluationTimer.useMutation({
    onSuccess: () => {
      toast.success("Round evaluation timer started — now live on the public rankings page");
      utils.director.dashboard.invalidate();
      utils.public.leaderboard.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const halt = trpc.director.haltEvaluationTimer.useMutation({
    onSuccess: () => {
      toast.success("Round deactivated — the public countdown has been cleared");
      utils.director.dashboard.invalidate();
      utils.public.leaderboard.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const now = useNow(1000);
  const endsAt = data.category.evalTimerEndsAt ? new Date(data.category.evalTimerEndsAt) : null;
  const active = Boolean(endsAt && endsAt.getTime() > now);

  return (
    <div className="mt-4 rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] p-3">
      <label className="mb-2 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">
        <Timer className="h-3 w-3" /> Live Evaluation Timer · shown on public rankings
      </label>
      {active && endsAt && (
        <div className="mb-3">
          <RoundCountdown target={endsAt} label={`Timer running for Round ${data.category.evalTimerRound}`} />
        </div>
      )}
      <div className="flex gap-2">
        <input
          type="number"
          min={1}
          value={minutes}
          onChange={(e) => setMinutes(e.target.value)}
          placeholder="Mins"
          className="w-20 rounded-md border border-[#D4AF37]/30 bg-[#121212] px-2 py-2 font-mono2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
        />
        <button
          onClick={() => start.mutate({ token: session.token, round, minutes: Number(minutes) || 60 })}
          className="flex flex-1 items-center justify-center gap-1.5 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2 text-[11px] font-bold text-black hover:opacity-90"
        >
          <Play className="h-3.5 w-3.5" /> Start Round Evaluation
        </button>
        {active && (
          <button
            onClick={() => halt.mutate({ token: session.token })}
            className="flex items-center gap-1 rounded-md border border-red-500/40 px-3 py-2 text-xs font-semibold text-red-400 hover:bg-red-500/10"
          >
            <Square className="h-3 w-3" /> Deactivate Round
          </button>
        )}
      </div>
      {active && data.category.evalTimerRound !== round && (
        <p className="mt-1.5 text-[10px] text-muted-foreground">
          Note: a timer is currently running for Round {data.category.evalTimerRound}.
        </p>
      )}
    </div>
  );
}

/* ─────────────────────── STUDY GUIDE UPLOAD ──────────────────────── */

function readFileAsBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.readAsDataURL(file);
  });
}

/** Director-side study-guide PDF upload — binds instantly to the public category card. */
export function StudyGuideUpload({
  token,
  categorySlug,
  hasGuide,
  onChanged,
}: {
  token: string;
  categorySlug: string;
  hasGuide: boolean;
  onChanged: () => void;
}) {
  const upload = trpc.director.uploadStudyGuide.useMutation({
    onSuccess: () => {
      toast.success('Study guide uploaded — the public card now reads "Download Guide"');
      onChanged();
    },
    onError: (e) => toast.error("Upload failed", { description: e.message }),
  });
  const remove = trpc.director.removeStudyGuide.useMutation({
    onSuccess: () => {
      toast.success("Study guide removed");
      onChanged();
    },
    onError: (e) => toast.error(e.message),
  });

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    if (file.type !== "application/pdf") {
      toast.error("Only PDF files are accepted");
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error("PDF exceeds the 20 MB limit");
      return;
    }
    const dataBase64 = await readFileAsBase64(file);
    upload.mutate({ token, dataBase64 });
  };

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <FileUp className="h-4 w-4 text-[#D4AF37]" /> Study Guide PDF
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Upload the official Round preparation guide for {categorySlug ? "your category" : "this category"}. It binds
        straight to the public category card and Delegate Hub.
      </p>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <span
          className={`rounded-full border px-3 py-1 text-[10px] font-bold uppercase tracking-[0.15em] ${
            hasGuide ? "border-[#D4AF37]/60 bg-[#D4AF37]/12 text-[#F3E5AB]" : "border-white/15 text-muted-foreground"
          }`}
        >
          {hasGuide ? "● Guide Live" : "No guide uploaded"}
        </span>
        <label className="flex cursor-pointer items-center gap-1.5 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-4 py-2 text-xs font-bold text-black hover:opacity-90">
          <FileUp className="h-3.5 w-3.5" /> {upload.isPending ? "Uploading…" : hasGuide ? "Replace PDF" : "Upload Study Guide PDF"}
          <input type="file" accept="application/pdf" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />
        </label>
        {hasGuide && (
          <>
            <a
              href={`/api/study-guide/${categorySlug}`}
              className="flex items-center gap-1 rounded-md border border-[#D4AF37]/40 px-3 py-2 text-xs text-[#F3E5AB] hover:bg-[#D4AF37]/10"
            >
              <FileDown className="h-3.5 w-3.5" /> Preview
            </a>
            <button
              onClick={() => remove.mutate({ token })}
              disabled={remove.isPending}
              className="flex items-center gap-1 rounded-md border border-red-500/40 px-3 py-2 text-xs font-semibold text-red-400 hover:bg-red-500/10"
            >
              <Trash2 className="h-3.5 w-3.5" /> Remove
            </button>
          </>
        )}
      </div>
    </div>
  );
}

/* ──────────────────────────── DASHBOARD ──────────────────────────── */

function Dashboard({ session }: { session: StoredSession }) {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const dash = trpc.director.dashboard.useQuery({ token: session.token }, { refetchInterval: 60000 });
  const [round, setRound] = useState<number | null>(null);
  const activeRound = round ?? dash.data?.category.activeRound ?? 1;

  const [critName, setCritName] = useState("");
  const [critMax, setCritMax] = useState("25");
  const [cutoff, setCutoff] = useState("");
  const [closesAt, setClosesAt] = useState("");
  const [teamName, setTeamName] = useState("");
  const [teamSchool, setTeamSchool] = useState("");

  const logout = trpc.auth.logout.useMutation();
  const invalidate = () => utils.director.dashboard.invalidate();

  const setActiveRound = trpc.director.setActiveRound.useMutation({
    onSuccess: () => { toast.success("Active round updated"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const addCriterion = trpc.director.addCriterion.useMutation({
    onSuccess: () => { toast.success("Criterion added"); setCritName(""); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const deleteCriterion = trpc.director.deleteCriterion.useMutation({
    onSuccess: () => { toast.success("Criterion removed"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const setRoundConfig = trpc.director.setRoundConfig.useMutation({
    onSuccess: () => { toast.success("Round configuration saved"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const addTeam = trpc.director.addTeam.useMutation({
    onSuccess: () => { toast.success("Team added to roster"); setTeamName(""); setTeamSchool(""); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const removeTeam = trpc.director.removeTeam.useMutation({
    onSuccess: () => { toast.success("Team removed"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const publish = trpc.director.publishResults.useMutation({
    onSuccess: () => { toast.success("Results published — announcement pushed to the live ticker"); utils.public.ticker.invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  if (dash.isLoading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-[#D4AF37]/20 border-t-[#D4AF37]" />
      </div>
    );
  }
  if (dash.error || !dash.data) {
    return <div className="py-20 text-center text-red-400">{dash.error?.message ?? "Failed to load dashboard"}</div>;
  }

  const d = dash.data;
  const roundCriteria = d.criteria.filter((c) => c.round === activeRound);
  const roundConfig = d.configs.find((c) => c.round === activeRound);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      {/* Header */}
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-[#C5A059]">
            <ShieldCheck className="h-3.5 w-3.5" /> Isolated Director Session
          </div>
          <h1 className="mt-1 font-display text-3xl font-black tracking-wide sm:text-4xl">
            <span className="gold-text">{d.category.name}</span> <span className="text-white">Command</span>
          </h1>
          <p className="mt-1 text-xs text-muted-foreground">
            {d.category.room} · {d.category.venue} · {d.teams.length} teams on roster
          </p>
        </div>
        <div className="flex items-center gap-2">
          {roundConfig?.closesAt && <RoundCountdown target={new Date(roundConfig.closesAt)} label={`Round ${activeRound} window closes in`} />}
          <button
            onClick={() => {
              logout.mutate({ token: session.token });
              clearSession("director");
              navigate("/");
            }}
            className="flex items-center gap-1.5 rounded-md border-2 border-[#D4AF37]/60 px-3 py-2 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/10"
          >
            <LogOut className="h-3.5 w-3.5" /> Log Out
          </button>
        </div>
      </div>

      {/* Round selector + publish */}
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div className="flex gap-2">
          {[1, 2, 3].map((r) => (
            <button
              key={r}
              onClick={() => setRound(r)}
              className={`rounded-lg border px-4 py-2 font-mono2 text-sm font-bold transition ${
                activeRound === r
                  ? "border-[#D4AF37] bg-[#D4AF37]/15 text-[#F3E5AB] shadow-[0_0_18px_rgba(212,175,55,0.25)]"
                  : "border-[#D4AF37]/25 text-muted-foreground hover:border-[#D4AF37]/60"
              }`}
            >
              ROUND {r}
              {d.category.activeRound === r && <span className="ml-2 text-[9px] uppercase tracking-widest text-[#D4AF37]">● live</span>}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          {d.category.activeRound !== activeRound && (
            <button
              onClick={() => setActiveRound.mutate({ token: session.token, round: activeRound })}
              className="flex items-center gap-1.5 rounded-lg border border-[#D4AF37]/40 px-4 py-2 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/10"
            >
              <Radio className="h-3.5 w-3.5" /> Make Round {activeRound} Active
            </button>
          )}
          <button
            onClick={() => publish.mutate({ token: session.token, round: activeRound })}
            className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-4 py-2 text-xs font-bold text-black hover:opacity-90"
          >
            <Trophy className="h-3.5 w-3.5" /> Publish Round {activeRound} Results
          </button>
        </div>
      </div>

      {/* Marking grid */}
      <MarkingGrid key={`${d.category.id}-${activeRound}-${d.teams.length}-${roundCriteria.length}`} session={session} round={activeRound} data={d} />

      {/* Criteria builder + round config + roster */}
      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        {/* Criteria Builder */}
        <div className="gold-card rounded-xl p-5">
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
            <Plus className="h-4 w-4 text-[#D4AF37]" /> Criteria Builder
          </h3>
          <p className="mt-1 text-xs text-muted-foreground">Custom evaluation fields for Round {activeRound}.</p>
          <div className="mt-4 space-y-2">
            <input
              value={critName}
              onChange={(e) => setCritName(e.target.value)}
              placeholder='e.g. "Technical Code Quality"'
              className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
            />
            <div className="flex gap-2">
              <input
                type="number"
                min={1}
                value={critMax}
                onChange={(e) => setCritMax(e.target.value)}
                placeholder="Max Points"
                className="w-28 rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 font-mono2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
              <button
                onClick={() => critName && addCriterion.mutate({ token: session.token, round: activeRound, name: critName, maxPoints: Number(critMax) || 25 })}
                className="flex-1 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2 text-xs font-bold text-black hover:opacity-90"
              >
                Add Field
              </button>
            </div>
          </div>
          <div className="mt-4 space-y-1.5">
            {roundCriteria.map((c) => (
              <div key={c.id} className="flex items-center justify-between rounded-md border border-[#D4AF37]/20 bg-[#0A0A0A] px-3 py-2 text-sm">
                <span className="text-white">{c.name}</span>
                <span className="flex items-center gap-2">
                  <span className="font-mono2 text-xs text-[#C5A059]">/{c.maxPoints}</span>
                  <button
                    onClick={() => deleteCriterion.mutate({ token: session.token, criteriaId: c.id })}
                    className="text-muted-foreground hover:text-red-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </span>
              </div>
            ))}
            {roundCriteria.length === 0 && <p className="text-xs text-muted-foreground">No fields yet for this round.</p>}
          </div>
        </div>

        {/* Round configuration + evaluation timer */}
        <div className="gold-card rounded-xl p-5">
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
            <Settings2 className="h-4 w-4 text-[#D4AF37]" /> Round Configuration
          </h3>
          <EvalTimer session={session} data={d} round={activeRound} />
          <p className="mt-1 text-xs text-muted-foreground">Cutoff score & evaluation window for Round {activeRound}.</p>
          <div className="mt-4 space-y-3">
            <div>
              <label className="mb-1 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">Round Cutoff Score</label>
              <input
                type="number"
                min={0}
                value={cutoff || roundConfig?.cutoffScore || ""}
                onChange={(e) => setCutoff(e.target.value)}
                className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 font-mono2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
            <div>
              <label className="mb-1 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">Evaluation Window Closes</label>
              <input
                type="datetime-local"
                value={closesAt}
                onChange={(e) => setClosesAt(e.target.value)}
                className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 font-mono2 text-sm text-white [color-scheme:dark] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
            <button
              onClick={() =>
                setRoundConfig.mutate({
                  token: session.token,
                  round: activeRound,
                  cutoffScore: Number(cutoff || roundConfig?.cutoffScore || 0),
                  ...(closesAt ? { closesAt: new Date(closesAt) } : {}),
                })
              }
              className="w-full rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2 text-xs font-bold text-black hover:opacity-90"
            >
              Save Configuration
            </button>
          </div>
        </div>

        {/* Roster */}
        <div className="gold-card rounded-xl p-5">
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
            <UserPlus className="h-4 w-4 text-[#D4AF37]" /> Team Roster
          </h3>
          <p className="mt-1 text-xs text-muted-foreground">
            {d.teams.length} teams registered in {d.category.name} — grouped by school. Multi-category registrations sync here automatically.
          </p>
          <div className="mt-4 space-y-2">
            <input
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              placeholder="Team name"
              className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
            />
            <div className="flex gap-2">
              <input
                value={teamSchool}
                onChange={(e) => setTeamSchool(e.target.value)}
                placeholder="School (optional)"
                className="flex-1 rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
              <button
                onClick={() => teamName && addTeam.mutate({ token: session.token, name: teamName, school: teamSchool || undefined })}
                className="rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-4 py-2 text-xs font-bold text-black hover:opacity-90"
              >
                Add
              </button>
            </div>
          </div>
          <div className="mt-4 max-h-64 space-y-3 overflow-y-auto pr-1">
            {Object.entries(
              d.teams.reduce<Record<string, typeof d.teams>>((acc, t) => {
                const key = t.school?.trim() || "Independent Delegation";
                (acc[key] ??= []).push(t);
                return acc;
              }, {}),
            ).map(([school, schoolTeams]) => (
              <div key={school}>
                <div className="mb-1.5 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  <span className="h-px flex-1 bg-[#D4AF37]/20" />
                  {school}
                  <span className="rounded-full border border-[#D4AF37]/40 px-1.5 font-mono2 text-[9px] text-[#F3E5AB]">{schoolTeams.length}</span>
                  <span className="h-px flex-1 bg-[#D4AF37]/20" />
                </div>
                <div className="space-y-1.5">
                  {schoolTeams.map((t) => (
                    <div key={t.id} className="rounded-md border border-[#D4AF37]/20 bg-[#0A0A0A] px-3 py-2 text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-white">{t.name}</span>
                        <button
                          onClick={() => removeTeam.mutate({ token: session.token, teamId: t.id })}
                          className="text-muted-foreground hover:text-red-400"
                          title="Remove from this category"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      {t.members.length > 0 && (
                        <div className="mt-1 flex flex-wrap gap-1">
                          {t.members.map((m) => (
                            <span key={m} className="rounded-full border border-[#D4AF37]/30 bg-[#D4AF37]/5 px-2 py-0.5 text-[10px] text-[#F3E5AB]">
                              {m}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Study guide asset pipeline */}
      <div className="mt-8">
        <StudyGuideUpload
          token={session.token}
          categorySlug={d.category.slug}
          hasGuide={d.category.hasStudyGuide}
          onChanged={() => invalidate()}
        />
      </div>

      {/* Helpdesk pinger — directors share the centralized staff feed */}
      <div className="mt-8">
        <PingerFeed token={session.token} />
      </div>

      {/* Danger zone — local category purge, clears test data before live ops */}
      <div className="mt-8">
        <LocalRosterReset token={session.token} categoryName={d.category.name} onPurged={() => invalidate()} />
      </div>
    </div>
  );
}

/* ─────────────────────── LOCAL ROSTER RESET ──────────────────────── */

/** High-visibility danger zone: wipes ONLY this director's category. */
export function LocalRosterReset({ token, categoryName, onPurged }: { token: string; categoryName: string; onPurged: () => void }) {
  const purge = trpc.director.purgeCategoryRoster.useMutation({
    onSuccess: (r) => {
      toast.success(`${categoryName} reset to a clean state`, {
        description: `${r.purgedTeams} teams · ${r.purgedMembers} members · ${r.purgedCriteria} criteria fields · ${r.purgedScores} score cells purged`,
      });
      onPurged();
    },
    onError: (e) => toast.error("Purge failed", { description: e.message }),
  });

  const execute = () => {
    const ok = window.confirm(
      "Are you sure you want to permanently delete all team rosters and custom scoring criteria fields for this category?",
    );
    if (ok) purge.mutate({ token });
  };

  return (
    <div className="rounded-xl border-2 border-red-500/50 bg-red-500/5 p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-red-400">
        <AlertTriangle className="h-4 w-4" /> Danger Zone — Local Data Reset
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Permanently deletes every team roster, member record, cached score and custom scoring criteria field inside{" "}
        <span className="font-semibold text-red-300">{categoryName}</span> only. Other categories are never touched.
        This cannot be undone.
      </p>
      <button
        onClick={execute}
        disabled={purge.isPending}
        className="mt-3 flex items-center gap-2 rounded-md border-2 border-red-500 bg-transparent px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-red-400 transition hover:bg-red-500/15 disabled:opacity-40"
      >
        <Trash2 className="h-4 w-4" />
        {purge.isPending ? "Purging category…" : "⚠️ Danger: Clear Local Category Roster"}
      </button>
    </div>
  );
}

/* ────────────────────────────── PAGE ─────────────────────────────── */

export default function DirectorDashboard() {
  const session = getSession("director");
  return (
    <Layout sponsors={false}>
      {session ? (
        <RequireRole role="director">
          <Dashboard session={session} />
        </RequireRole>
      ) : (
        <DirectorGate />
      )}
    </Layout>
  );
}

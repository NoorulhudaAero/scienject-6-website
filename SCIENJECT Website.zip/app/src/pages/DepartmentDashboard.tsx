import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import {
  Bell, Briefcase, FileUp, IdCard, ImagePlus, KeyRound, Loader2, LogOut, Play, Send, ShieldCheck, Trash2, UserPlus,
} from "lucide-react";
import { toast } from "sonner";
import { Layout } from "@/components/Layout";
import { RequireRole } from "@/components/guards";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/providers/trpc";
import { clearSession, getSession, saveSession, type StoredSession } from "@/lib/auth";
import { DEPARTMENTS } from "@contracts/categories";

/* ──────────────────────────── AUTH GATE ──────────────────────────── */

function DepartmentGate() {
  const navigate = useNavigate();
  const [deptSlug, setDeptSlug] = useState("");
  const [pin, setPin] = useState("");
  const login = trpc.auth.loginDepartment.useMutation({
    onSuccess: (data) => {
      saveSession({ token: data.token, role: "department", departmentSlug: data.department.slug, departmentName: data.department.name });
      toast.success(`Welcome to the ${data.department.name} Desk`);
      navigate(0);
    },
    onError: (e) => toast.error("Access denied", { description: e.message }),
  });

  return (
    <div className="mx-auto max-w-md px-4 py-20">
      <div className="gold-card rounded-2xl p-8">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-[#D4AF37]/50 bg-[#D4AF37]/10">
            <Briefcase className="h-7 w-7 text-[#D4AF37]" />
          </div>
          <h1 className="font-display text-2xl font-bold tracking-wide">
            Department <span className="gold-text">Desk</span>
          </h1>
          <p className="mt-2 text-xs text-muted-foreground">
            Support staff authorization gate — Media, Registrations, Logistics, Publications, Marketing, Security.
          </p>
        </div>
        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (deptSlug && pin) login.mutate({ departmentSlug: deptSlug, pin });
          }}
        >
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.2em] text-[#C5A059]">Department</label>
            <Select value={deptSlug} onValueChange={setDeptSlug}>
              <SelectTrigger className="border-[#D4AF37]/40 bg-[#0A0A0A] text-white focus:ring-[#D4AF37]">
                <SelectValue placeholder="Select your department" />
              </SelectTrigger>
              <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
                {DEPARTMENTS.map((d) => (
                  <SelectItem key={d.slug} value={d.slug} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                    {d.name} — {d.remit}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.2em] text-[#C5A059]">Secret Department PIN</label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#C5A059]" />
              <input
                type="password"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="e.g. REG-6X0-D2"
                className="w-full rounded-md border border-[#D4AF37]/40 bg-[#0A0A0A] py-2.5 pl-10 pr-3 font-mono2 text-sm text-white placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
              />
            </div>
          </div>
          <button
            type="submit"
            disabled={login.isPending || !deptSlug || !pin}
            className="w-full rounded-lg bg-gradient-to-r from-[#D4AF37] via-[#F3E5AB] to-[#C5A059] py-3 text-sm font-bold text-black transition hover:opacity-90 disabled:opacity-40"
          >
            {login.isPending ? "Verifying…" : "Unlock Department Desk"}
          </button>
        </form>
      </div>
    </div>
  );
}

/* ────────────────────────── HELPDESK PINGER ───────────────────────── */

export function PingerFeed({ token, role = "director" }: { token: string; role?: "director" | "department" | "admin" }) {
  const utils = trpc.useUtils();
  const feed = trpc.pings.list.useQuery({ token }, { refetchInterval: 5000 });
  const depts = trpc.pings.departments.useQuery({ token });
  const cats = trpc.pings.categories.useQuery({ token });
  const [text, setText] = useState("");
  // Departments/admin can also target category director desks (single or all-13 broadcast)
  const canBroadcastCategories = role !== "director";
  const [target, setTarget] = useState(canBroadcastCategories ? "cat:all" : "dept:logistics");

  const targetLabel = (t: string) => {
    if (t === "cat:all") return "All 13 Categories";
    if (t.startsWith("cat:")) return `${cats.data?.find((c) => c.slug === t.slice(4))?.name ?? t.slice(4)} Desk`;
    return depts.data?.find((d) => d.slug === t.slice(5))?.name ?? t.slice(5);
  };

  const send = trpc.pings.send.useMutation({
    onMutate: (vars) => {
      // Instant optimistic push — the message lands in the feed before the server roundtrip.
      const toDept = vars.toCategory === "all" ? "all-categories" : vars.toCategory ? `category:${vars.toCategory}` : vars.toDepartment ?? "";
      utils.pings.list.setData({ token }, (old) => [
        {
          id: -Date.now(),
          senderRole: role,
          senderName: "You",
          toDepartment: toDept,
          targetLabel: targetLabel(target),
          text: vars.text,
          createdAt: new Date(),
        },
        ...(old ?? []),
      ]);
      setText("");
    },
    onSuccess: (r) => {
      toast.success(r.deliveredTo > 1 ? "Broadcast pushed to all 13 category dashboards" : "Ping broadcast to the helpdesk feed");
      utils.pings.list.invalidate();
    },
    onError: (e) => {
      utils.pings.list.invalidate();
      toast.error(e.message);
    },
  });

  const fire = () => {
    if (!text.trim()) return;
    if (target.startsWith("cat:")) send.mutate({ token, toCategory: target.slice(4), text: text.trim() });
    else send.mutate({ token, toDepartment: target.slice(5), text: text.trim() });
  };

  return (
    <div className="gold-card rounded-xl p-5">
      <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
        <Bell className="h-4 w-4 text-[#D4AF37]" /> Centralized Messaging Pinger
      </h3>
      <p className="mt-1 text-xs text-muted-foreground">
        {canBroadcastCategories
          ? "Broadcast instantly to any operations desk — or push one ping into all 13 category director dashboards at once."
          : "Alert any operations department — directors and department heads share one unified feed."}
      </p>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <Select value={target} onValueChange={setTarget}>
          <SelectTrigger className="w-full border-[#D4AF37]/40 bg-[#0A0A0A] text-white focus:ring-[#D4AF37] sm:w-64">
            <SelectValue placeholder="Select target" />
          </SelectTrigger>
          <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
            {canBroadcastCategories && (
              <>
                <SelectItem value="cat:all" className="font-bold text-[#F3E5AB] focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                  📢 ALL 13 CATEGORIES — BROADCAST
                </SelectItem>
                {(cats.data ?? []).map((c) => (
                  <SelectItem key={c.slug} value={`cat:${c.slug}`} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                    {c.name} Desk
                  </SelectItem>
                ))}
                <div className="mx-2 my-1 h-px bg-[#D4AF37]/25" />
              </>
            )}
            {(depts.data ?? []).map((d) => (
              <SelectItem key={d.slug} value={`dept:${d.slug}`} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                {d.name} (Dept)
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") fire();
          }}
          placeholder='e.g. "Avionix Room 103: Logistics is running out of scoring paper sheets"'
          className="flex-1 rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
        />
        <button
          onClick={fire}
          disabled={send.isPending || !text.trim()}
          className="flex items-center justify-center gap-1.5 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] px-4 py-2 text-xs font-bold text-black hover:opacity-90 disabled:opacity-40"
        >
          <Send className="h-3.5 w-3.5" /> {target === "cat:all" ? "Broadcast" : "Ping"}
        </button>
      </div>

      <div className="mt-4 max-h-96 space-y-2 overflow-y-auto pr-1">
        {feed.data?.map((m) => (
          <div key={m.id} className="rounded-lg border border-[#D4AF37]/15 bg-[#0A0A0A] px-4 py-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.15em]">
                <span className="rounded-full border border-[#D4AF37]/50 bg-[#D4AF37]/10 px-2 py-0.5 text-[#F3E5AB]">
                  {m.senderName}
                </span>
                <span className="text-muted-foreground">→</span>
                <span className={`rounded-full border px-2 py-0.5 text-[#F3E5AB] ${m.toDepartment === "all-categories" ? "border-[#D4AF37]/70 bg-[#D4AF37]/15" : "border-white/15"}`}>
                  {m.targetLabel}
                </span>
              </div>
              <span className="font-mono2 text-[10px] text-muted-foreground">
                {new Date(m.createdAt).toLocaleString()}
              </span>
            </div>
            <p className="mt-2 whitespace-normal break-words text-sm leading-relaxed text-white">{m.text}</p>
          </div>
        ))}
        {feed.data && feed.data.length === 0 && (
          <p className="py-8 text-center text-xs text-muted-foreground">No pings yet — the feed is quiet.</p>
        )}
      </div>
    </div>
  );
}

/* ─────────────────────── REGISTRATIONS ROSTER ─────────────────────── */

const ATT_CACHE_KEY = "scienject_attendance_cache";

function loadAttCache(): Record<string, boolean> {
  try {
    return JSON.parse(localStorage.getItem(ATT_CACHE_KEY) ?? "{}");
  } catch {
    return {};
  }
}

function AttendanceCheck({ checked, onToggle }: { checked: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      className={`flex h-6 w-6 items-center justify-center rounded-md border transition-colors duration-75 ${
        checked
          ? "border-[#D4AF37] bg-gradient-to-br from-[#D4AF37] to-[#C5A059] text-black shadow-[0_0_10px_rgba(212,175,55,0.4)]"
          : "border-[#D4AF37]/30 bg-[#0A0A0A] text-transparent hover:border-[#D4AF37]/60"
      }`}
    >
      ✓
    </button>
  );
}

/** Multi-select checkbox grid — one team can register for many categories at once. */
function CategoryMultiSelect({
  categories,
  selected,
  onChange,
}: {
  categories: { id: number; name: string }[];
  selected: number[];
  onChange: (ids: number[]) => void;
}) {
  const toggle = (id: number) =>
    onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
  return (
    <div className="grid max-h-36 grid-cols-2 gap-1 overflow-y-auto rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] p-2">
      {categories.map((c) => (
        <label
          key={c.id}
          className={`flex cursor-pointer items-center gap-1.5 rounded px-1.5 py-1 text-[11px] transition ${
            selected.includes(c.id) ? "bg-[#D4AF37]/15 font-semibold text-[#F3E5AB]" : "text-white/80 hover:bg-[#D4AF37]/5"
          }`}
        >
          <input
            type="checkbox"
            checked={selected.includes(c.id)}
            onChange={() => toggle(c.id)}
            className="h-3 w-3 shrink-0 accent-[#D4AF37]"
          />
          {c.name}
        </label>
      ))}
    </div>
  );
}

function RegistrationsRoster({ token, categories }: { token: string; categories: { id: number; name: string }[] }) {
  const utils = trpc.useUtils();
  const [categoryId, setCategoryId] = useState<number | "all">("all");
  const roster = trpc.department.roster.useQuery(
    { token, ...(categoryId !== "all" ? { categoryId } : {}) },
    { refetchInterval: 30000 },
  );

  const [name, setName] = useState("");
  const [school, setSchool] = useState("");
  const [members, setMembers] = useState("");
  const [addCats, setAddCats] = useState<number[]>([]);
  const [csv, setCsv] = useState("");

  // Zero-latency attendance layer: localStorage-backed optimistic state
  const [localAtt, setLocalAtt] = useState<Record<string, boolean>>(loadAttCache);
  const attKey = (teamId: number, day: number) => `${teamId}:${day}`;

  // Self-heal: once the server confirms a cached value, drop the local override
  useEffect(() => {
    if (!roster.data) return;
    setLocalAtt((cache) => {
      let changed = false;
      const next = { ...cache };
      for (const t of roster.data) {
        for (const d of [1, 2, 3] as const) {
          const k = attKey(t.id, d);
          const serverVal = t.attendance[`day${d}` as "day1" | "day2" | "day3"];
          if (k in next && next[k] === serverVal) {
            delete next[k];
            changed = true;
          }
        }
      }
      if (changed) localStorage.setItem(ATT_CACHE_KEY, JSON.stringify(next));
      return changed ? next : cache;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roster.data]);

  const invalidate = () => utils.department.roster.invalidate();
  const addTeam = trpc.department.addTeam.useMutation({
    onSuccess: () => { toast.success("Team registered across the selected categories"); setName(""); setSchool(""); setMembers(""); setAddCats([]); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const bulk = trpc.department.bulkImport.useMutation({
    onSuccess: (r) => {
      toast.success(`Imported ${r.membersInserted} member rows (${r.teamsCreated} new teams)`, {
        description: r.warnings.length ? r.warnings.slice(0, 3).join(" · ") : undefined,
      });
      setCsv("");
      invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const toggle = trpc.department.toggleAttendance.useMutation({
    onError: (e, vars) => {
      // Roll back the optimistic flip
      setLocalAtt((cache) => {
        const next = { ...cache, [attKey(vars.teamId, vars.day)]: !vars.present };
        localStorage.setItem(ATT_CACHE_KEY, JSON.stringify(next));
        return next;
      });
      toast.error(e.message);
    },
  });
  const remove = trpc.department.removeTeam.useMutation({
    onSuccess: () => { toast.success("Team removed"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  // Passport Batch Export — one full passport page per member profile
  const [exportingId, setExportingId] = useState<number | null>(null);
  const passports = trpc.department.exportPassports.useMutation({
    onSuccess: (r) => {
      const bytes = Uint8Array.from(atob(r.pdfBase64), (c) => c.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = r.fileName;
      a.click();
      URL.revokeObjectURL(url);
      toast.success(`Passport deck ready — ${r.pages} page${r.pages === 1 ? "" : "s"} compiled`);
      setExportingId(null);
    },
    onError: (e) => { toast.error(e.message); setExportingId(null); },
  });

  const handleAttendance = (teamId: number, day: 1 | 2 | 3, serverVal: boolean) => {
    const current = localAtt[attKey(teamId, day)] ?? serverVal;
    const next = !current;
    // 1 — instantaneous UI fill + synchronous LocalStorage write (no debounce, no macro-task)
    setLocalAtt((cache) => {
      const updated = { ...cache, [attKey(teamId, day)]: next };
      localStorage.setItem(ATT_CACHE_KEY, JSON.stringify(updated));
      return updated;
    });
    // 2 — persist to the central database in the background
    toggle.mutate({ token, teamId, day, present: next });
  };

  return (
    <div className="space-y-6">
      <div className="gold-card overflow-hidden rounded-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#D4AF37]/20 px-5 py-4">
          <div>
            <h3 className="font-display text-lg font-bold text-white">Delegate Roster & Attendance</h3>
            <p className="text-xs text-muted-foreground">Team · School · Members · Categories · Day 1–3 attendance checklist</p>
          </div>
          <Select
            value={String(categoryId)}
            onValueChange={(v) => setCategoryId(v === "all" ? "all" : Number(v))}
          >
            <SelectTrigger className="w-[220px] border-[#D4AF37]/40 bg-[#0A0A0A] text-white focus:ring-[#D4AF37]">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
              <SelectItem value="all" className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">All 13 Categories</SelectItem>
              {categories.map((c) => (
                <SelectItem key={c.id} value={String(c.id)} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                  {c.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#D4AF37]/20 bg-[#D4AF37]/5 text-left">
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Team</th>
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">School Institution</th>
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Member Names</th>
                <th className="px-4 py-3 font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Categories</th>
                <th className="px-3 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">D1</th>
                <th className="px-3 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">D2</th>
                <th className="px-3 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">D3</th>
                <th className="px-4 py-3 text-center font-display text-xs uppercase tracking-[0.15em] text-[#C5A059]">Passport Batch Export</th>
                <th className="px-3 py-3" />
              </tr>
            </thead>
            <tbody>
              {roster.data?.map((t) => (
                <tr key={t.id} className="border-b border-[#D4AF37]/10 hover:bg-[#D4AF37]/5">
                  <td className="px-4 py-2.5 font-semibold text-white">{t.name}</td>
                  <td className="px-4 py-2.5 text-xs text-[#F3E5AB]">{t.school ?? "—"}</td>
                  <td className="px-4 py-2.5 text-xs text-white/80">{t.memberNames ?? "—"}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex max-w-[220px] flex-wrap gap-1">
                      {t.categories.map((c) => (
                        <span key={c} className="rounded-full border border-[#D4AF37]/40 bg-[#D4AF37]/10 px-2 py-0.5 text-[10px] font-semibold text-[#F3E5AB]">
                          {c}
                        </span>
                      ))}
                    </div>
                  </td>
                  {([1, 2, 3] as const).map((d) => {
                    const serverVal = t.attendance[`day${d}` as "day1" | "day2" | "day3"];
                    return (
                      <td key={d} className="px-3 py-2.5 text-center">
                        <div className="flex justify-center">
                          <AttendanceCheck
                            checked={localAtt[attKey(t.id, d)] ?? serverVal}
                            onToggle={() => handleAttendance(t.id, d, serverVal)}
                          />
                        </div>
                      </td>
                    );
                  })}
                  <td className="px-4 py-2.5 text-center">
                    <button
                      onClick={() => { setExportingId(t.id); passports.mutate({ token, teamId: t.id }); }}
                      disabled={exportingId === t.id}
                      className="inline-flex items-center gap-1.5 rounded-md border border-[#D4AF37] bg-[#D4AF37]/5 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.12em] text-[#F3E5AB] transition hover:bg-[#D4AF37]/15 disabled:opacity-50"
                    >
                      {exportingId === t.id ? (
                        <Loader2 className="h-3 w-3 animate-spin" />
                      ) : (
                        <IdCard className="h-3 w-3 text-[#D4AF37]" />
                      )}
                      Generate Cards
                    </button>
                  </td>
                  <td className="px-3 py-2.5">
                    <button onClick={() => remove.mutate({ token, teamId: t.id })} className="text-muted-foreground hover:text-red-400">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
              {roster.data && roster.data.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-muted-foreground">
                    No teams on record — add manually or bulk-import below.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Manual add — multi-category */}
        <div className="gold-card rounded-xl p-5">
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
            <UserPlus className="h-4 w-4 text-[#D4AF37]" /> Manual Roster Entry
          </h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Tick every category this team is registering for — their name & school sync to each director dashboard.
          </p>
          <div className="mt-4 space-y-2">
            <CategoryMultiSelect categories={categories} selected={addCats} onChange={setAddCats} />
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Team Name"
              className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]" />
            <input value={school} onChange={(e) => setSchool(e.target.value)} placeholder="School Institution"
              className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]" />
            <input value={members} onChange={(e) => setMembers(e.target.value)} placeholder="Member Names (comma separated)"
              className="w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]" />
            <button
              onClick={() =>
                name && addCats.length > 0 &&
                addTeam.mutate({ token, categoryIds: addCats, name, school: school || undefined, memberNames: members || undefined })
              }
              disabled={!name || addCats.length === 0}
              className="w-full rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2 text-xs font-bold text-black hover:opacity-90 disabled:opacity-40"
            >
              Add Team to {addCats.length > 1 ? `${addCats.length} Categories` : "Roster"}
            </button>
          </div>
        </div>

        {/* Bulk import — row-based member engine */}
        <div className="gold-card rounded-xl p-5">
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-white">
            <FileUp className="h-4 w-4 text-[#D4AF37]" /> Bulk Excel / CSV Import
          </h3>
          <p className="mt-1 text-xs text-muted-foreground">
            One <span className="text-[#F3E5AB]">individual member</span> per row. Columns:{" "}
            <span className="font-mono2 text-[#F3E5AB]">Team Name, School Institution, Member Name, Categories</span>.
            The Categories cell takes a comma-separated list —{" "}
            <span className="font-mono2 text-[#F3E5AB]">"Avionix, Pitchcraft, Equinox"</span> — and the member is
            cross-populated into every category listed.
          </p>
          <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed border-[#D4AF37]/40 bg-[#0A0A0A] py-2.5 text-xs font-semibold text-[#F3E5AB] hover:bg-[#D4AF37]/5">
            <FileUp className="h-3.5 w-3.5" /> Choose .csv file (or paste below)
            <input
              type="file"
              accept=".csv,.txt,.tsv"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const reader = new FileReader();
                reader.onload = () => setCsv(String(reader.result ?? ""));
                reader.readAsText(f);
              }}
            />
          </label>
          <textarea
            value={csv}
            onChange={(e) => setCsv(e.target.value)}
            rows={5}
            placeholder={"Quantum Quizzers, LGS Gulberg, Ayaan Raza, Avionix, Pitchcraft\nQuantum Quizzers, LGS Gulberg, Zara Khan, Avionix\nStellar Minds, Aitchison College, Hamza Noor, Equinox"}
            className="mt-2 w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 font-mono2 text-xs text-white placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
          />
          <button
            onClick={() => csv.trim() && bulk.mutate({ token, csvText: csv })}
            disabled={bulk.isPending || !csv.trim()}
            className="mt-2 w-full rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2 text-xs font-bold text-black hover:opacity-90 disabled:opacity-40"
          >
            {bulk.isPending ? "Importing…" : "Import Member Roster"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────── MEDIA UPLOAD PORTAL ─────────────────────── */

const MEDIA_DAY_OPTIONS = [
  { value: "promo", label: "Promotional Material" },
  { value: "opening", label: "Opening Ceremony" },
  { value: "day1", label: "Day 1 · Oct 2" },
  { value: "day2", label: "Day 2 · Oct 3" },
  { value: "day3", label: "Day 3 · Oct 4" },
  { value: "closing", label: "Closing Ceremony" },
] as const;

/** Read a File into a raw base64 payload (no data: prefix). */
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

/** Probe a video file's intrinsic dimensions to classify 9:16 vertical reels. */
function probeVideoOrientation(file: File): Promise<"vertical" | "landscape"> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.preload = "metadata";
    v.onloadedmetadata = () => {
      const o = v.videoHeight > v.videoWidth ? "vertical" : "landscape";
      URL.revokeObjectURL(url);
      resolve(o);
    };
    v.onerror = () => {
      URL.revokeObjectURL(url);
      resolve("landscape");
    };
    v.src = url;
  });
}

function MediaUploadPortal({ token }: { token: string }) {
  const utils = trpc.useUtils();
  const items = trpc.department.mediaList.useQuery({ token }, { refetchInterval: 20000 });
  const [mode, setMode] = useState<"link" | "file">("link");
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [kind, setKind] = useState<"photo" | "video">("photo");
  const [dayTag, setDayTag] = useState<string>("day1");
  const [orientation, setOrientation] = useState<"vertical" | "landscape">("landscape");
  const [files, setFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const invalidate = () => {
    utils.department.mediaList.invalidate();
    utils.public.mediaGallery.invalidate();
  };

  const add = trpc.department.mediaAdd.useMutation({
    onSuccess: () => { toast.success("Media record published to the live gallery"); setUrl(""); setTitle(""); invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const uploadFile = trpc.department.mediaUploadFile.useMutation();
  const remove = trpc.department.mediaRemove.useMutation({
    onSuccess: () => { toast.success("Media record removed"); invalidate(); },
    onError: (e) => toast.error(e.message),
  });

  const inputCls =
    "w-full rounded-md border border-[#D4AF37]/30 bg-[#0A0A0A] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#D4AF37]";
  const dayLabel = (v: string) => MEDIA_DAY_OPTIONS.find((d) => d.value === v)?.label ?? v;

  const handleFiles = (list: FileList | null) => {
    if (!list) return;
    const accepted = [...list].filter((f) => /^(image\/(png|jpe?g|webp)|video\/(mp4|quicktime|webm))$/.test(f.type));
    const rejected = list.length - accepted.length;
    if (rejected > 0) toast.error(`${rejected} file(s) skipped — accepted: .png .jpeg .webp · .mp4 .mov .webm`);
    setFiles(accepted);
  };

  const publishLocal = async () => {
    if (!files.length || uploading) return;
    setUploading(true);
    try {
      for (const f of files) {
        const base64 = await fileToBase64(f);
        const up = await uploadFile.mutateAsync({ token, fileName: f.name, mime: f.type, base64 });
        const o = up.kind === "video" ? await probeVideoOrientation(f) : orientation;
        await add.mutateAsync({ token, kind: up.kind, url: up.url, title: (title.trim() || f.name.replace(/\.[A-Za-z0-9]+$/, "")), dayTag: dayTag as never, orientation: o });
      }
      setFiles([]);
      setTitle("");
      if (fileInputRef.current) fileInputRef.current.value = "";
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-5">
      {/* Dual-input upload console */}
      <div className="gold-card rounded-xl p-5 lg:col-span-2">
        <h3 className="flex items-center gap-2 font-display text-lg font-bold text-white">
          <ImagePlus className="h-4 w-4 text-[#D4AF37]" /> Publish to Live Gallery
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">
          External links or local files go live on the public /media page instantly.
        </p>

        {/* Dual-input tabs */}
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => setMode("link")}
            className={`rounded-md border px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider transition ${
              mode === "link" ? "border-[#D4AF37] bg-[#D4AF37]/15 text-[#F3E5AB]" : "border-[#D4AF37]/20 text-muted-foreground hover:border-[#D4AF37]/50"
            }`}
          >
            🔗 Add External Link
          </button>
          <button
            type="button"
            onClick={() => setMode("file")}
            className={`rounded-md border px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider transition ${
              mode === "file" ? "border-[#D4AF37] bg-[#D4AF37]/15 text-[#F3E5AB]" : "border-[#D4AF37]/20 text-muted-foreground hover:border-[#D4AF37]/50"
            }`}
          >
            📁 Upload Local File
          </button>
        </div>

        {mode === "link" ? (
          <>
            <label className="mb-1 mt-4 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">Media Type</label>
            <div className="grid grid-cols-2 gap-2">
              {(["photo", "video"] as const).map((k) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => setKind(k)}
                  className={`rounded-md border px-3 py-2 text-xs font-bold uppercase tracking-wider transition ${
                    kind === k ? "border-[#D4AF37] bg-[#D4AF37]/15 text-[#F3E5AB]" : "border-[#D4AF37]/20 text-muted-foreground hover:border-[#D4AF37]/50"
                  }`}
                >
                  {k === "photo" ? "📷 Photo" : "🎬 Video / Reel"}
                </button>
              ))}
            </div>

            <label className="mb-1 mt-4 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">
              {kind === "photo" ? "Image URL" : "Video URL (direct file or Instagram link)"}
            </label>
            <input
              className={inputCls}
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder={kind === "photo" ? "https://…/coverage-shot.jpg · instagram.com/p/…" : "https://…/highlight.mp4 · instagram.com/reel/…"}
            />
          </>
        ) : (
          <>
            <label className="mb-1 mt-4 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">
              Device Gallery / Disk — multi-select supported
            </label>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".png,.jpg,.jpeg,.webp,.mp4,.mov,.webm,image/png,image/jpeg,image/webp,video/mp4,video/quicktime,video/webm"
              onChange={(e) => handleFiles(e.target.files)}
              className="w-full cursor-pointer rounded-md border border-dashed border-[#D4AF37]/40 bg-[#0A0A0A] px-3 py-6 text-xs text-muted-foreground file:mr-3 file:rounded-md file:border-0 file:bg-[#D4AF37] file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-black hover:border-[#D4AF37]"
            />
            {files.length > 0 && (
              <div className="mt-2 space-y-1">
                {files.map((f, i) => (
                  <p key={i} className="flex items-center gap-2 truncate font-mono2 text-[10px] text-[#F3E5AB]">
                    {f.type.startsWith("video/") ? <Play className="h-3 w-3 shrink-0 text-[#D4AF37]" /> : <ImagePlus className="h-3 w-3 shrink-0 text-[#D4AF37]" />}
                    {f.name} · {(f.size / 1024 / 1024).toFixed(1)} MB
                  </p>
                ))}
              </div>
            )}
            <label className="mb-1 mt-4 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">Frame Orientation (photos)</label>
            <div className="grid grid-cols-2 gap-2">
              {(["landscape", "vertical"] as const).map((o) => (
                <button
                  key={o}
                  type="button"
                  onClick={() => setOrientation(o)}
                  className={`rounded-md border px-3 py-2 text-xs font-bold uppercase tracking-wider transition ${
                    orientation === o ? "border-[#D4AF37] bg-[#D4AF37]/15 text-[#F3E5AB]" : "border-[#D4AF37]/20 text-muted-foreground hover:border-[#D4AF37]/50"
                  }`}
                >
                  {o === "landscape" ? "▭ Landscape" : "▯ Vertical 9:16"}
                </button>
              ))}
            </div>
          </>
        )}

        <label className="mb-1 mt-4 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">Caption / Title</label>
        <input className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Robotics final — winning run" maxLength={255} />

        <label className="mb-1 mt-4 block text-[10px] uppercase tracking-[0.2em] text-[#C5A059]">Timeline Directory</label>
        <Select value={dayTag} onValueChange={setDayTag}>
          <SelectTrigger className="border-[#D4AF37]/30 bg-[#0A0A0A] text-white focus:ring-[#D4AF37]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-[#D4AF37]/40 bg-[#121212] text-white">
            {MEDIA_DAY_OPTIONS.map((d) => (
              <SelectItem key={d.value} value={d.value} className="focus:bg-[#D4AF37]/15 focus:text-[#F3E5AB]">
                {d.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {mode === "link" ? (
          <button
            onClick={() => url.trim() && add.mutate({ token, kind, url: url.trim(), title: title.trim() || undefined, dayTag: dayTag as never, orientation })}
            disabled={add.isPending || !url.trim()}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2.5 text-xs font-bold uppercase tracking-[0.2em] text-black hover:opacity-90 disabled:opacity-40"
          >
            {add.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
            {add.isPending ? "Publishing…" : "Publish Record"}
          </button>
        ) : (
          <button
            onClick={publishLocal}
            disabled={uploading || files.length === 0}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-md bg-gradient-to-r from-[#D4AF37] to-[#C5A059] py-2.5 text-xs font-bold uppercase tracking-[0.2em] text-black hover:opacity-90 disabled:opacity-40"
          >
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileUp className="h-3.5 w-3.5" />}
            {uploading ? "Uploading…" : `Upload ${files.length || ""} File${files.length === 1 ? "" : "s"}`}
          </button>
        )}
      </div>

      {/* Live records manager */}
      <div className="gold-card overflow-hidden rounded-xl lg:col-span-3">
        <div className="border-b border-[#D4AF37]/20 px-5 py-4">
          <h3 className="font-display text-lg font-bold text-white">Live Gallery Records</h3>
          <p className="text-xs text-muted-foreground">{items.data?.length ?? 0} records on the public /media page</p>
        </div>
        <div className="max-h-[560px] space-y-3 overflow-y-auto p-5">
          {items.data?.map((m) => (
            <div key={m.id} className="flex items-center gap-3 rounded-lg border border-[#D4AF37]/20 bg-[#0A0A0A] p-3">
              {m.kind === "photo" ? (
                <img src={m.url} alt={m.title} className="h-14 w-20 shrink-0 rounded-md border border-[#F3E5AB]/40 object-cover" />
              ) : (
                <div className="flex h-14 w-20 shrink-0 items-center justify-center rounded-md border border-[#F3E5AB]/40 bg-[#121212]">
                  <Play className="h-5 w-5 text-[#D4AF37]" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-white">{m.title || "Untitled"}</p>
                <p className="truncate font-mono2 text-[10px] text-muted-foreground">{m.url}</p>
                <div className="mt-1 flex gap-1.5">
                  <span className="rounded-full border border-[#D4AF37]/40 bg-[#D4AF37]/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-[#F3E5AB]">
                    {dayLabel(m.dayTag)}
                  </span>
                  <span className="rounded-full border border-white/15 bg-white/5 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white/70">
                    {m.kind}
                  </span>
                </div>
              </div>
              <button
                onClick={() => remove.mutate({ token, id: m.id })}
                disabled={remove.isPending}
                className="shrink-0 text-muted-foreground transition hover:text-red-400"
                aria-label="Remove record"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
          {items.data && items.data.length === 0 && (
            <p className="py-12 text-center text-sm text-muted-foreground">
              No gallery records yet — publish the first frame using the console.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────────── WORKSPACE ──────────────────────────── */

function DepartmentWorkspace({ session }: { session: StoredSession }) {
  const navigate = useNavigate();
  const ws = trpc.department.workspace.useQuery({ token: session.token });
  const logout = trpc.auth.logout.useMutation();

  if (ws.isLoading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-2 border-[#D4AF37]/20 border-t-[#D4AF37]" />
      </div>
    );
  }
  if (ws.error || !ws.data) {
    return <div className="py-20 text-center text-red-400">{ws.error?.message ?? "Failed to load workspace"}</div>;
  }

  const isRegistrations = ws.data.department.slug === "registrations";
  const isMedia = ws.data.department.slug === "media";

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.3em] text-[#C5A059]">
            <ShieldCheck className="h-3.5 w-3.5" /> Department Staff Session
          </div>
          <h1 className="mt-1 font-display text-3xl font-black tracking-wide sm:text-4xl">
            <span className="gold-text">{ws.data.department.name}</span> <span className="text-white">Desk</span>
          </h1>
          <p className="mt-1 text-xs text-muted-foreground">
            {DEPARTMENTS.find((d) => d.slug === ws.data.department.slug)?.remit}
          </p>
        </div>
        <button
          onClick={() => {
            logout.mutate({ token: session.token });
            clearSession("department");
            navigate("/");
          }}
          className="flex items-center gap-1.5 rounded-md border border-[#D4AF37]/40 px-3 py-2 text-xs text-muted-foreground hover:bg-[#D4AF37]/10 hover:text-[#F3E5AB]"
        >
          <LogOut className="h-3.5 w-3.5" /> Log Out
        </button>
      </div>

      {isRegistrations ? (
        <Tabs defaultValue="roster" className="w-full">
          <TabsList className="mb-6 border border-[#D4AF37]/30 bg-[#121212]">
            <TabsTrigger value="roster" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Roster & Attendance
            </TabsTrigger>
            <TabsTrigger value="pings" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Helpdesk Pings
            </TabsTrigger>
          </TabsList>
          <TabsContent value="roster">
            <RegistrationsRoster token={session.token} categories={ws.data.categories} />
          </TabsContent>
          <TabsContent value="pings">
            <PingerFeed token={session.token} role="department" />
          </TabsContent>
        </Tabs>
      ) : isMedia ? (
        <Tabs defaultValue="gallery" className="w-full">
          <TabsList className="mb-6 border border-[#D4AF37]/30 bg-[#121212]">
            <TabsTrigger value="gallery" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Gallery Upload Portal
            </TabsTrigger>
            <TabsTrigger value="pings" className="data-[state=active]:bg-[#D4AF37] data-[state=active]:text-black">
              Helpdesk Pings
            </TabsTrigger>
          </TabsList>
          <TabsContent value="gallery">
            <MediaUploadPortal token={session.token} />
          </TabsContent>
          <TabsContent value="pings">
            <PingerFeed token={session.token} role="department" />
          </TabsContent>
        </Tabs>
      ) : (
        <PingerFeed token={session.token} role="department" />
      )}
    </div>
  );
}

/* ────────────────────────────── PAGE ─────────────────────────────── */

export default function DepartmentDashboard() {
  const session = getSession("department");
  return (
    <Layout sponsors={false}>
      {session ? (
        <RequireRole role="department">
          <DepartmentWorkspace session={session} />
        </RequireRole>
      ) : (
        <DepartmentGate />
      )}
    </Layout>
  );
}

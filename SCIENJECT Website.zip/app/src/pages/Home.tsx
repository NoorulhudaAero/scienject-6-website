import { Link, useLocation } from "react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  ArrowRight, Bot, Brain, Briefcase, Code, Crown, FileDown, FlaskConical, Leaf, MapPin, Mic, Moon,
  Plane, Radio, Search, ShieldAlert, Sigma, Sparkles, Trophy, Zap,
} from "lucide-react";
import { Layout } from "@/components/Layout";
import { HeroCountdown } from "@/components/Countdown";
import { LogoMark } from "@/components/LogoMark";
import { trpc } from "@/providers/trpc";
import { CATEGORIES, LAUNCH_DATE_ISO, REGISTRATION_FORM_URL, VENUE_NAME } from "@contracts/categories";

const ICONS: Record<string, typeof Zap> = {
  Zap, Plane, Mic, Briefcase, Search, Bot, Moon, Leaf, Sigma, FlaskConical, Code, Sparkles, Brain,
};

const LAUNCH = new Date(LAUNCH_DATE_ISO);

type LiveCat = { slug: string; name: string; activeRound: number; room: string };

/** Live-status tracker: chips animate in on activation and animate out the moment a category goes Inactive. */
function LiveNowStrip({ liveNow }: { liveNow: LiveCat[] }) {
  const [rendered, setRendered] = useState<(LiveCat & { leaving?: boolean })[]>([]);
  const prevSlugs = useRef<Set<string>>(new Set());

  useEffect(() => {
    const nextSlugs = new Set(liveNow.map((c) => c.slug));
    setRendered((current) => {
      const kept = current.filter((c) => nextSlugs.has(c.slug) && !c.leaving);
      const leaving = current
        .filter((c) => !nextSlugs.has(c.slug) && !c.leaving)
        .map((c) => ({ ...c, leaving: true }));
      const added = liveNow.filter((c) => !prevSlugs.current.has(c.slug));
      return [...kept, ...added, ...leaving];
    });
    prevSlugs.current = nextSlugs;
    // Purge leaving chips after their exit transition completes
    const id = setTimeout(() => {
      setRendered((current) => current.filter((c) => !c.leaving));
    }, 450);
    return () => clearTimeout(id);
  }, [liveNow]);

  if (rendered.length === 0) return null;

  return (
    <section className="border-y border-[#D4AF37]/25 bg-[#121212]/60 py-3">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 sm:px-6">
        <span className="flex shrink-0 items-center gap-1.5 rounded-full border border-red-500/50 bg-red-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.2em] text-red-400">
          <Radio className="h-3 w-3 animate-pulse" /> Live Now
        </span>
        {rendered.map((c) => (
          <span
            key={c.slug}
            className={`${
              c.leaving ? "live-chip-leave" : "live-chip-enter"
            } inline-flex items-center gap-1.5 overflow-hidden whitespace-nowrap rounded-full border border-[#D4AF37]/50 bg-[#D4AF37]/10 px-3.5 py-1.5 text-xs font-semibold text-[#F3E5AB] shadow-[0_0_16px_rgba(212,175,55,0.18)]`}
          >
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" />
            {c.name} <span className="text-white/70">· Round {c.activeRound} in {c.room}</span>
          </span>
        ))}
      </div>
    </section>
  );
}

export default function Home() {
  const location = useLocation();
  const { data: categories } = trpc.public.categories.useQuery(undefined, { refetchInterval: 8000 });
  const { data: schedule } = trpc.public.schedule.useQuery(undefined, { refetchInterval: 30000 });

  useEffect(() => {
    if ((location.state as { authError?: boolean } | null)?.authError) {
      toast.error("Access Restricted", {
        description: "That area requires validated credentials. Please sign in.",
        icon: <ShieldAlert className="h-4 w-4 text-[#D4AF37]" />,
      });
      window.history.replaceState({}, "");
    }
  }, [location.state]);

  const liveNow = categories?.filter((c) => c.isLiveNow) ?? [];

  return (
    <Layout>
      {/* ── Hero ─────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden px-4 pb-20 pt-16 sm:px-6">
        <div className="pointer-events-none absolute inset-0 flex items-start justify-center">
          <div className="h-[420px] w-[820px] rounded-full bg-[#D4AF37]/8 blur-[130px]" />
        </div>
        <div className="relative mx-auto max-w-5xl text-center">
          <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-[#D4AF37]/40 bg-[#121212]/80 px-4 py-1.5">
            <Crown className="h-3.5 w-3.5 text-[#D4AF37]" />
            <span className="text-[11px] font-medium uppercase tracking-[0.3em] text-[#F3E5AB]">
              {VENUE_NAME}
            </span>
          </div>

          {/* Central hero logo space — official crest with the futuristic rotating treatment */}
          <div className="mx-auto mb-6 flex justify-center py-3">
            <LogoMark animated className="h-28 w-28 sm:h-36 sm:w-36" fallbackClassName="h-12 w-12" />
          </div>

          <h1 className="font-display text-5xl font-black tracking-wide sm:text-7xl lg:text-8xl">
            <span className="gold-text">SCIENJECT</span>{" "}
            <span className="text-white">6.0</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-sm leading-relaxed text-white sm:text-base">
            Thirteen arenas of science, technology and intellect. Three rounds. One champion per category.
            Welcome to the most prestigious STEM championship of 2026.
          </p>

          {/* Primary registration CTA — bold dark charcoal text on solid bright metallic gold.
              Fires a clean client-side window.open straight at the official Google Form. */}
          <div className="mt-8">
            <button
              type="button"
              onClick={() => window.open(REGISTRATION_FORM_URL, "_blank", "noopener,noreferrer")}
              className="gold-pulse inline-flex items-center gap-2.5 rounded-xl bg-[#D4AF37] px-10 py-4 font-display text-base font-black uppercase tracking-[0.15em] text-[#121212] shadow-[0_0_50px_rgba(212,175,55,0.45)] transition hover:scale-[1.03] hover:bg-[#F3E5AB]"
            >
              Click to Register Now <ArrowRight className="h-5 w-5" />
            </button>
            <div className="mt-3">
              <Link to="/registration" className="text-xs text-muted-foreground underline-offset-4 hover:text-[#F3E5AB] hover:underline">
                Payment methods, steps &amp; contact details →
              </Link>
            </div>
          </div>

          <div className="mt-12">
            <div className="mb-4 font-display text-xs font-semibold uppercase tracking-[0.4em] text-[#C5A059]">
              Countdown to Launch · October 2, 2026
            </div>
            <HeroCountdown target={LAUNCH} />
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/rankings"
              className="inline-flex items-center gap-2 rounded-lg border border-[#D4AF37]/50 bg-[#121212] px-6 py-3 text-sm font-semibold text-[#F3E5AB] transition hover:bg-[#D4AF37]/10"
            >
              <Trophy className="h-4 w-4" /> Live Leaderboard
            </Link>
            <Link
              to="/delegates"
              className="inline-flex items-center gap-2 rounded-lg border border-[#D4AF37]/50 bg-[#121212] px-6 py-3 text-sm font-semibold text-[#F3E5AB] transition hover:bg-[#D4AF37]/10"
            >
              <MapPin className="h-4 w-4" /> Delegate Hub
            </Link>
          </div>
        </div>
      </section>

      {/* ── Live on campus status strip ──────────────────────────── */}
      <LiveNowStrip liveNow={liveNow} />

      {/* ── 13 Categories ────────────────────────────────────────── */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="mb-10 text-center">
          <h2 className="font-display text-3xl font-bold tracking-wide sm:text-4xl">
            The <span className="gold-text">Thirteen Arenas</span>
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Every category runs three live-graded rounds with dynamic criteria and cutoff qualification.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {CATEGORIES.map((cat, i) => {
            const Icon = ICONS[cat.icon] ?? Zap;
            const live = categories?.find((c) => c.slug === cat.slug);
            return (
              <div key={cat.slug} className="gold-card group rounded-xl p-5 transition-transform duration-300 hover:-translate-y-1">
                <div className="flex items-start justify-between">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-[#D4AF37]/40 bg-[#D4AF37]/8">
                    <Icon className="h-5 w-5 text-[#D4AF37]" />
                  </div>
                  <div className="flex items-center gap-2">
                    {live?.isLiveNow && (
                      <span className="live-chip-enter rounded-full border border-red-500/50 bg-red-500/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-red-400">
                        Live
                      </span>
                    )}
                    <span className="font-mono2 text-[10px] text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                  </div>
                </div>
                <h3 className="mt-4 font-display text-lg font-bold uppercase tracking-wide text-white group-hover:gold-text">
                  {cat.name}
                </h3>
                <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-[0.12em] text-[#C5A059]">{cat.discipline}</p>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{cat.description}</p>
                <div className="mt-4 flex items-center justify-between border-t border-[#D4AF37]/15 pt-3 text-[11px]">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <MapPin className="h-3 w-3 text-[#C5A059]" /> {cat.room}
                  </span>
                  <span className="font-medium text-[#C5A059]">
                    {live ? `R${live.activeRound} · ${live.teamCount} teams` : "—"}
                  </span>
                </div>
                <div className="mt-3 flex gap-2">
                  {live?.hasStudyGuide ? (
                    <a
                      href={`/api/study-guide/${cat.slug}`}
                      className="flex flex-1 items-center justify-center gap-1.5 rounded-md border border-[#D4AF37]/60 bg-[#D4AF37]/10 px-2 py-1.5 text-[11px] font-semibold text-[#F3E5AB] transition hover:bg-[#D4AF37]/20"
                    >
                      <FileDown className="h-3.5 w-3.5" /> Download Guide
                    </a>
                  ) : (
                    <span className="flex flex-1 cursor-not-allowed items-center justify-center gap-1.5 rounded-md border border-white/10 px-2 py-1.5 text-[11px] font-semibold text-muted-foreground">
                      <FileDown className="h-3.5 w-3.5" /> Coming Soon
                    </span>
                  )}
                  <Link
                    to={`/rankings?category=${cat.slug}`}
                    className="flex items-center justify-center rounded-md border border-[#D4AF37]/25 px-2.5 text-[#C5A059] transition hover:bg-[#D4AF37]/10 hover:text-[#F3E5AB]"
                    title="View rankings"
                  >
                    <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <div className="gold-divider mx-auto max-w-5xl" />

      {/* ── Master Timeline ──────────────────────────────────────── */}
      <section className="mx-auto max-w-4xl px-4 py-16 sm:px-6">
        <div className="mb-12 text-center">
          <h2 className="font-display text-3xl font-bold tracking-wide sm:text-4xl">
            Master <span className="gold-text">Timeline</span>
          </h2>
          <p className="mt-3 text-sm text-muted-foreground">Three days · Three rounds · October 2–4, 2026</p>
        </div>
        <div className="relative ml-4 border-l border-[#D4AF37]/30 pl-8 sm:ml-8">
          {(schedule ?? []).map((item) => (
            <div key={item.id} className="relative mb-8 last:mb-0">
              <div className="absolute -left-[39px] top-1 flex h-5 w-5 items-center justify-center rounded-full border border-[#D4AF37] bg-[#0A0A0A] sm:-left-[41px]">
                <div className="h-2 w-2 rounded-full bg-gradient-to-br from-[#F3E5AB] to-[#D4AF37] shadow-[0_0_10px_rgba(212,175,55,0.8)]" />
              </div>
              <div className="gold-card rounded-xl p-5">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <span className="font-mono2 text-sm font-bold gold-text">
                    {item.dayLabel} · {item.timeLabel}
                  </span>
                  <span className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">{item.venue}</span>
                </div>
                <h3 className="mt-2 text-base font-semibold text-white">{item.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
}

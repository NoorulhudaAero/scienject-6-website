import { createHash } from "crypto";
import { asc, eq } from "drizzle-orm";
import { getDb } from "../api/queries/connection";
import { categories, departments, messages, scheduleItems, sponsors, teams } from "./schema";
import { CATEGORIES, EVENT_SCHEDULE } from "../contracts/categories";

const hashPin = (pin: string) => createHash("sha256").update(pin.trim().toUpperCase()).digest("hex");

// Server-side only — department desk PINs (never shipped to the client bundle).
const DEPARTMENT_PINS: Record<string, string> = {
  media: "MED-6X0-K4",
  registrations: "REG-6X0-D2",
  logistics: "LOG-6X0-P8",
  publications: "PUB-6X0-W5",
  marketing: "MKT-6X0-R1",
  security: "SEC-6X0-T9",
};

const DEPARTMENT_NAMES: Record<string, string> = {
  media: "Media",
  registrations: "Registrations",
  logistics: "Logistics",
  publications: "Publications",
  marketing: "Marketing",
  security: "Security",
};

const SCHOOL_POOL = [
  "Lahore Grammar School Gulberg",
  "Aitchison College",
  "Lahore College of Arts & Sciences",
  "Beaconhouse Defence Campus",
  "The City School Ravi Campus",
  "Divisional Public School Model Town",
  "Lahore Grammar School DHA",
  "SICAS Gulberg",
];

const FIRST = ["Ayaan", "Zara", "Hamza", "Mahnoor", "Bilal", "Areeba", "Daniyal", "Hira", "Umar", "Sana", "Ali", "Fatima", "Rayyan", "Amal"];
const LAST = ["Raza", "Khan", "Ahmed", "Malik", "Siddiqui", "Chaudhry", "Butt", "Qureshi", "Sheikh", "Tariq", "Aslam", "Nawaz"];

function pick<T>(arr: T[], i: number): T {
  return arr[i % arr.length];
}

async function backfill() {
  const db = getDb();
  console.log("Backfilling SCIENJECT 6.0 v2 data...");

  // ── 1. Update all categories to the v2 spec (names, disciplines, rooms) ──
  for (const def of CATEGORIES) {
    const existing = await db.select().from(categories).where(eq(categories.slug, def.slug)).limit(1);
    if (existing.length > 0) {
      await db
        .update(categories)
        .set({ name: def.name, discipline: def.discipline, tagline: def.description, room: def.room, venue: def.venue })
        .where(eq(categories.id, existing[0].id));
      console.log(`  ✓ updated ${def.name}`);
    } else {
      // New category (e.g. aqualibrium replaces environment)
      const legacy = def.slug === "aqualibrium" ? await db.select().from(categories).where(eq(categories.slug, "environment")).limit(1) : [];
      if (legacy.length > 0) {
        await db
          .update(categories)
          .set({ slug: def.slug, name: def.name, discipline: def.discipline, tagline: def.description, room: def.room, venue: def.venue })
          .where(eq(categories.id, legacy[0].id));
        console.log(`  ✓ migrated environment → ${def.name}`);
      } else {
        await db.insert(categories).values({
          slug: def.slug,
          name: def.name,
          discipline: def.discipline,
          pinHash: hashPin("AQL-1193-CG"),
          room: def.room,
          venue: def.venue,
          tagline: def.description,
        });
        console.log(`  ✓ created ${def.name}`);
      }
    }
  }

  // ── 2. Departments ──
  for (const [slug, pin] of Object.entries(DEPARTMENT_PINS)) {
    const existing = await db.select().from(departments).where(eq(departments.slug, slug)).limit(1);
    if (existing.length === 0) {
      await db.insert(departments).values({ slug, name: DEPARTMENT_NAMES[slug], pinHash: hashPin(pin) });
      console.log(`  ✓ department ${DEPARTMENT_NAMES[slug]}`);
    }
  }

  // ── 3. Schedule items ──
  const existingSchedule = await db.select().from(scheduleItems).limit(1);
  if (existingSchedule.length === 0) {
    await db.insert(scheduleItems).values(
      EVENT_SCHEDULE.map((s, i) => ({ dayLabel: s.date, timeLabel: s.time, title: s.title, venue: s.venue, sortOrder: i })),
    );
    console.log("  ✓ schedule items");
  }

  // ── 4. Sponsors ──
  const existingSponsors = await db.select().from(sponsors).limit(1);
  if (existingSponsors.length === 0) {
    const SPONSOR_SEED = [
      "AURUM LABS", "LGS GULBERG 15C", "VERTEX AEROSPACE", "GOLDEN GATE BANK", "HELIX BIOTECH",
      "NOVA ROBOTICS", "CELESTIAL OPTICS", "MERIDIAN SCHOOLS", "OBSIDIAN TECH", "LUMEN FOUNDATION",
    ];
    await db.insert(sponsors).values(SPONSOR_SEED.map((name, i) => ({ name, sortOrder: i })));
    console.log("  ✓ sponsors");
  }

  // ── 5. Diversify team schools + member names ──
  const allTeams = await db.select().from(teams).orderBy(asc(teams.id));
  let i = 0;
  for (const t of allTeams) {
    if (t.school === "SCIENJECT Delegate School" || !t.school) {
      const school = pick(SCHOOL_POOL, i + Math.floor(i / 3));
      const members = `${pick(FIRST, i)} ${pick(LAST, i)}, ${pick(FIRST, i + 5)} ${pick(LAST, i + 7)}, ${pick(FIRST, i + 9)} ${pick(LAST, i + 3)}`;
      await db.update(teams).set({ school, memberNames: members }).where(eq(teams.id, t.id));
    }
    i++;
  }
  console.log(`  ✓ ${allTeams.length} teams updated with schools & members`);

  // ── 6. Demo helpdesk pings ──
  const existingMessages = await db.select().from(messages).limit(1);
  if (existingMessages.length === 0) {
    await db.insert(messages).values([
      { senderRole: "director", senderName: "Avionix", toDepartment: "logistics", text: "Avionix Room 103: Logistics is running out of scoring paper sheets — please restock before Round 2." },
      { senderRole: "department", senderName: "Security", toDepartment: "media", text: "Security: Media crew please collect your floor access passes from the front desk." },
      { senderRole: "department", senderName: "Registrations", toDepartment: "registrations", text: "Registrations desk: Day 1 attendance checklist is now open for all 13 categories." },
    ]);
    console.log("  ✓ demo pings");
  }

  console.log("Backfill complete.");
  process.exit(0);
}

backfill().catch((err) => {
  console.error(err);
  process.exit(1);
});

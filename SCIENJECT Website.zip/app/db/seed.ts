import { createHash } from "crypto";
import { getDb } from "../api/queries/connection";
import { categories, teams, criteria, roundConfigs, scores, announcements } from "./schema";
import { CATEGORIES } from "../contracts/categories";

const hashPin = (pin: string) => createHash("sha256").update(pin.trim().toUpperCase()).digest("hex");

// Server-side only — never shipped to the client bundle.
const DIRECTOR_PINS: Record<string, string> = {
  scilase: "SCL-4821-AU",
  avionix: "AVX-9034-KP",
  pitchcraft: "PCH-2210-QR",
  "entrepreneurship-x-stem": "EXS-7712-MZ",
  "sleuths-saga": "SLU-5588-DV",
  robomatrix: "RBX-3345-TN",
  equinox: "EQX-6670-JW",
  aqualibrium: "ENV-1193-CG",
  vinculum: "VNC-8456-LB",
  "science-frenzy": "SFR-2097-XH",
  "tech-valley": "TCV-5520-NU",
  femstem: "FST-7864-RE",
  neuroflix: "NFX-4418-YO",
};

const TEAM_POOLS: Record<string, string[]> = {
  scilase: ["Photon Pioneers", "Prism Protocol", "Coherent Crew", "Laser Legends", "Optic Order"],
  avionix: ["Stratos Squad", "Thrust Vector", "Aero Falcons", "Mach Theory", "Skyforge", "Vortex Wing"],
  pitchcraft: ["Elevator Elite", "Deck Dynamos", "Venture Vocal", "Pitch Perfect", "Golden Mic"],
  "entrepreneurship-x-stem": ["Quantum Capital", "Stemventures", "The Disruptors", "Equinox Equity", "Lab2Market"],
  "sleuths-saga": ["Cipher Circle", "The Deductionists", "Forensic Four", "Magnifying Minds", "Clue Cartel"],
  robomatrix: ["Servo Syndicate", "Torque Titans", "Binary Builders", "Actuator Alliance", "Mecha Minds", "Circuit Senate"],
  equinox: ["Nebula Navigators", "Celestial Six", "Orbit Observatory", "Stellar Scholars", "Apex Astronomy"],
  environment: ["Green Guardians", "Carbon Cutters", "Terra Tribe", "Eco Engineers", "Verdant Vision"],
  vinculum: ["Prime Pursuit", "Theorem Throne", "Axiom Army", "Euler's Eagles", "Matrix Mavens"],
  "science-frenzy": ["Reaction Force", "Catalyst Club", "Fission Fusion", "The Variables", "Hypothesis HQ"],
  "tech-valley": ["Kernel Kings", "Stack Storm", "Null Pointer Ninjas", "Deploy Dynasty", "Async Aces"],
  femstem: ["Athena Alliance", "Curie Collective", "Hypatia Hub", "Rosalind Rising", "Ada Army"],
  neuroflix: ["Synapse Society", "Cortex Crew", "Dendrite Dynasty", "Neuron Nexus", "Axon Assembly"],
};

const CRITERIA_POOLS: Record<string, { name: string; max: number }[]> = {
  round1: [
    { name: "Concept & Innovation", max: 25 },
    { name: "Technical Execution", max: 35 },
    { name: "Presentation Quality", max: 20 },
    { name: "Scientific Accuracy", max: 20 },
  ],
  round2: [
    { name: "Problem Solving Depth", max: 30 },
    { name: "Prototype / Deliverable", max: 40 },
    { name: "Team Coordination", max: 15 },
    { name: "Q&A Defence", max: 15 },
  ],
};

// Round evaluation windows (UTC offsets chosen so countdowns are live in preview)
function roundClose(round: number): Date {
  const base: Record<number, string> = {
    1: "2026-10-02T17:00:00",
    2: "2026-10-03T16:30:00",
    3: "2026-10-04T15:00:00",
  };
  return new Date(base[round] ?? base[1]);
}

// Deterministic pseudo-random for stable seed scores
function seededValue(seedStr: string, max: number): number {
  let h = 0;
  for (let i = 0; i < seedStr.length; i++) h = (h * 31 + seedStr.charCodeAt(i)) >>> 0;
  const ratio = 0.45 + ((h % 1000) / 1000) * 0.55; // 45%..100%
  return Math.round(ratio * max * 10) / 10;
}

async function seed() {
  const db = getDb();
  console.log("Seeding SCIENJECT 6.0 database...");

  const existing = await db.query.categories.findMany();
  if (existing.length > 0) {
    console.log(`Database already seeded (${existing.length} categories found). Skipping.`);
    process.exit(0);
  }

  for (const cat of CATEGORIES) {
    const [{ id: categoryId }] = await db
      .insert(categories)
      .values({
        slug: cat.slug,
        name: cat.name,
        pinHash: hashPin(DIRECTOR_PINS[cat.slug]),
        room: cat.room,
        venue: cat.venue,
        discipline: cat.discipline,
        tagline: cat.description,
        activeRound: 1,
      })
      .$returningId();

    // Round configs for all 3 rounds
    for (let round = 1; round <= 3; round++) {
      await db.insert(roundConfigs).values({
        categoryId,
        round,
        cutoffScore: round === 1 ? 55 : round === 2 ? 60 : 65,
        closesAt: roundClose(round),
        resultsLive: round === 1,
      });
    }

    // Criteria for rounds 1 & 2 (round 3 left for directors to build)
    const critIds: { id: number; max: number; round: number }[] = [];
    for (const [roundKey, roundNum] of [["round1", 1], ["round2", 2]] as const) {
      for (const c of CRITERIA_POOLS[roundKey]) {
        const [{ id: criteriaId }] = await db
          .insert(criteria)
          .values({ categoryId, round: roundNum, name: c.name, maxPoints: c.max })
          .$returningId();
        critIds.push({ id: criteriaId, max: c.max, round: roundNum });
      }
    }

    // Teams + round-1 scores
    for (const teamName of TEAM_POOLS[cat.slug] ?? []) {
      const [{ id: teamId }] = await db
        .insert(teams)
        .values({ categoryId, name: teamName, school: "SCIENJECT Delegate School" })
        .$returningId();

      for (const c of critIds.filter((x) => x.round === 1)) {
        await db.insert(scores).values({
          teamId,
          criteriaId: c.id,
          round: 1,
          value: seededValue(`${cat.slug}:${teamName}:${c.id}`, c.max),
        });
      }
    }
    console.log(`  ✓ ${cat.name}`);
  }

  await db.insert(announcements).values([
    { text: "📢 Welcome to SCIENJECT 6.0 — the Central Event Platform is now LIVE!", active: true },
    { text: "🏆 Round 1 evaluations are underway across all 13 categories.", active: true },
    { text: "📍 Delegates: check the Venue Room Directory on the Delegate Hub for your category rooms.", active: true },
  ]);

  console.log("Seed complete.");
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});

// Minimal PDF generator for category study-guide placeholder documents.
// No external dependencies — emits a single-page A4 PDF directly.

const GOLD = { r: 0.831, g: 0.686, b: 0.216 }; // #D4AF37
const CREAM = { r: 0.953, g: 0.898, b: 0.671 }; // #F3E5AB
const GRAY = { r: 0.35, g: 0.35, b: 0.35 };

function esc(s: string): string {
  return s.replace(/[^\x20-\x7E]/g, "").replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function wordWrap(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    if ((line + " " + w).trim().length > maxChars) {
      lines.push(line.trim());
      line = w;
    } else {
      line += " " + w;
    }
  }
  if (line.trim()) lines.push(line.trim());
  return lines;
}

export function buildStudyGuidePdf(opts: { name: string; discipline: string; description: string }): Buffer {
  interface T {
    x: number;
    y: number;
    font: "F1" | "F2";
    size: number;
    color: typeof GOLD;
    text: string;
  }
  const items: T[] = [
    { x: 70, y: 742, font: "F1", size: 30, color: GOLD, text: "SCIENJECT 6.0" },
    { x: 70, y: 720, font: "F2", size: 10, color: GRAY, text: "CENTRAL EVENT PLATFORM  |  OFFICIAL STUDY GUIDE SERIES" },
    { x: 70, y: 636, font: "F1", size: 22, color: GOLD, text: opts.name.toUpperCase() },
    { x: 70, y: 610, font: "F2", size: 12, color: GRAY, text: opts.discipline },
  ];

  let y = 572;
  for (const ln of wordWrap(opts.description, 86)) {
    items.push({ x: 70, y, font: "F2", size: 11, color: { r: 0.15, g: 0.15, b: 0.15 }, text: ln });
    y -= 16;
  }

  items.push(
    { x: 70, y: y - 26, font: "F1", size: 14, color: CREAM, text: "STUDY GUIDE — COMING SOON" },
    { x: 70, y: y - 48, font: "F2", size: 10, color: GRAY, text: "The full study guide for this category will be released by the Publications Department." },
    { x: 70, y: y - 62, font: "F2", size: 10, color: GRAY, text: "Watch the live announcement ticker for the release notice." },
    { x: 70, y: 96, font: "F2", size: 9, color: GRAY, text: "Lahore Grammar School Gulberg 15C O/A Level Campus  |  October 2-4, 2026" },
    { x: 70, y: 82, font: "F2", size: 9, color: GRAY, text: "Instagram @scienject_6.0  |  scienject6.0@gmail.com" },
  );

  const parts: string[] = ["BT"];
  for (const it of items) {
    parts.push(`${it.color.r} ${it.color.g} ${it.color.b} rg`);
    parts.push(`/${it.font} ${it.size} Tf`);
    parts.push(`1 0 0 1 ${it.x} ${it.y} Tm`);
    parts.push(`(${esc(it.text)}) Tj`);
  }
  // Gold rules
  parts.push(`${GOLD.r} ${GOLD.g} ${GOLD.b} RG`, "2 w", "70 700 m 525 700 l S", "70 646 m 525 646 l S");
  parts.push("ET");
  const content = parts.join("\n");

  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${content.length} >>\nstream\n${content}\nendstream`,
  ];

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [0];
  objects.forEach((body, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xrefPos = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
  return Buffer.from(pdf, "binary");
}

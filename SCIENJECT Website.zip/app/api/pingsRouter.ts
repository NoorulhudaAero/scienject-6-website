import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { categories, departments, messages } from "../db/schema";
import { resolveSession } from "./auth";

const tokenInput = { token: z.string().min(1) };

/**
 * Ping targets are encoded in the `toDepartment` column:
 *   "logistics"            → a single operations department
 *   "category:avionix"     → one category director desk
 *   "all-categories"       → broadcast to all 13 category director desks
 */
const ALL_CATEGORIES_TARGET = "all-categories";

/** Resolve any authenticated staff session and derive a display name. */
async function requireStaff(token: string | undefined) {
  const session = await resolveSession(token);
  const db = getDb();
  if (session.role === "admin") return { role: "admin" as const, name: "Master Admin" };
  if (session.role === "director" && session.categoryId != null) {
    const [cat] = await db.select().from(categories).where(eq(categories.id, session.categoryId)).limit(1);
    return { role: "director" as const, name: cat?.name ?? "Director" };
  }
  if (session.role === "department" && session.allocationSlug) {
    const [dept] = await db.select().from(departments).where(eq(departments.slug, session.allocationSlug)).limit(1);
    return { role: "department" as const, name: dept?.name ?? session.allocationSlug, slug: session.allocationSlug };
  }
  throw new TRPCError({ code: "FORBIDDEN", message: "Staff credentials required." });
}

export const pingsRouter = createRouter({
  /** Send a ping — to a department, a single category desk, or all 13 categories at once. */
  send: publicQuery
    .input(
      z.object({
        ...tokenInput,
        toDepartment: z.string().min(1).max(64).optional(),
        toCategory: z.string().min(1).max(64).optional(),
        text: z.string().min(1).max(500),
      }),
    )
    .mutation(async ({ input }) => {
      const sender = await requireStaff(input.token);
      const db = getDb();

      // Category broadcasts / category-targeted pings
      if (input.toCategory) {
        if (sender.role === "director") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Directors ping the support departments; category broadcast is a department/admin capability." });
        }
        if (input.toCategory === "all") {
          await db.insert(messages).values({
            senderRole: sender.role,
            senderName: sender.name,
            toDepartment: ALL_CATEGORIES_TARGET,
            text: input.text,
          });
          return { ok: true, deliveredTo: 13 };
        }
        const [cat] = await db.select().from(categories).where(eq(categories.slug, input.toCategory)).limit(1);
        if (!cat) throw new TRPCError({ code: "NOT_FOUND", message: `Category "${input.toCategory}" not found.` });
        await db.insert(messages).values({
          senderRole: sender.role,
          senderName: sender.name,
          toDepartment: `category:${cat.slug}`,
          text: input.text,
        });
        return { ok: true, deliveredTo: 1 };
      }

      if (!input.toDepartment) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Select a target department or category." });
      }
      await db.insert(messages).values({
        senderRole: sender.role,
        senderName: sender.name,
        toDepartment: input.toDepartment,
        text: input.text,
      });
      return { ok: true, deliveredTo: 1 };
    }),

  /** Unified feed — every staff role can view all pings (director + department + admin). */
  list: publicQuery.input(z.object(tokenInput)).query(async ({ input }) => {
    await requireStaff(input.token);
    const db = getDb();
    const [rows, cats] = await Promise.all([
      db.select().from(messages).orderBy(desc(messages.createdAt)).limit(100),
      db.select().from(categories),
    ]);
    return rows.map((m) => {
      let targetLabel = m.toDepartment;
      if (m.toDepartment === ALL_CATEGORIES_TARGET) targetLabel = "All 13 Categories";
      else if (m.toDepartment.startsWith("category:")) {
        const slug = m.toDepartment.slice("category:".length);
        targetLabel = `${cats.find((c) => c.slug === slug)?.name ?? slug} Desk`;
      }
      return { ...m, targetLabel };
    });
  }),

  /** Department list for the ping target dropdown. */
  departments: publicQuery.input(z.object(tokenInput)).query(async ({ input }) => {
    await requireStaff(input.token);
    const rows = await getDb().select().from(departments);
    return rows.map((d) => ({ slug: d.slug, name: d.name }));
  }),

  /** Category list for the category-broadcast target dropdown. */
  categories: publicQuery.input(z.object(tokenInput)).query(async ({ input }) => {
    await requireStaff(input.token);
    const rows = await getDb().select().from(categories);
    return rows.map((c) => ({ slug: c.slug, name: c.name }));
  }),
});

// Multi-page delegate passport PDF generator — one full page per student.
// Dependency-light: vector QR via qrcode-generator module matrix, crest JPEG
// embedded natively via DCTDecode, Type1 core fonts only (fully printable).

import qrcode from "qrcode-generator";
import { PASSPORT_LOGO_JPEG_B64, PASSPORT_LOGO_SIZE } from "./assets/passportLogo";

const GOLD = { r: 0.831, g: 0.686, b: 0.216 }; // #D4AF37
const DARKGOLD = { r: 0.62, g: 0.51, b: 0.16 };
const INK = { r: 0.08, g: 0.08, b: 0.08 };
const GRAY = { r: 0.38, g: 0.38, b: 0.38 };

const PAGE_W = 595;
const PAGE_H = 842;

export interface PassportMember {
  memberId: number;
  memberName: string;
}

export interface PassportRequest {
  teamName: string;
  school: string;
  categories: string[]; // the team's active categories (5 max)
  members: PassportMember[];
  verifiedAt: Date;
}

function esc(s: string): string {
  return s.replace(/[^\x20-\x7E]/g, "").replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function wordWrap(text: string, maxChars: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let line = "";
  for (const w of words) {
    if ((line + " " + w).trim().length > maxChars) {
      lines.push(line.trim());
      line = w;
    } else {
      line += " " + w;
    }
  }
  if (line.trim()) lines.push(line.trim());
  return lines;
}

/** Rough Helvetica width estimate (em-based) for horizontal centering. */
function textWidth(text: string, size: number, bold: boolean): number {
  let em = 0;
  for (const ch of text) {
    if (ch === " ") em += 0.278;
    else if (ch >= "0" && ch <= "9") em += 0.556;
    else if (ch >= "A" && ch <= "Z") em += bold ? 0.72 : 0.68;
    else if (ch >= "a" && ch <= "z") em += 0.52;
    else em += 0.333;
  }
  return em * size;
}

interface TextItem {
  x: number;
  y: number;
  font: "F1" | "F2";
  size: number;
  color: typeof GOLD;
  text: string;
  center?: boolean;
}

const INSTRUCTIONS =
  "DELEGATE INSTRUCTIONS: Save this individual QR code directly to your smartphone storage or print it out. " +
  "You must present this credential to the Registrations Desk on Day 1, Day 2, and Day 3 to seamlessly confirm " +
  "your identity on campus.";

/** Render one member's passport page content stream. */
function pageContent(req: PassportRequest, member: PassportMember): string {
  const parts: string[] = [];
  const texts: TextItem[] = [];
  const cx = PAGE_W / 2;

  // ── Gold double frame ────────────────────────────────────────────────
  parts.push(
    `${GOLD.r} ${GOLD.g} ${GOLD.b} RG`,
    "2.5 w",
    `28 28 ${PAGE_W - 56} ${PAGE_H - 56} re S`,
    "0.7 w",
    `35 35 ${PAGE_W - 70} ${PAGE_H - 70} re S`,
  );

  // ── Crest ────────────────────────────────────────────────────────────
  parts.push("q", `88 0 0 88 ${cx - 44} 690 cm`, "/Logo Do", "Q");

  // ── Header branding ──────────────────────────────────────────────────
  texts.push(
    { x: cx, y: 652, font: "F1", size: 27, color: DARKGOLD, text: "SCIENJECT 6.0", center: true },
    { x: cx, y: 634, font: "F2", size: 9.5, color: GRAY, text: "OFFICIAL DELEGATE CHECK-IN PASSPORT  |  CENTRAL EVENT PLATFORM", center: true },
    {
      x: cx,
      y: 618,
      font: "F2",
      size: 8.5,
      color: GRAY,
      text: `Verified ${req.verifiedAt.toISOString().replace("T", " ").slice(0, 19)} UTC  ·  Credential ID SC6-MBR-${member.memberId}`,
      center: true,
    },
  );
  parts.push(`${GOLD.r} ${GOLD.g} ${GOLD.b} RG`, "1.6 w", "90 604 m 505 604 l S");

  // ── QR passport code — bound to the student's system ID ─────────────
  const payload = `SCIENJECT6::CHECKIN::MEMBER::${member.memberId}`;
  const qr = qrcode(0, "M");
  qr.addData(payload);
  qr.make();
  const count = qr.getModuleCount();
  const quiet = 4;
  const cell = Math.floor(190 / (count + quiet * 2) * 100) / 100;
  const box = (count + quiet * 2) * cell;
  const boxX = cx - box / 2;
  const boxY = 356;

  // white card + gold ring behind the code
  parts.push(
    "1 1 1 rg",
    `${boxX - 14} ${boxY - 14} ${box + 28} ${box + 28} re f`,
    `${GOLD.r} ${GOLD.g} ${GOLD.b} RG`,
    "1.6 w",
    `${boxX - 14} ${boxY - 14} ${box + 28} ${box + 28} re S`,
    "0 0 0 rg",
  );
  for (let r = 0; r < count; r++) {
    for (let c = 0; c < count; c++) {
      if (qr.isDark(r, c)) {
        const x = boxX + (c + quiet) * cell;
        const y = boxY + box - (r + quiet + 1) * cell;
        parts.push(`${x.toFixed(2)} ${y.toFixed(2)} ${cell.toFixed(2)} ${cell.toFixed(2)} re f`);
      }
    }
  }

  texts.push(
    { x: cx, y: boxY - 32, font: "F1", size: 10.5, color: INK, text: payload, center: true },
    { x: cx, y: boxY - 46, font: "F2", size: 8, color: GRAY, text: "Scan at the Registrations Desk to confirm delegate identity", center: true },
  );

  // ── Profile block ────────────────────────────────────────────────────
  let y = boxY - 84;
  const row = (label: string, value: string) => {
    texts.push(
      { x: 92, y, font: "F1", size: 8.5, color: DARKGOLD, text: label.toUpperCase() },
      { x: 222, y, font: "F1", size: 11.5, color: INK, text: value },
    );
    y -= 21;
  };
  parts.push(`${GOLD.r} ${GOLD.g} ${GOLD.b} RG`, "0.8 w", `90 ${y + 12} m 505 ${y + 12} l S`);
  row("Member Name", member.memberName);
  row("Team Name", req.teamName);
  row("School Institution", req.school);
  const cats = req.categories.slice(0, 5);
  texts.push({ x: 92, y, font: "F1", size: 8.5, color: DARKGOLD, text: "ACTIVE CATEGORIES" });
  y -= 15;
  for (const cName of cats) {
    texts.push({ x: 222, y, font: "F2", size: 10, color: INK, text: `•  ${cName}` });
    y -= 14;
  }
  if (cats.length === 0) {
    texts.push({ x: 222, y, font: "F2", size: 10, color: GRAY, text: "—" });
    y -= 14;
  }

  // ── Delegate instructions (verbatim) ────────────────────────────────
  const insY = 128;
  parts.push(`${GOLD.r} ${GOLD.g} ${GOLD.b} RG`, "0.8 w", `90 ${insY + 46} m 505 ${insY + 46} l S`);
  // warning triangle glyph (vector stand-in for the ⚠️ marker)
  parts.push(
    `${GOLD.r} ${GOLD.g} ${GOLD.b} RG`,
    "1.4 w",
    `92 ${insY + 22} m 102 ${insY + 38} l 112 ${insY + 22} l h S`,
    "0 0 0 rg",
  );
  texts.push({ x: 99.2, y: insY + 24.5, font: "F1", size: 9, color: INK, text: "!" });
  let ty = insY + 30;
  for (const ln of wordWrap(INSTRUCTIONS, 78)) {
    texts.push({ x: 122, y: ty, font: "F2", size: 8.8, color: INK, text: ln });
    ty -= 11.5;
  }

  // ── Footer ───────────────────────────────────────────────────────────
  texts.push(
    {
      x: cx,
      y: 58,
      font: "F1",
      size: 8.5,
      color: DARKGOLD,
      text: "LAHORE GRAMMAR SCHOOL GULBERG 15C AND 16C O/A LEVEL CAMPUS",
      center: true,
    },
    { x: cx, y: 46, font: "F2", size: 8, color: GRAY, text: "October 2-4, 2026  |  scienject6.0@gmail.com  |  @scienject_6.0", center: true },
  );

  // ── Emit text ────────────────────────────────────────────────────────
  parts.push("BT");
  for (const it of texts) {
    const x = it.center ? it.x - textWidth(it.text, it.size, it.font === "F1") / 2 : it.x;
    parts.push(
      `${it.color.r} ${it.color.g} ${it.color.b} rg`,
      `/${it.font} ${it.size} Tf`,
      `1 0 0 1 ${x.toFixed(2)} ${it.y} Tm`,
      `(${esc(it.text)}) Tj`,
    );
  }
  parts.push("ET");
  return parts.join("\n");
}

/** Build the full multi-page passport deck — one page break per student. */
export function buildPassportPdf(req: PassportRequest): Buffer {
  const logoBytes = Buffer.from(PASSPORT_LOGO_JPEG_B64, "base64");
  const pages = req.members.map((m) => pageContent(req, m));

  // Object map: 1 catalog, 2 pages, 3 F1, 4 F2, 5 logo, then per page (page, content)
  const objects: (string | Buffer)[] = [];
  objects.push("<< /Type /Catalog /Pages 2 0 R >>");
  const kids = pages.map((_, i) => `${6 + i * 2} 0 R`).join(" ");
  objects.push(`<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
  objects.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
  objects.push("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  objects.push(
    Buffer.concat([
      Buffer.from(
        `<< /Type /XObject /Subtype /Image /Width ${PASSPORT_LOGO_SIZE} /Height ${PASSPORT_LOGO_SIZE} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${logoBytes.length} >>\nstream\n`,
      ),
      logoBytes,
      Buffer.from("\nendstream"),
    ]),
  );

  pages.forEach((content, i) => {
    objects.push(
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << /Logo 5 0 R >> >> /Contents ${7 + i * 2} 0 R >>`,
    );
    objects.push(`<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`);
  });

  const chunks: Buffer[] = [Buffer.from("%PDF-1.4\n")];
  const offsets: number[] = [0];
  let pos = chunks[0].length;
  objects.forEach((body, i) => {
    offsets.push(pos);
    const head = Buffer.from(`${i + 1} 0 obj\n`);
    const tail = Buffer.from("\nendobj\n");
    const payload = typeof body === "string" ? Buffer.from(body) : body;
    chunks.push(head, payload, tail);
    pos += head.length + payload.length + tail.length;
  });

  const xrefPos = pos;
  let xref = `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i++) xref += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  xref += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`;
  chunks.push(Buffer.from(xref));
  return Buffer.concat(chunks);
}

import { z } from "zod";
import { and, desc, eq, gt, lt } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { listScheduleChronological } from "./queries/schedule";
import { announcements, categories, criteria, feedbackResponses, flashAlerts, mediaItems, roundConfigs, scores, sponsors, teams } from "../db/schema";
import { membershipMap, teamsForCategory } from "./queries/teams";
import {
  COMPULSORY_POOL,
  COMPULSORY_R1,
  COMPULSORY_R2,
  COMPULSORY_R3,
  OPTIONAL_R1,
  OPTIONAL_R2,
  OPTIONAL_R3,
  isCompulsoryCategory,
} from "../contracts/pointScale";
import { asc } from "drizzle-orm";

/** Lazily clear expired evaluation clocks so they vanish from every public view. */
export async function clearExpiredEvalTimers() {
  await getDb()
    .update(categories)
    .set({ evalTimerEndsAt: null, evalTimerRound: null })
    .where(lt(categories.evalTimerEndsAt, new Date()));
}

/** Assemble a full leaderboard for one category + round. */
export async function buildLeaderboard(categoryId: number, round: number) {
  const db = getDb();
  await clearExpiredEvalTimers();
  const [category] = await db.select().from(categories).where(eq(categories.id, categoryId)).limit(1);
  if (!category) throw new TRPCError({ code: "NOT_FOUND", message: "Category not found." });

  const [config] = await db
    .select()
    .from(roundConfigs)
    .where(and(eq(roundConfigs.categoryId, categoryId), eq(roundConfigs.round, round)))
    .limit(1);

  const crits = await db
    .select()
    .from(criteria)
    .where(and(eq(criteria.categoryId, categoryId), eq(criteria.round, round)));

  const teamRows = (await teamsForCategory(categoryId)).sort((a, b) =>
    (a.school ?? "").localeCompare(b.school ?? "") || a.name.localeCompare(b.name),
  );

  const critIds = crits.map((c) => c.id);
  const scoreRows = critIds.length
    ? await db.select().from(scores).where(eq(scores.round, round))
    : [];
  const relevant = scoreRows.filter((s) => critIds.includes(s.criteriaId));

  const cutoff = config?.cutoffScore ?? 0;
  const board = teamRows
    .map((t) => {
      const cellMap: Record<number, number> = {};
      let total = 0;
      for (const c of crits) {
        const cell = relevant.find((s) => s.teamId === t.id && s.criteriaId === c.id);
        const v = cell?.value ?? 0;
        cellMap[c.id] = v;
        total += v;
      }
      total = Math.round(total * 10) / 10;
      return {
        id: t.id,
        name: t.name,
        school: t.school,
        scores: cellMap,
        total,
        graded: relevant.some((s) => s.teamId === t.id),
        status: total >= cutoff && cutoff > 0 ? ("Qualified" as const) : ("Eliminated" as const),
      };
    })
    .sort((a, b) => b.total - a.total)
    .map((t, i) => ({ ...t, rank: i + 1 }));

  return {
    category: {
      id: category.id,
      slug: category.slug,
      name: category.name,
      discipline: category.discipline,
      room: category.room,
      venue: category.venue,
      tagline: category.tagline,
      activeRound: category.activeRound,
      isLiveNow: category.isLiveNow,
      evalTimerEndsAt: category.evalTimerEndsAt,
      evalTimerRound: category.evalTimerRound,
    },
    round,
    criteria: crits.map((c) => ({ id: c.id, name: c.name, maxPoints: c.maxPoints })),
    config: config
      ? { cutoffScore: config.cutoffScore, closesAt: config.closesAt, resultsLive: config.resultsLive }
      : { cutoffScore: 0, closesAt: null, resultsLive: false },
    teams: board,
  };
}

export const publicRouter = createRouter({
  /** All 13 categories with venue info + team counts. */
  categories: publicQuery.query(async () => {
    const db = getDb();
    await clearExpiredEvalTimers();
    const cats = await db.select().from(categories);
    const membership = await membershipMap();
    return cats.map((c) => ({
      id: c.id,
      slug: c.slug,
      name: c.name,
      discipline: c.discipline,
      room: c.room,
      venue: c.venue,
      tagline: c.tagline,
      activeRound: c.activeRound,
      isLiveNow: c.isLiveNow,
      hasStudyGuide: Boolean(c.studyGuidePath),
      teamCount: [...membership.values()].filter((set) => set.has(c.id)).length,
    }));
  }),

  /** Active sponsor carousel entries. */
  sponsors: publicQuery.query(async () => {
    const rows = await getDb().select().from(sponsors).orderBy(asc(sponsors.sortOrder));
    return rows.map((r) => r.name);
  }),

  /** Master timeline schedule (admin-editable). */
  schedule: publicQuery.query(async () => {
    return listScheduleChronological();
  }),

  /**
   * Individual Team Leaderboard — the "Race for Best Delegation" master grid.
   *
   * Background scale-key conversion: for every team, each round column silently
   * converts director-flagged qualification status into fixed block scores from
   * the global point-scale variables (Compulsory R1=40 / Optional R1=25, etc.).
   * Raw rubric marks never appear here — only the standardized weight keys.
   * The Total column sums all three round blocks and the grid re-sorts live.
   */
  teamStandings: publicQuery.query(async () => {
    const db = getDb();
    await clearExpiredEvalTimers();
    const cats = await db.select().from(categories);
    const allTeams = await db.select().from(teams);
    const membership = await membershipMap();
    const configRows = await db.select().from(roundConfigs);
    const critRows = await db.select().from(criteria);
    const scoreRows = await db.select().from(scores);

    const weights = (slug: string) =>
      isCompulsoryCategory(slug)
        ? { r1: COMPULSORY_R1, r2: COMPULSORY_R2, r3: COMPULSORY_R3 }
        : { r1: OPTIONAL_R1, r2: OPTIONAL_R2, r3: OPTIONAL_R3 };

    const catCritIds = (categoryId: number, round: number) =>
      critRows.filter((c) => c.categoryId === categoryId && c.round === round).map((c) => c.id);

    const roundTotal = (teamId: number, categoryId: number, round: number) => {
      const ids = catCritIds(categoryId, round);
      if (!ids.length) return 0;
      return scoreRows
        .filter((s) => s.teamId === teamId && s.round === round && ids.includes(s.criteriaId))
        .reduce((sum, s) => sum + s.value, 0);
    };

    const roundGraded = (teamId: number, categoryId: number, round: number) => {
      const ids = catCritIds(categoryId, round);
      return scoreRows.some((s) => s.teamId === teamId && s.round === round && ids.includes(s.criteriaId));
    };

    const rows = allTeams.map((t) => {
      const catIds = [...(membership.get(t.id) ?? new Set([t.categoryId]))];
      let r1 = 0;
      let r2 = 0;
      let r3 = 0;
      for (const cid of catIds) {
        const cat = cats.find((c) => c.id === cid);
        if (!cat) continue;
        const w = weights(cat.slug);

        // R1 — cutoff qualification converts to the fixed R1 block score.
        const cfg1 = configRows.find((r) => r.categoryId === cid && r.round === 1);
        if (cfg1 && cfg1.cutoffScore > 0 && roundTotal(t.id, cid, 1) >= cfg1.cutoffScore) r1 += w.r1;

        // R2 — subsequent round qualification adds the sequential R2 weight.
        const cfg2 = configRows.find((r) => r.categoryId === cid && r.round === 2);
        if (cfg2 && cfg2.cutoffScore > 0 && roundTotal(t.id, cid, 2) >= cfg2.cutoffScore) r2 += w.r2;

        // R3 — podium finish (top 3 on the graded Round 3 board) adds the R3 weight.
        const cfg3 = configRows.find((r) => r.categoryId === cid && r.round === 3);
        if (cfg3 && roundGraded(t.id, cid, 3)) {
          const finalists = allTeams
            .filter((x) => membership.get(x.id)?.has(cid))
            .filter((x) => roundGraded(x.id, cid, 3))
            .map((x) => ({ id: x.id, total: roundTotal(x.id, cid, 3) }))
            .sort((a, b) => b.total - a.total);
          const rank = finalists.findIndex((x) => x.id === t.id) + 1;
          if (rank >= 1 && rank <= 3) r3 += w.r3;
        }
      }
      return { id: t.id, name: t.name, school: t.school, r1Pts: r1, r2Pts: r2, r3Pts: r3, total: r1 + r2 + r3 };
    });

    return rows
      .sort((a, b) => b.total - a.total || a.name.localeCompare(b.name))
      .map((r, i) => ({ ...r, rank: i + 1 }));
  }),

  /** Active ticker announcements. */
  ticker: publicQuery.query(async () => {
    const rows = await getDb()
      .select()
      .from(announcements)
      .where(eq(announcements.active, true))
      .orderBy(desc(announcements.createdAt));
    return rows.map((r) => r.text);
  }),

  /** Standardized Qualification Point Scale — live global config variables. */
  pointScale: publicQuery.query(async () => ({
    compulsory: { r1: COMPULSORY_R1, r2: COMPULSORY_R2, r3: COMPULSORY_R3 },
    optional: { r1: OPTIONAL_R1, r2: OPTIONAL_R2, r3: OPTIONAL_R3 },
    compulsoryPool: [...COMPULSORY_POOL],
  })),

  /**
   * Standalone delegate feedback submission — writes to the isolated
   * feedback_responses table, viewable exclusively in /admin.
   * No files or certificates are generated on submit.
   */
  submitFeedback: publicQuery
    .input(
      z.object({
        delegateName: z.string().min(1).max(255),
        school: z.string().max(255).optional(),
        role: z.string().max(64).default("Delegate"),
        overallRating: z.number().int().min(1).max(5),
        organizationRating: z.number().int().min(1).max(5),
        venueRating: z.number().int().min(1).max(5),
        judgingRating: z.number().int().min(1).max(5),
        favoriteCategory: z.string().max(255).optional(),
        highlights: z.string().max(4000).optional(),
        improvements: z.string().max(4000).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      await getDb().insert(feedbackResponses).values({
        delegateName: input.delegateName,
        school: input.school || null,
        role: input.role,
        overallRating: input.overallRating,
        organizationRating: input.organizationRating,
        venueRating: input.venueRating,
        judgingRating: input.judgingRating,
        favoriteCategory: input.favoriteCategory || null,
        highlights: input.highlights || null,
        improvements: input.improvements || null,
      });
      return { ok: true };
    }),

  /**
   * Active urgent flash alert (if any) — polled at low latency by the public
   * layout so an admin broadcast instantly overlays every public screen.
   */
  activeFlashAlert: publicQuery.query(async () => {
    const db = getDb();
    const [row] = await db
      .select()
      .from(flashAlerts)
      .where(gt(flashAlerts.expiresAt, new Date()))
      .orderBy(desc(flashAlerts.createdAt))
      .limit(1);
    return row ? { id: row.id, text: row.text, createdAt: row.createdAt } : null;
  }),

  /** Public media gallery — photos + video highlights grouped for day tabs. */
  mediaGallery: publicQuery.query(async () => {
    const rows = await getDb().select().from(mediaItems).orderBy(desc(mediaItems.createdAt));
    return rows.map((r) => ({ id: r.id, kind: r.kind, url: r.url, title: r.title, dayTag: r.dayTag, orientation: r.orientation }));
  }),

  /** Public live leaderboard for a category + round. */
  leaderboard: publicQuery
    .input(z.object({ categorySlug: z.string(), round: z.number().int().min(1).max(3) }))
    .query(async ({ input }) => {
      const db = getDb();
      const [cat] = await db.select().from(categories).where(eq(categories.slug, input.categorySlug)).limit(1);
      if (!cat) throw new TRPCError({ code: "NOT_FOUND", message: "Category not found." });
      return buildLeaderboard(cat.id, input.round);
    }),
});

import { eq } from "drizzle-orm";
import { getDb } from "./connection";
import { teamRegistrations, teams, type Team } from "../../db/schema";

/**
 * Authoritative category-membership resolver.
 * A team belongs to a category if it has a join-table registration row OR its
 * legacy primary `teams.categoryId` matches. Returns full team rows.
 */
export async function teamsForCategory(categoryId: number): Promise<Team[]> {
  const db = getDb();
  const [regs, allTeams] = await Promise.all([
    db.select().from(teamRegistrations).where(eq(teamRegistrations.categoryId, categoryId)),
    db.select().from(teams),
  ]);
  const memberIds = new Set(regs.map((r) => r.teamId));
  return allTeams.filter((t) => memberIds.has(t.id) || t.categoryId === categoryId);
}

/** All registration rows as a teamId → categoryIds map (plus legacy primary). */
export async function membershipMap(): Promise<Map<number, Set<number>>> {
  const db = getDb();
  const [regs, allTeams] = await Promise.all([
    db.select().from(teamRegistrations),
    db.select().from(teams),
  ]);
  const map = new Map<number, Set<number>>();
  const add = (teamId: number, categoryId: number) => {
    const set = map.get(teamId) ?? new Set<number>();
    set.add(categoryId);
    map.set(teamId, set);
  };
  for (const r of regs) add(r.teamId, r.categoryId);
  for (const t of allTeams) add(t.id, t.categoryId);
  return map;
}

/** Check whether a team is registered in a category (join table or legacy primary). */
export async function teamBelongsToCategory(teamId: number, categoryId: number): Promise<boolean> {
  const db = getDb();
  const [team] = await db.select().from(teams).where(eq(teams.id, teamId)).limit(1);
  if (!team) return false;
  if (team.categoryId === categoryId) return true;
  const regs = await db.select().from(teamRegistrations).where(eq(teamRegistrations.teamId, teamId));
  return regs.some((r) => r.categoryId === categoryId);
}

/** Register a team into a category (idempotent). */
export async function registerTeamInCategory(teamId: number, categoryId: number) {
  await getDb()
    .insert(teamRegistrations)
    .values({ teamId, categoryId })
    .onDuplicateKeyUpdate({ set: { teamId } });
}

/** Remove a team's registration from one category. */
export async function unregisterTeamFromCategory(teamId: number, categoryId: number) {
  const db = getDb();
  const regs = await db.select().from(teamRegistrations).where(eq(teamRegistrations.teamId, teamId));
  const row = regs.find((r) => r.categoryId === categoryId);
  if (row) await db.delete(teamRegistrations).where(eq(teamRegistrations.id, row.id));
}

/* ─────────────── Row-based member roster engine ─────────────── */

import { categories, teamMembers } from "../../db/schema";
import { TRPCError } from "@trpc/server";

/** teamId → ordered member names. */
export async function membersMap(teamIds?: number[]): Promise<Map<number, string[]>> {
  const db = getDb();
  const rows = await db.select().from(teamMembers);
  const map = new Map<number, string[]>();
  for (const r of rows) {
    if (teamIds && !teamIds.includes(r.teamId)) continue;
    const list = map.get(r.teamId) ?? [];
    list.push(r.name);
    map.set(r.teamId, list);
  }
  return map;
}

/** Resolve a free-text category reference ("Avionix", "pitch-craft", "Pitchcraft") to a category row. */
export function resolveCategoryRef(ref: string, cats: { id: number; slug: string; name: string }[]) {
  const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");
  const needle = norm(ref);
  if (!needle) return undefined;
  return cats.find((c) => norm(c.name) === needle || norm(c.slug) === needle);
}

/** Split one CSV line into fields — quote-aware, comma/semicolon/tab delimiters. */
export function splitCsvLine(line: string): string[] {
  const fields: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
      else inQuotes = !inQuotes;
    } else if (!inQuotes && (ch === "," || ch === ";" || ch === "\t")) {
      fields.push(cur);
      cur = "";
    } else {
      cur += ch;
    }
  }
  fields.push(cur);
  return fields.map((f) => f.trim());
}

export interface MemberRow {
  teamName: string;
  school: string;
  memberName: string;
  categoriesRaw: string;
}

/**
 * Parse the member-roster sheet. Expected columns:
 * [Team Name, School Institution, Member Name, Categories]
 * The Categories cell accepts a comma-separated list ("Avionix, Pitchcraft").
 * If a line yields more than 4 raw fields, fields 4..n are merged as the categories list.
 */
export function parseMemberRows(csvText: string): MemberRow[] {
  const rows: MemberRow[] = [];
  for (const rawLine of csvText.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;
    if (/^team\s*name/i.test(line)) continue; // header row
    const fields = splitCsvLine(line);
    if (fields.length < 3) continue;
    const [teamName, school, memberName, ...rest] = fields;
    if (!teamName || !memberName) continue;
    rows.push({ teamName, school: school ?? "", memberName, categoriesRaw: rest.join(", ") });
  }
  return rows;
}

/**
 * Ingest member rows: create/find the team, register it into every parsed category
 * (cross-populating every listed director dashboard), then insert the member row.
 */
export async function importMemberRows(rows: MemberRow[]) {
  const db = getDb();
  const cats = await db.select().from(categories);
  const allTeams = await db.select().from(teams);
  const membership = await membershipMap();

  const byKey = new Map(allTeams.map((t) => [`${t.name.trim().toLowerCase()}|${(t.school ?? "").trim().toLowerCase()}`, t]));

  let membersInserted = 0;
  let teamsCreated = 0;
  const warnings: string[] = [];

  for (const row of rows) {
    // Parse the multi-select Categories cell
    const refs = row.categoriesRaw.split(/[,;|\/]/).map((s) => s.trim()).filter(Boolean);
    const catIds: number[] = [];
    for (const ref of refs) {
      const cat = resolveCategoryRef(ref, cats);
      if (!cat) {
        warnings.push(`Unknown category "${ref}" for ${row.teamName} — skipped that entry`);
        continue;
      }
      if (!catIds.includes(cat.id)) catIds.push(cat.id);
    }
    if (catIds.length === 0) {
      warnings.push(`No valid categories for ${row.teamName} / ${row.memberName} — row skipped`);
      continue;
    }

    // Find or create the team entity (keyed by name + school)
    const key = `${row.teamName.trim().toLowerCase()}|${row.school.trim().toLowerCase()}`;
    let team = byKey.get(key);
    if (!team) {
      const [{ id }] = await db
        .insert(teams)
        .values({ categoryId: catIds[0], name: row.teamName.trim(), school: row.school.trim() || null })
        .$returningId();
      team = { id } as (typeof allTeams)[number];
      byKey.set(key, team);
      teamsCreated++;
    }

    // Cross-populate: register into every category listed on the row
    for (const categoryId of catIds) {
      if (!membership.get(team.id)?.has(categoryId)) {
        await registerTeamInCategory(team.id, categoryId);
        const set = membership.get(team.id) ?? new Set<number>();
        set.add(categoryId);
        membership.set(team.id, set);
      }
    }

    // Insert the individual member row (deduped by unique teamId+name)
    try {
      await db.insert(teamMembers).values({ teamId: team.id, name: row.memberName.trim() });
      membersInserted++;
    } catch {
      // duplicate member row — idempotent skip
    }
  }

  return { membersInserted, teamsCreated, warnings };
}

/** Storage location for an uploaded category study-guide PDF. */
export function studyGuidePublicPath(slug: string) {
  return `/api/study-guide/${encodeURIComponent(slug)}`;
}

export function assertPdf(base64: string): Buffer {
  let buf: Buffer;
  try {
    buf = Buffer.from(base64, "base64");
  } catch {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Corrupt upload payload." });
  }
  if (buf.length < 100) throw new TRPCError({ code: "BAD_REQUEST", message: "File is too small to be a PDF." });
  if (buf.length > 20 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "PDF exceeds the 20 MB limit." });
  if (buf.subarray(0, 5).toString("latin1") !== "%PDF-") {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Only PDF files are accepted." });
  }
  return buf;
}

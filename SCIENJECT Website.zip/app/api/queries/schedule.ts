import { asc } from "drizzle-orm";
import { getDb } from "./connection";
import { scheduleItems } from "../../db/schema";

const MONTH_INDEX: Record<string, number> = {
  jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
  jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11,
};

/**
 * Chronological sort key for one itinerary card, derived from its human labels.
 * Accepts day labels like "Oct 2" / "October 3, 2026" and times like
 * "08:30", "9:00 AM", "17:45". Unparseable parts fall back to the earliest
 * slot of the event window; the stored sortOrder breaks exact ties.
 */
function scheduleSortKey(dayLabel: string, timeLabel: string, sortOrder: number): number {
  const dm = dayLabel.match(/([A-Za-z]{3})[a-z]*\s+(\d{1,2})/);
  const month = dm ? MONTH_INDEX[dm[1].slice(0, 3).toLowerCase()] ?? 9 : 9;
  const day = dm ? Number(dm[2]) : 1;

  const tm = timeLabel.match(/(\d{1,2})(?::(\d{2}))?\s*([AaPp][Mm])?/);
  let minutes = 0;
  if (tm) {
    let h = Number(tm[1]);
    const m = Number(tm[2] ?? 0);
    if (tm[3]) {
      const ap = tm[3].toLowerCase();
      if (ap === "pm" && h < 12) h += 12;
      if (ap === "am" && h === 12) h = 0;
    }
    minutes = h * 60 + m;
  }

  return ((month * 31 + day) * 1440 + minutes) * 100_000 + sortOrder;
}

/**
 * Master timeline listing with the automatic chronological alignment loop:
 * every fetch re-sequences the cards ascending by (date, time), so a newly
 * appended slot lands in its correct position on the public itinerary without
 * any manual re-ordering.
 */
export async function listScheduleChronological() {
  const rows = await getDb().select().from(scheduleItems).orderBy(asc(scheduleItems.sortOrder));
  return rows
    .map((r) => ({ ...r, _key: scheduleSortKey(r.dayLabel, r.timeLabel, r.sortOrder) }))
    .sort((a, b) => a._key - b._key)
    .map(({ _key, ...r }) => r);
}
